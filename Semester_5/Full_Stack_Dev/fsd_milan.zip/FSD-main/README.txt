# Simple Student Management System (Practical 9)

## Features
- Login with three roles: Student, Faculty, Admin
- Search one student using UID
- Faculty/Admin can add and update students
- Admin can delete students
- Uses MySQL, Node.js, Express, Bootstrap and Tailwind CSS
- Does not include View All Students, View Unique Courses, Create Table, or Drop Table buttons

## 1. Install packages
Open a terminal in this project folder and run:

```bash
npm init -y
npm install express mysql2
```

## 2. Configure MySQL
Open `server.js` and update this section with your MySQL password:

```js
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'password'
});
```

The server creates the `prac8_db` database and `students` table automatically.

## 3. Run the project
Make sure MySQL Server is running. Then run:

```bash
node server.js
```

Open `http://localhost:3000` in your browser.

## Demo login accounts
- Admin: username `admin`, password `123`
- Faculty: username `faculty`, password `123`
- Student: username `student`, password `123`

## Role permissions
- Student: Search a student by UID
- Faculty: Search, add, and update students
- Admin: Search, add, update, and delete students

## Practical note
This is a simplified college practical. The demo login accounts are stored in the server code and are not suitable for a production system. For production, use server-side sessions or secure tokens and store hashed passwords. The role value sent by the browser can be modified, so production applications must verify permissions using trusted server-side authentication.
