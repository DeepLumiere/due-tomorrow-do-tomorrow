const express = require('express');
const mysql = require('mysql2');
const path = require('path');

const app = express();
const PORT = 3000;

// Read form data and JSON data
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// MySQL connection
// Change the password below to your own MySQL root password.
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'password'
});

// Simple accounts for this college practical
const USERS = [
    { username: 'admin', password: '123', role: 'Admin' },
    { username: 'faculty', password: '123', role: 'Faculty' },
    { username: 'student', password: '123', role: 'Student' }
];

// Operations allowed for each role
const PERMISSIONS = {
    Student: ['search'],
    Faculty: ['search', 'insert', 'update'],
    Admin: ['search', 'insert', 'update', 'delete']
};

// Check whether a role can perform an operation
function canAccess(role, operation) {
    return (PERMISSIONS[role] || []).includes(operation);
}

// Show a message and return to the previous page
function showMessage(res, message) {
    res.send(`
        <!DOCTYPE html>
        <html>
        <head><meta charset="UTF-8"><title>Student Management</title></head>
        <body>
            <script>
                alert(${JSON.stringify(message)});
                history.back();
            </script>
        </body>
        </html>
    `);
}

// Create database and student table when the server starts
db.connect((err) => {
    if (err) {
        console.error('MySQL connection failed:', err.message);
        return;
    }

    console.log('Connected to MySQL.');

    db.query('CREATE DATABASE IF NOT EXISTS prac8_db', (err) => {
        if (err) {
            console.error('Could not create database:', err.message);
            return;
        }

        db.changeUser({ database: 'prac8_db' }, (err) => {
            if (err) {
                console.error('Could not select database:', err.message);
                return;
            }

            const sql = `
                CREATE TABLE IF NOT EXISTS students (
                    uid VARCHAR(50) PRIMARY KEY,
                    name VARCHAR(100) NOT NULL,
                    course VARCHAR(100) NOT NULL
                )
            `;

            db.query(sql, (err) => {
                if (err) {
                    console.error('Could not create students table:', err.message);
                    return;
                }
                console.log('Database and students table are ready.');
            });
        });
    });
});

// Open the home page
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Login
app.post('/api/login', (req, res) => {
    const username = (req.body.username || '').trim();
    const password = req.body.password || '';

    const user = USERS.find(
        account => account.username === username && account.password === password
    );

    if (!user) {
        return res.status(401).json({
            success: false,
            message: 'Invalid username or password.'
        });
    }

    res.json({
        success: true,
        user: {
            username: user.username,
            role: user.role
        }
    });
});

// Add a student: Faculty and Admin
app.post('/insert', (req, res) => {
    const role = req.body.userRole;

    if (!canAccess(role, 'insert')) {
        return showMessage(res, 'Access denied. Faculty or Admin is required.');
    }

    const { uid, name, course } = req.body;

    db.query(
        'INSERT INTO students (uid, name, course) VALUES (?, ?, ?)',
        [uid, name, course],
        (err) => {
            if (err) {
                if (err.code === 'ER_DUP_ENTRY') {
                    return showMessage(res, 'This UID already exists.');
                }
                return showMessage(res, 'Could not add student: ' + err.message);
            }

            showMessage(res, 'Student added successfully.');
        }
    );
});

// Update a student: Faculty and Admin
app.post('/update', (req, res) => {
    const role = req.body.userRole;

    if (!canAccess(role, 'update')) {
        return showMessage(res, 'Access denied. Faculty or Admin is required.');
    }

    const { uid, name, course } = req.body;

    db.query(
        'UPDATE students SET name = ?, course = ? WHERE uid = ?',
        [name, course, uid],
        (err, result) => {
            if (err) {
                return showMessage(res, 'Could not update student: ' + err.message);
            }

            if (result.affectedRows === 0) {
                return showMessage(res, 'No student found with this UID.');
            }

            showMessage(res, 'Student updated successfully.');
        }
    );
});

// Search for one student by UID: all roles
app.get('/select-record', (req, res) => {
    const role = req.query.userRole;

    if (!canAccess(role, 'search')) {
        return showMessage(res, 'Access denied. Please log in first.');
    }

    const uid = req.query.uid;

    db.query(
        'SELECT uid, name, course FROM students WHERE uid = ?',
        [uid],
        (err, rows) => {
            if (err) {
                return showMessage(res, 'Could not search student: ' + err.message);
            }

            if (rows.length === 0) {
                return showMessage(res, 'No student found with this UID.');
            }

            const student = rows[0];
            showMessage(
                res,
                'Student Details\\nUID: ' + student.uid +
                '\\nName: ' + student.name +
                '\\nCourse: ' + student.course
            );
        }
    );
});

// Delete a student: Admin only
app.post('/delete', (req, res) => {
    const role = req.body.userRole;

    if (!canAccess(role, 'delete')) {
        return showMessage(res, 'Access denied. Only Admin can delete students.');
    }

    const uid = req.body.uid;

    db.query('DELETE FROM students WHERE uid = ?', [uid], (err, result) => {
        if (err) {
            return showMessage(res, 'Could not delete student: ' + err.message);
        }

        if (result.affectedRows === 0) {
            return showMessage(res, 'No student found with this UID.');
        }

        showMessage(res, 'Student deleted successfully.');
    });
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
