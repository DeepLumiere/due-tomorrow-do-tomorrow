// 1 Single Middleware Function for Auth & Role Authorization
// Admin: has all 4 permissions ('create', 'read', 'update', 'delete')
// User: has just 'create' and 'read'
const checkAuth = (action) => {
  return (req, res, next) => {
    // Read role directly from header (e.g. role: admin or role: user)
    const role = (req.headers['role'] || '').toLowerCase();

    // 1. Admin has access to all actions
    if (role === 'admin') {
      req.user = { role: 'admin' };
      return next();
    }

    // 2. User only has 'create' and 'read'
    if (role === 'user' && (action === 'create' || action === 'read')) {
      req.user = { role: 'user' };
      return next();
    }

    // Otherwise access denied
    return res.status(403).json({
      error: 'Forbidden',
      message: `Role '${role || 'none'}' is not authorized to '${action}'. Admin can do all 4, User can only create and read.`
    });
  };
};

module.exports = { checkAuth };
