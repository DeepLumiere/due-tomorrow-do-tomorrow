const express = require('express');
const router = express.Router();

// Static user list (No encryption, simple plain credentials)
const USERS = [
  { username: 'admin', password: 'admin123', role: 'admin' },
  { username: 'user', password: 'user123', role: 'user' }
];

// Simple Login Endpoint
router.post('/login', (req, res) => {
  const { username, password } = req.body;

  const foundUser = USERS.find(u => u.username === username && u.password === password);

  if (!foundUser) {
    return res.status(401).json({
      error: 'Unauthorized',
      message: 'Invalid credentials. Use admin/admin123 or user/user123'
    });
  }

  res.json({
    message: 'Login successful',
    user: {
      username: foundUser.username,
      role: foundUser.role
    },
    usageHint: `Send header: "role: ${foundUser.role}" on CRUD requests`
  });
});

module.exports = router;
