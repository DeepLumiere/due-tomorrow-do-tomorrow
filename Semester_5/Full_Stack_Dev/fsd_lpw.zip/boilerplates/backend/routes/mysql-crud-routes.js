const express = require('express');
const router = express.Router();
const { pool } = require('../config/db-mysql');
const { checkAuth } = require('../middleware/auth');

// 1. READ ALL + QUERY SEARCH (Allowed: admin, user)
// Examples:
//   /api/mysql/items?search=node
//   /api/mysql/items?title=api
router.get('/items', checkAuth('read'), async (req, res) => {
  try {
    const { search, title } = req.query;
    let sql = 'SELECT * FROM items WHERE 1=1';
    let params = [];

    if (search) {
      sql += ' AND (title LIKE ? OR description LIKE ?)';
      params.push(`%${search}%`, `%${search}%`);
    }
    if (title) {
      sql += ' AND title LIKE ?';
      params.push(`%${title}%`);
    }

    sql += ' ORDER BY id DESC';

    const [rows] = await pool.query(sql, params);
    res.json({ total: rows.length, items: rows });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 2. READ ONE BY ID (Allowed: admin, user)
router.get('/items/:id', checkAuth('read'), async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM items WHERE id = ?', [req.params.id]);
    if (rows.length === 0) return res.status(404).json({ message: 'Item not found' });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 3. CREATE (Allowed: admin, user)
router.post('/items', checkAuth('create'), async (req, res) => {
  try {
    const { title, description } = req.body;
    if (!title) return res.status(400).json({ message: 'Title is required' });

    const [result] = await pool.query(
      'INSERT INTO items (title, description) VALUES (?, ?)',
      [title, description || '']
    );

    res.status(201).json({
      message: 'Item created',
      item: { id: result.insertId, title, description: description || '' }
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 4. UPDATE (Allowed: admin ONLY)
router.put('/items/:id', checkAuth('update'), async (req, res) => {
  try {
    const { title, description } = req.body;
    const [result] = await pool.query(
      'UPDATE items SET title = COALESCE(?, title), description = COALESCE(?, description) WHERE id = ?',
      [title, description, req.params.id]
    );

    if (result.affectedRows === 0) return res.status(404).json({ message: 'Item not found' });
    res.json({ message: 'Item updated', id: req.params.id });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 5. DELETE (Allowed: admin ONLY)
router.delete('/items/:id', checkAuth('delete'), async (req, res) => {
  try {
    const [result] = await pool.query('DELETE FROM items WHERE id = ?', [req.params.id]);
    if (result.affectedRows === 0) return res.status(404).json({ message: 'Item not found' });
    res.json({ message: 'Item deleted', id: req.params.id });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
