const express = require('express');
const router = express.Router();
const Item = require('../models/mongo-item');
const { checkAuth } = require('../middleware/auth');

// 1. READ ALL + QUERY SEARCH (Allowed: admin, user)
// Examples:
//   /api/mongo/items?search=node
//   /api/mongo/items?category=Backend&title=api
router.get('/items', checkAuth('read'), async (req, res) => {
  try {
    const { search, title, category } = req.query;
    let filter = {};

    if (search) {
      filter.$or = [
        { title: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } },
        { category: { $regex: search, $options: 'i' } }
      ];
    }
    if (title) filter.title = { $regex: title, $options: 'i' };
    if (category) filter.category = category;

    const items = await Item.find(filter).sort({ createdAt: -1 });
    res.json({ total: items.length, items });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 2. READ ONE BY ID (Allowed: admin, user)
router.get('/items/:id', checkAuth('read'), async (req, res) => {
  try {
    const item = await Item.findById(req.params.id);
    if (!item) return res.status(404).json({ message: 'Item not found' });
    res.json(item);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 3. CREATE (Allowed: admin, user)
router.post('/items', checkAuth('create'), async (req, res) => {
  try {
    const { title, description, category } = req.body;
    if (!title) return res.status(400).json({ message: 'Title is required' });

    const newItem = await Item.create({
      title,
      description: description || '',
      category: category || 'General'
    });

    res.status(201).json({ message: 'Item created', item: newItem });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// 4. UPDATE (Allowed: admin ONLY)
router.put('/items/:id', checkAuth('update'), async (req, res) => {
  try {
    const updated = await Item.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!updated) return res.status(404).json({ message: 'Item not found' });
    res.json({ message: 'Item updated', item: updated });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// 5. DELETE (Allowed: admin ONLY)
router.delete('/items/:id', checkAuth('delete'), async (req, res) => {
  try {
    const deleted = await Item.findByIdAndDelete(req.params.id);
    if (!deleted) return res.status(404).json({ message: 'Item not found' });
    res.json({ message: 'Item deleted', id: req.params.id });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
