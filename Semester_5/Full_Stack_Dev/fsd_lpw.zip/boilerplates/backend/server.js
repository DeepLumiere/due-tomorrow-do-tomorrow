require('dotenv').config();
const express = require('express');
const cors = require('cors');

const connectMongo = require('./config/db-mongo');
const { initMySQL } = require('./config/db-mysql');

const authRoutes = require('./routes/auth-routes');
const mongoCrudRoutes = require('./routes/mongo-crud-routes');
const mysqlCrudRoutes = require('./routes/mysql-crud-routes');

const app = express();
const PORT = process.env.PORT || 5000;

// Middlewares
app.use(cors());
app.use(express.json());

// Initialize Database Connections
connectMongo();
initMySQL();

// Route Mounts
app.use('/api/auth', authRoutes);
app.use('/api/mongo', mongoCrudRoutes);
app.use('/api/mysql', mysqlCrudRoutes);

// Health check / root route
app.get('/', (req, res) => {
  res.json({
    status: 'online',
    endpoints: {
      auth: '/api/auth (register, login, static-login, profile, admin-dashboard)',
      mongoCRUD: '/api/mongo/items',
      mysqlCRUD: '/api/mysql/items'
    }
  });
});

app.listen(PORT, () => {
  console.log(`Server listening on http://localhost:${PORT}`);
});
