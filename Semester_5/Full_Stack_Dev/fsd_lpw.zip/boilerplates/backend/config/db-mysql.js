const mysql = require('mysql2/promise');

// XAMPP Default credentials: user: 'root', password: '', host: 'localhost', port: 3306
const pool = mysql.createPool({
  host: process.env.MYSQL_HOST || 'localhost',
  user: process.env.MYSQL_USER || 'root',
  password: process.env.MYSQL_PASSWORD || '',
  database: process.env.MYSQL_DATABASE || 'fsd_db',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// Helper to initialize database and table if not already created
const initMySQL = async () => {
  try {
    // Connect without DB first to ensure DB exists
    const rootConn = await mysql.createConnection({
      host: process.env.MYSQL_HOST || 'localhost',
      user: process.env.MYSQL_USER || 'root',
      password: process.env.MYSQL_PASSWORD || ''
    });

    await rootConn.query(`CREATE DATABASE IF NOT EXISTS \`${process.env.MYSQL_DATABASE || 'fsd_db'}\`;`);
    await rootConn.end();

    // Now test connection on the pool and create sample table
    const [rows] = await pool.query(`
      CREATE TABLE IF NOT EXISTS items (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        description TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);
    console.log('MySQL connected and "items" table verified');
  } catch (error) {
    console.error('MySQL connection error (ensure XAMPP MySQL is running):', error.message);
  }
};

module.exports = { pool, initMySQL };
