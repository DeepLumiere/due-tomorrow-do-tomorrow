# Frontend Component Variants, States & Architectural Patterns

This guide lists the possible variants, pseudo-classes, component states, and design patterns for **Tailwind CSS**, **Bootstrap 5**, and **Vue 3** so you can easily reference and adapt them to any project requirement.

---

## 1. Tailwind CSS Variants & Patterns

Tailwind uses variant prefixes to apply styles conditionally based on state, screen size, themes, or DOM relationships.

### A. State & Pseudo-Class Variants
| Variant Prefix | Trigger Condition | Practical Example |
|---|---|---|
| `hover:` | Mouse hover | `hover:bg-indigo-700 hover:shadow-lg` |
| `focus:` | Element focus (clicks, tab navigation) | `focus:ring-2 focus:ring-indigo-500 focus:outline-none` |
| `focus-visible:` | Keyboard-only focus (accessibility) | `focus-visible:ring-2 focus-visible:ring-offset-2` |
| `active:` | Moment of click / press | `active:scale-95 active:bg-indigo-800` |
| `disabled:` | Disabled input or button | `disabled:opacity-50 disabled:cursor-not-allowed` |
| `group-hover:` | Parent with `.group` is hovered | `<div class="group"><span class="group-hover:text-blue-500">` |
| `peer-checked:` | Sibling checkbox with `.peer` is checked | `<input type="checkbox" class="peer hidden"/><div class="peer-checked:bg-blue-600">` (toggle switches) |
| `peer-invalid:` | Sibling input is invalid | `peer-invalid:block text-red-500` (zero-JS validation messages) |
| `focus-within:` | Any child element has focus | `focus-within:border-indigo-500` on input wrappers |

### B. List, Child & Table Variants
- **Alternating Table Rows**: `odd:bg-white even:bg-slate-50`
- **First & Last Items**: `first:pt-0 last:pb-0`, `first:rounded-t-lg last:rounded-b-lg`
- **Empty States**: `empty:hidden` (hides badges or lists when no text exists)

### C. Responsive Breakpoint Variants
- Mobile-first approach:
  - Default (mobile): `< 640px`
  - `sm:` `>= 640px` (Tablets / large phones)
  - `md:` `>= 768px` (Laptops / tablets landscape)
  - `lg:` `>= 1024px` (Desktops)
  - `xl:` `>= 1280px` (Large desktops)
  - `2xl:` `>= 1536px` (Ultra-wide screens)

### D. Dark Mode Strategies
- **Class Strategy** (`class="dark"` on `<html>`): `bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100`
- **Media Strategy** (automatic OS preference detection): `dark:` applies when OS prefers dark.

### E. Popular Button & Badge Variants
```html
<!-- 1. Solid Primary Button -->
<button class="bg-indigo-600 hover:bg-indigo-700 text-white font-medium px-4 py-2 rounded-lg shadow-sm">Solid</button>

<!-- 2. Outline Button -->
<button class="border border-indigo-600 text-indigo-600 hover:bg-indigo-50 font-medium px-4 py-2 rounded-lg">Outline</button>

<!-- 3. Soft / Subtle Button -->
<button class="bg-indigo-100 hover:bg-indigo-200 text-indigo-700 font-medium px-4 py-2 rounded-lg">Soft</button>

<!-- 4. Ghost Button -->
<button class="text-slate-600 hover:bg-slate-100 font-medium px-4 py-2 rounded-lg">Ghost</button>

<!-- 5. Status Badges -->
<span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800">Active</span>
<span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-100 text-amber-800">Pending</span>
```

### F. Popular Tailwind Component Libraries & Ecosystem
- **DaisyUI**: Semantic component classes on top of Tailwind (`btn btn-primary`, `modal`, `card`).
- **Flowbite**: Interactive components with vanilla JS scripts (accordions, dropdowns, datepickers).
- **Headless UI**: Unstyled, accessible UI components (Tabs, Dialogs, Combobox) designed to be styled with Tailwind.
- **shadcn/ui**: Copy-paste accessible components built on Tailwind + Radix primitives.

---

## 2. Bootstrap 5 Variants & Component Patterns

Bootstrap 5 provides a comprehensive class dictionary and built-in JavaScript component plugins.

### A. Theme Colors Applied Across Components
Bootstrap's core palette: `primary`, `secondary`, `success`, `danger`, `warning`, `info`, `light`, `dark`.
- **Buttons**:
  - Solid: `.btn-primary`, `.btn-success`, `.btn-danger`
  - Outline: `.btn-outline-primary`, `.btn-outline-secondary`
  - Sizing: `.btn-sm`, `.btn-lg`
- **Badges**:
  - Solid: `.badge .bg-primary`, `.badge .bg-success`
  - Subtle / Text-Bg: `.badge .text-bg-warning`, `.badge .text-bg-info`
  - Rounded Pill: `.rounded-pill`
- **Alerts**:
  - `.alert .alert-success`, `.alert .alert-danger`, `.alert .alert-warning`
  - Dismissible: `.alert-dismissible .fade .show` + `<button class="btn-close" data-bs-dismiss="alert"></button>`

### B. Table Variants
- **Striped Rows**: `.table .table-striped`
- **Hoverable Rows**: `.table .table-hover`
- **Border Options**: `.table-bordered`, `.table-borderless`, `.table-sm`
- **Color Themes**: `.table-dark`, `.table-primary`, `.table-light`
- **Responsive Wrapper**: `.table-responsive`, `.table-responsive-md`

### C. Form Variants
- **Floating Labels**:
  ```html
  <div class="form-floating mb-3">
    <input type="text" class="form-control" id="fId" placeholder="Name">
    <label for="fId">Your Name</label>
  </div>
  ```
- **Validation Classes**:
  - `.was-validated` on `<form>` triggers native browser validation icons & styles.
  - Manual states on inputs: `.is-valid` (green check) vs `.is-invalid` (red warning)
  - Feedback captions: `.valid-feedback`, `.invalid-feedback`
- **Input Groups**:
  ```html
  <div class="input-group">
    <span class="input-group-text">@</span>
    <input type="text" class="form-control" placeholder="Username">
    <button class="btn btn-outline-secondary">Check</button>
  </div>
  ```
- **Switches & Radios**: `.form-check .form-switch`

### D. Overlay & Structural Components
- **Modals**:
  - Default: `.modal .fade`
  - Vertically Centered: `.modal-dialog .modal-dialog-centered`
  - Scrollable: `.modal-dialog .modal-dialog-scrollable`
  - Sizes: `.modal-sm`, `.modal-lg`, `.modal-xl`, `.modal-fullscreen`
- **Offcanvas Drawers**:
  - Placements: `.offcanvas-start` (left), `.offcanvas-end` (right), `.offcanvas-top`, `.offcanvas-bottom`
- **Navigation**:
  - `.nav-tabs` (Classic tabbed interface)
  - `.nav-pills` (Button-like pills)
  - `.nav-underline` (Modern underlined links)
- **Accordion**: Collapse content panels with `.accordion-item`, `.accordion-header`, `.accordion-collapse`.

---

## 3. Vue 3 Variants & Architectural Patterns

Vue 3 offers flexible state handling and component composition models.

### A. Reactivity API Variants
| Technique | Best Used For | Example |
|---|---|---|
| `ref(val)` | Primitives (strings, numbers, booleans) or reassigned arrays | `const count = ref(0); count.value++` |
| `reactive(obj)` | Deep state objects / form payloads | `const form = reactive({ email: '', role: 'user' })` |
| `computed(() => ...)` | Pure derived state that auto-updates when dependencies change | `const activeItems = computed(() => items.value.filter(i => i.active))` |
| `watch(source, cb)` | Performing side effects (API call, saving to storage) on change | `watch(searchQuery, (newVal) => fetchResults(newVal))` |
| `watchEffect(cb)` | Immediate execution with automatic dependency tracking | `watchEffect(() => console.log('Current user:', user.role))` |

### B. Conditional & Dynamic DOM Rendering
- **`v-if` vs `v-show`**:
  - `v-if`: Completely unmounts/destroys elements from the DOM (ideal for authorization guards like admin controls).
  - `v-show`: Toggles CSS `display: none` without unmounting (ideal for frequently toggled modals or tabs).
- **`v-for` with Keys**:
  - Array iteration: `v-for="(item, index) in items" :key="item.id"`
  - Object iteration: `v-for="(value, key) in userProfile" :key="key"`

### C. Directives & Modifiers
- **Form Modifiers**:
  - `v-model.trim`: Strips leading/trailing whitespace automatically.
  - `v-model.number`: Casts string inputs to numbers.
  - `v-model.lazy`: Updates state only on `change` (blur) instead of every keystroke.
- **Event Modifiers**:
  - `@submit.prevent`: Prevents standard browser page reload.
  - `@click.stop`: Stops event propagation (bubble up).
  - `@keydown.enter`: Triggers action specifically on Enter key press.
  - `@click.once`: Fires event handler at most once.

### D. Component Architectures
- **Single-File Component (SFC)**: `<template>`, `<script setup>`, and `<style scoped>`.
- **Props & Emits**:
  - Parent to Child: `:item="record"` -> `defineProps(['item'])`
  - Child to Parent: `@delete="handleDelete"` -> `defineEmits(['delete'])`
- **Slots**:
  - Default Slot: `<slot />`
  - Named Slots: `<slot name="header" />`, `<template #header>`
  - Scoped Slots: Passing data back from child to parent slot template.
- **Dynamic Components**:
  - `<component :is="currentTabComponent" />` (switches components dynamically).
  - `<KeepAlive>`: Caches inactive component instances so state isn't lost during tab switching.

### E. Popular Vue 3 Component Ecosystems
- **PrimeVue**: Over 90+ production-ready UI components (DataTables with built-in filtering/pagination).
- **Vuetify 3**: Material Design component framework.
- **Element Plus**: Clean enterprise desktop UI library.
- **Pinia**: Official, lightweight state management replacement for Vuex.
