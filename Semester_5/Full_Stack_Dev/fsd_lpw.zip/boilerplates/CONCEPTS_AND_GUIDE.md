# Full Stack Development (FSD) — Concepts, Simplified Auth & Execution Guide

This document explains the simplified architecture, the 1-function 2-role static authorization model (no JWT, no encryption), full CRUD with query search, and instructions for running and testing.

---

## 1. Simplified Auth & Role Authorization Model

### Architecture (Zero Encryption, Zero JWT)
- **2 Static Roles**: `admin` and `user`.
- **Permission Matrix**:
  - `admin`: Has access to all 4 operations (**Create, Read, Update, Delete**).
  - `user`: Has access strictly to **Create and Read** (Update and Delete return `403 Forbidden`).
- **1 Unified Middleware Function**: [`backend/middleware/auth.js`](file:///R:/DeepWorks/DeepCollege/fsd/boilerplates/backend/middleware/auth.js)
  ```javascript
  const checkAuth = (action) => (req, res, next) => {
    const role = (req.headers['role'] || '').toLowerCase();

    // Admin has access to all 4 actions
    if (role === 'admin') return next();

    // User only has 'create' and 'read'
    if (role === 'user' && (action === 'create' || action === 'read')) return next();

    return res.status(403).json({
      error: 'Forbidden',
      message: `Role '${role || 'none'}' cannot perform '${action}'.`
    });
  };
  ```

### Sending Authentication on Requests
Simply supply the header:
```http
role: admin
```
or
```http
role: user
```

---

## 2. API Endpoints Reference

### Authentication
- `POST /api/auth/login`
  - Input: `{ "username": "admin", "password": "admin123" }` or `{ "username": "user", "password": "user123" }`
  - Output: Returns user object with role and hint to supply `role: <role>` header on subsequent requests.

---

### MongoDB (Mongoose) CRUD (`/api/mongo/items`)
| Method | Endpoint | Header Required | Allowed Roles | Description |
|---|---|---|---|---|
| `GET` | `/api/mongo/items` | `role: user` or `role: admin` | `user`, `admin` | Read all items |
| `GET` | `/api/mongo/items?search=keyword` | `role: user` or `role: admin` | `user`, `admin` | Global search across `title`, `description`, `category` |
| `GET` | `/api/mongo/items?title=xyz&category=Backend` | `role: user` or `role: admin` | `user`, `admin` | Multi-key search |
| `GET` | `/api/mongo/items/:id` | `role: user` or `role: admin` | `user`, `admin` | Read single item by ID |
| `POST` | `/api/mongo/items` | `role: user` or `role: admin` | `user`, `admin` | Create item (`{ title, description, category }`) |
| `PUT` | `/api/mongo/items/:id` | `role: admin` | `admin` ONLY | Update item |
| `DELETE` | `/api/mongo/items/:id` | `role: admin` | `admin` ONLY | Delete item |

---

### XAMPP MySQL CRUD (`/api/mysql/items`)
| Method | Endpoint | Header Required | Allowed Roles | Description |
|---|---|---|---|---|
| `GET` | `/api/mysql/items` | `role: user` or `role: admin` | `user`, `admin` | Read all records |
| `GET` | `/api/mysql/items?search=keyword` | `role: user` or `role: admin` | `user`, `admin` | Query search across `title` or `description` |
| `GET` | `/api/mysql/items?title=xyz` | `role: user` or `role: admin` | `user`, `admin` | Query search by specific key |
| `GET` | `/api/mysql/items/:id` | `role: user` or `role: admin` | `user`, `admin` | Read single record by ID |
| `POST` | `/api/mysql/items` | `role: user` or `role: admin` | `user`, `admin` | Insert record |
| `PUT` | `/api/mysql/items/:id` | `role: admin` | `admin` ONLY | Update record |
| `DELETE` | `/api/mysql/items/:id` | `role: admin` | `admin` ONLY | Delete record |

---

## 3. How to Run the Backend

```bash
cd boilerplates/backend
npm install
npm start
```
- Server starts on `http://localhost:5000`
- MongoDB connects to `mongodb://127.0.0.1:27017/fsd_boilerplate_db`
- MySQL connects to `localhost:3306` (XAMPP default: user `root`, no password) and creates table `items` automatically.

---

## 4. cURL Testing Guide

### 1. Test Login
```bash
# Admin Login
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d "{\"username\": \"admin\", \"password\": \"admin123\"}"

# User Login
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d "{\"username\": \"user\", \"password\": \"user123\"}"
```

---

### 2. Test Role Permissions with MongoDB
```bash
# 1. User Creates an Item (Allowed)
curl -X POST http://localhost:5000/api/mongo/items \
  -H "Content-Type: application/json" \
  -H "role: user" \
  -d "{\"title\":\"User Created Task\",\"category\":\"Frontend\",\"description\":\"Testing user permissions\"}"

# 2. User Reads & Searches Items (Allowed)
curl -X GET "http://localhost:5000/api/mongo/items?search=Task" \
  -H "role: user"

# 3. User Attempts to Delete an Item (Blocked -> 403 Forbidden)
curl -X DELETE http://localhost:5000/api/mongo/items/<ITEM_ID> \
  -H "role: user"

# 4. Admin Deletes the Item (Allowed -> 200 OK)
curl -X DELETE http://localhost:5000/api/mongo/items/<ITEM_ID> \
  -H "role: admin"
```

---

### 3. Test Role Permissions with XAMPP MySQL
```bash
# 1. User Inserts a Record (Allowed)
curl -X POST http://localhost:5000/api/mysql/items \
  -H "Content-Type: application/json" \
  -H "role: user" \
  -d "{\"title\":\"MySQL Database Entry\",\"description\":\"Created via User role\"}"

# 2. User Searches Records (Allowed)
curl -X GET "http://localhost:5000/api/mysql/items?title=MySQL" \
  -H "role: user"

# 3. User Attempts to Update Record (Blocked -> 403 Forbidden)
curl -X PUT http://localhost:5000/api/mysql/items/<ITEM_ID> \
  -H "Content-Type: application/json" \
  -H "role: user" \
  -d "{\"title\":\"Unauthorized Edit\"}"

# 4. Admin Updates Record (Allowed -> 200 OK)
curl -X PUT http://localhost:5000/api/mysql/items/<ITEM_ID> \
  -H "Content-Type: application/json" \
  -H "role: admin" \
  -d "{\"title\":\"Authorized Admin Update\"}"
```

---

## 5. Frontend Variants Reference
For all possible variants, pseudo-classes, theme utilities, and component states for Tailwind, Bootstrap, and Vue, see [`FRONTEND_VARIANTS.md`](./FRONTEND_VARIANTS.md).
