# FSD Generalized Boilerplates — Multi-Page & Full CRUD

A comprehensive, clean, and extensible full-stack boilerplate setup covering multi-page UI suites (Tailwind, Bootstrap 5, Vue 3) and Node.js REST APIs with MongoDB (Mongoose) and XAMPP MySQL (mysql2), multi-key search, and Authentication/Authorization (RBAC).

---

## Folder Structure

```
boilerplates/
├── README.md                 # Quick overview
├── CONCEPTS_AND_GUIDE.md     # Detailed concepts & execution manual
├── frontend/
│   ├── tailwind/
│   │   ├── signin.html       # Sign-in form with validation rings, error banners & alerts
│   │   ├── dashboard.html    # Metric cards, multi-key search toolbar, table, modal, toasts
│   │   └── 404.html          # Custom 404 error page
│   ├── bootstrap/
│   │   ├── signin.html       # Floating labels, client validation (.was-validated), alerts
│   │   ├── dashboard.html    # Offcanvas sidebar, tabs (table, card grid, accordion), modal, toasts
│   │   └── 404.html          # Centered 404 card
│   └── vue/
│       ├── signin.html       # Reactive login, form validation feedback, role selection
│       ├── dashboard.html    # Live role toggle (admin vs user), computed multi-key search, reactive modal
│       └── 404.html          # Error fallback page
└── backend/
    ├── .env.example          # Environment variables
    ├── package.json          # Express, Mongoose, mysql2, bcryptjs, jsonwebtoken, cors
    ├── server.js             # Express server setup
    ├── config/
    │   ├── db-mongo.js       # Mongoose connection
    │   └── db-mysql.js       # XAMPP MySQL pool + automatic database/table bootstrapping
    ├── middleware/
    │   └── auth.js           # Static auth, JWT verification & authorizeRoles (RBAC)
    ├── models/
    │   ├── mongo-user.js     # User schema (roles: 'user', 'admin')
    │   └── mongo-item.js     # Item schema with searchable fields
    └── routes/
        ├── auth-routes.js       # Static & JWT register/login + protected endpoints
        ├── mongo-crud-routes.js # MongoDB CRUD + multi-key search ($regex) + JWT + Admin Delete
        └── mysql-crud-routes.js # MySQL CRUD + multi-key search (LIKE) + JWT + Admin Delete
```

---

## Features & Implementation Overview

### 1. Multi-Page Frontends (No build step required)
Open any HTML file directly in any modern web browser:
- **Tailwind CSS**:
  - `signin.html`: Form validation, error state indicators, credential mock.
  - `dashboard.html`: Stat cards grid, multi-key search (keyword + category + status), dynamic responsive table, modal dialog, and floating toast notifications.
  - `404.html`: 404 error view.
- **Bootstrap 5**:
  - `signin.html`: Floating form labels, validation feedback, dismissible alerts.
  - `dashboard.html`: Offcanvas drawer sidebar, multi-view tabs (Table, Cards, FAQ Accordion), modal for Add/Edit, and native Bootstrap toasts.
  - `404.html`: Error layout.
- **Vue 3**:
  - `signin.html`: Reactive `v-model` form with real-time error messages and role choice.
  - `dashboard.html`: Live role toggle (switch between `admin` and `user` to test UI authorization restrictions live), computed multi-key filtering pipeline, reactive inline/modal state editing.
  - `404.html`: Vue error view.

### 2. Backend REST API
- **Authentication**:
  - **Static Auth**: Header `x-api-key: static-secret-token`.
  - **Database Auth**: Salted password hashing via `bcryptjs` and stateless JWT via `jsonwebtoken`.
- **Authorization (RBAC)**:
  - Role-based middleware (`authorizeRoles('admin')`) protecting deletion routes.
- **Multi-Key Search & Filtering**:
  - MongoDB: Global search across `title`, `description`, and `category` via `$or` & `$regex`, plus specific field matching (`/api/mongo/items?search=xyz&category=Backend`).
  - MySQL: Parameterized queries using `LIKE ?` and column-specific filters (`/api/mysql/items?search=xyz&title=abc`).

---

## Quick Start Backend

```bash
cd backend
npm install
npm start
```
Runs at `http://localhost:5000`.

For complete step-by-step instructions and cURL testing commands, see [`CONCEPTS_AND_GUIDE.md`](./CONCEPTS_AND_GUIDE.md).
