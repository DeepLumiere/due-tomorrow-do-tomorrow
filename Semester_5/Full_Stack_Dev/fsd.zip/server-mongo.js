/**
 * server-mongo.js
 * Standalone Generalized MongoDB API
 * 
 * Functions:
 * 1. Dynamically creates database and collections for ANY schema defined in schema.js
 * 2. Dynamically seeds initial data for all schemas
 * 3. Generalized Login endpoint (/api/login)
 * 4. Schema introspection endpoint (/api/schemas and /api/schemas/:entity)
 * 5. Generalized REST CRUD endpoints for ANY entity (/api/:entity):
 *    - POST   /api/:entity      -> Create with schema validation & defaults
 *    - GET    /api/:entity      -> Read all with dynamic query filtering & regex search
 *    - GET    /api/:entity/:id  -> Read single record by ID
 *    - PUT    /api/:entity/:id  -> Update record by ID
 *    - DELETE /api/:entity/:id  -> Delete record by ID (Admin authorized)
 */

const express = require('express');
const cors = require('cors');
const { MongoClient, ObjectId } = require('mongodb');
const path = require('path');
const { schemas, validateAndFormat } = require('./schema');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.static(__dirname)); // serve html files directly from root

const MONGO_URI = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017';
const DB_NAME = process.env.MONGODB_DATABASE || process.env.DB_NAME || 'library_db';

let db = null;

// Helper to build a MongoDB filter for an ID (supports both numeric id and MongoDB ObjectId)
function buildIdFilter(id) {
  const numId = Number(id);
  if (!isNaN(numId)) {
    return { id: numId };
  }
  if (ObjectId.isValid(id)) {
    return { _id: new ObjectId(id) };
  }
  return { id };
}

// Build Database and Collections dynamically from schema.js
async function setupDatabase() {
  try {
    const client = new MongoClient(MONGO_URI);
    await client.connect();
    db = client.db(DB_NAME);
    console.log(`[MongoDB] Database "${DB_NAME}" connected/created.`);

    // Auto-create collections and seed initial data for EVERY schema
    const existingCollections = await db.listCollections().toArray();
    const existingNames = existingCollections.map(c => c.name);

    for (const schema of Object.values(schemas)) {
      if (!existingNames.includes(schema.name)) {
        await db.createCollection(schema.name);
        console.log(`[MongoDB] Collection "${schema.name}" verified/created.`);
      }

      // Seed if collection is empty and seedData exists
      if (Array.isArray(schema.seedData) && schema.seedData.length > 0) {
        const count = await db.collection(schema.name).countDocuments();
        if (count === 0) {
          const docsToInsert = schema.seedData.map((item, index) => {
            const { data } = validateAndFormat(schema, item);
            return {
              id: index + 1,
              ...data,
              created_at: new Date()
            };
          });
          await db.collection(schema.name).insertMany(docsToInsert);
          console.log(`[MongoDB] Seeded initial data for collection "${schema.name}".`);
        }
      }
    }
  } catch (err) {
    console.error('[MongoDB Error] Could not connect to MongoDB:', err.message);
    console.log('-> Make sure MongoDB service is running on mongodb://127.0.0.1:27017.');
  }
}

// Middleware: Validate that the requested entity exists in schema.js
function resolveSchema(req, res, next) {
  const entityName = req.params.entity;
  const schema = schemas[entityName];
  if (!schema) {
    const available = Object.keys(schemas).join(', ');
    return res.status(404).json({
      success: false,
      error: 'Not Found',
      message: `Entity "${entityName}" does not exist in schema.js. Available entities: [${available}]`
    });
  }
  req.schema = schema;
  next();
}

// Middleware: Admin Authorization Check
function requireAdmin(req, res, next) {
  const role = req.headers['x-role'] || (req.headers['authorization'] === 'Bearer admin' ? 'admin' : '');
  if (role !== 'admin') {
    const entityName = req.params.entity || 'this';
    return res.status(403).json({
      success: false,
      error: 'Forbidden',
      message: `Access Denied: Only Admin can delete ${entityName} items! (Sign in as admin to delete)`
    });
  }
  next();
}

// ==========================================
// 1. SCHEMA INTROSPECTION APIS
// ==========================================
app.get('/api/schemas', (req, res) => {
  res.json({ success: true, schemas });
});

app.get('/api/schemas/:entity', resolveSchema, (req, res) => {
  res.json({ success: true, schema: req.schema });
});

// ==========================================
// 2. AUTHENTICATION (LOGIN) API
// ==========================================
app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ success: false, message: 'Username and password required.' });
  }

  try {
    const user = await db.collection('user').findOne({ username, password });
    if (!user) {
      return res.status(401).json({ success: false, message: 'Invalid username or password.' });
    }
    res.json({
      success: true,
      message: `Logged in successfully as ${user.role}!`,
      user: { username: user.username, role: user.role },
      token: user.role === 'admin' ? 'admin-token' : 'user-token'
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ==========================================
// 3. GENERALIZED REST CRUD APIS FOR ANY ENTITY
// ==========================================

// CREATE (POST /api/:entity)
app.post('/api/:entity', resolveSchema, async (req, res) => {
  const schema = req.schema;
  const { data, errors } = validateAndFormat(schema, req.body, false);

  if (errors.length > 0) {
    return res.status(400).json({
      success: false,
      message: errors.join(' '),
      errors
    });
  }

  try {
    // Generate sequential numeric id for user convenience
    const lastDoc = await db.collection(schema.name).find().sort({ id: -1 }).limit(1).toArray();
    const nextId = (lastDoc.length > 0 && typeof lastDoc[0].id === 'number') ? lastDoc[0].id + 1 : 1;

    const newDoc = {
      id: nextId,
      ...data,
      created_at: new Date()
    };

    const result = await db.collection(schema.name).insertOne(newDoc);
    res.status(201).json({
      success: true,
      message: `${schema.name.charAt(0).toUpperCase() + schema.name.slice(1)} record created successfully!`,
      data: { ...newDoc, _id: result.insertedId }
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// READ ALL with Filtering & Search (GET /api/:entity)
app.get('/api/:entity', resolveSchema, async (req, res) => {
  const schema = req.schema;
  try {
    const filter = {};

    // 1. Dynamic filtering by schema fields from query params (e.g. ?category=Programming)
    for (const [key, val] of Object.entries(req.query)) {
      if (schema.fields[key] && val !== undefined && val !== '') {
        const fieldDef = schema.fields[key];
        if (fieldDef.type === 'number') {
          filter[key] = Number(val);
        } else if (fieldDef.type === 'boolean') {
          filter[key] = val === 'true' || val === true || val === 1 || val === '1';
        } else {
          filter[key] = val;
        }
      }
    }

    // 2. Optional text search across string fields (e.g. ?search=keyword or ?q=keyword)
    const searchQuery = req.query.search || req.query.q;
    if (searchQuery) {
      const stringCols = Object.entries(schema.fields)
        .filter(([, def]) => def.type === 'string' || def.type === 'text')
        .map(([col]) => ({ [col]: { $regex: searchQuery, $options: 'i' } }));
      if (stringCols.length > 0) {
        filter.$or = stringCols;
      }
    }

    const items = await db.collection(schema.name).find(filter).sort({ id: -1 }).toArray();
    res.json({ success: true, count: items.length, data: items });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// READ ONE (GET /api/:entity/:id)
app.get('/api/:entity/:id', resolveSchema, async (req, res) => {
  const schema = req.schema;
  const { id } = req.params;

  try {
    const filter = buildIdFilter(id);
    const item = await db.collection(schema.name).findOne(filter);
    if (!item) {
      return res.status(404).json({ success: false, message: `${schema.name} record #${id} not found.` });
    }
    res.json({ success: true, data: item });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// UPDATE (PUT or PATCH /api/:entity/:id)
const handleUpdate = async (req, res) => {
  const schema = req.schema;
  const { id } = req.params;
  const { data, errors } = validateAndFormat(schema, req.body, true);

  if (errors.length > 0) {
    return res.status(400).json({ success: false, message: errors.join(' '), errors });
  }

  if (Object.keys(data).length === 0) {
    return res.status(400).json({ success: false, message: 'No valid fields provided to update.' });
  }

  try {
    const filter = buildIdFilter(id);
    const result = await db.collection(schema.name).updateOne(filter, { $set: data });
    if (result.matchedCount === 0) {
      return res.status(404).json({ success: false, message: `${schema.name} record #${id} not found.` });
    }
    res.json({
      success: true,
      message: `${schema.name.charAt(0).toUpperCase() + schema.name.slice(1)} #${id} updated successfully.`,
      data: { id, ...data }
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
};

app.put('/api/:entity/:id', resolveSchema, handleUpdate);
app.patch('/api/:entity/:id', resolveSchema, handleUpdate);

// DELETE (DELETE /api/:entity/:id - Admin Authorized)
app.delete('/api/:entity/:id', resolveSchema, requireAdmin, async (req, res) => {
  const schema = req.schema;
  const { id } = req.params;

  try {
    const filter = buildIdFilter(id);
    const result = await db.collection(schema.name).deleteOne(filter);
    if (result.deletedCount === 0) {
      return res.status(404).json({ success: false, message: `${schema.name} record #${id} not found.` });
    }
    res.json({
      success: true,
      message: `${schema.name.charAt(0).toUpperCase() + schema.name.slice(1)} #${id} deleted successfully.`
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Start Server
setupDatabase().then(() => {
  app.listen(PORT, () => {
    console.log(`[MongoDB API] Running at http://localhost:${PORT}`);
  });
});
