/**
 * server-mysql.js
 * Standalone Generalized MySQL API
 * 
 * Functions:
 * 1. Dynamically creates database and tables for ANY schema defined in schema.js
 * 2. Dynamically seeds initial data for all schemas
 * 3. Generalized Login endpoint (/api/login)
 * 4. Schema introspection endpoint (/api/schemas and /api/schemas/:entity)
 * 5. Generalized REST CRUD endpoints for ANY entity (/api/:entity):
 *    - POST   /api/:entity      -> Create with schema validation & defaults
 *    - GET    /api/:entity      -> Read all with dynamic query filtering & search
 *    - GET    /api/:entity/:id  -> Read single record by ID
 *    - PUT    /api/:entity/:id  -> Update record by ID
 *    - DELETE /api/:entity/:id  -> Delete record by ID (Admin authorized)
 */

const express = require('express');
const cors = require('cors');
const mysql = require('mysql2/promise');
const path = require('path');
const { schemas, generateMySqlTableSql, validateAndFormat } = require('./schema');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.static(__dirname)); // serve html files directly from root

const DB_CONFIG = {
  host: process.env.MYSQL_HOST || 'localhost',
  user: process.env.MYSQL_USER || 'root',
  password: process.env.MYSQL_PASSWORD || '',
  database: process.env.MYSQL_DATABASE || process.env.DB_NAME || 'library_db',
  port: Number(process.env.MYSQL_PORT || 3306)
};

let pool = null;

// Build Database and Tables dynamically for all schemas in schema.js
async function setupDatabase() {
  try {
    // 1. Connect without database to ensure database exists
    const rootConn = await mysql.createConnection({
      host: DB_CONFIG.host,
      user: DB_CONFIG.user,
      password: DB_CONFIG.password,
      port: DB_CONFIG.port
    });
    await rootConn.query(`CREATE DATABASE IF NOT EXISTS \`${DB_CONFIG.database}\`;`);
    await rootConn.end();
    console.log(`[MySQL] Database "${DB_CONFIG.database}" verified/created.`);

    // 2. Connect to the database pool
    pool = mysql.createPool(DB_CONFIG);

    // 3. Dynamically create tables and seed initial data for EVERY schema
    for (const schema of Object.values(schemas)) {
      const sql = generateMySqlTableSql(schema);
      await pool.query(sql);
      console.log(`[MySQL] Table "${schema.name}" verified/created.`);

      // Seed if table is empty and seedData exists
      if (Array.isArray(schema.seedData) && schema.seedData.length > 0) {
        const [rows] = await pool.query(`SELECT COUNT(*) AS count FROM \`${schema.name}\``);
        if (rows[0].count === 0) {
          for (const item of schema.seedData) {
            const { data } = validateAndFormat(schema, item);
            const cols = Object.keys(data);
            const vals = Object.values(data);
            const placeholders = cols.map(() => '?').join(', ');
            const colNames = cols.map(c => `\`${c}\``).join(', ');
            await pool.query(
              `INSERT INTO \`${schema.name}\` (${colNames}) VALUES (${placeholders})`,
              vals
            );
          }
          console.log(`[MySQL] Seeded initial data for table "${schema.name}".`);
        }
      }
    }
  } catch (err) {
    console.error('[MySQL Error] Could not connect to MySQL:', err.message);
    console.log('-> Make sure MySQL service is running and credentials match DB_CONFIG.');
  }
}

// Middleware: Validate that the requested entity exists in schema.js
function resolveSchema(req, res, next) {
  const entityName = req.params.entity;
  const schema = schemas[entityName];
  if (!schema) {
    const available = Object.keys(schemas).join(', ');
    return res.status(404).json({
      success: false,
      error: 'Not Found',
      message: `Entity "${entityName}" does not exist in schema.js. Available entities: [${available}]`
    });
  }
  req.schema = schema;
  next();
}

// Middleware: Admin Authorization Check
function requireAdmin(req, res, next) {
  const role = req.headers['x-role'] || (req.headers['authorization'] === 'Bearer admin' ? 'admin' : '');
  if (role !== 'admin') {
    const entityName = req.params.entity || 'this';
    return res.status(403).json({
      success: false,
      error: 'Forbidden',
      message: `Access Denied: Only Admin can delete ${entityName} items! (Sign in as admin to delete)`
    });
  }
  next();
}

// ==========================================
// 1. SCHEMA INTROSPECTION APIS
// ==========================================
app.get('/api/schemas', (req, res) => {
  res.json({ success: true, schemas });
});

app.get('/api/schemas/:entity', resolveSchema, (req, res) => {
  res.json({ success: true, schema: req.schema });
});

// ==========================================
// 2. AUTHENTICATION (LOGIN) API
// ==========================================
app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ success: false, message: 'Username and password required.' });
  }

  try {
    const [rows] = await pool.query(
      'SELECT id, username, role FROM `user` WHERE username = ? AND password = ?',
      [username, password]
    );
    if (rows.length === 0) {
      return res.status(401).json({ success: false, message: 'Invalid username or password.' });
    }
    const user = rows[0];
    res.json({
      success: true,
      message: `Logged in successfully as ${user.role}!`,
      user: { username: user.username, role: user.role },
      token: user.role === 'admin' ? 'admin-token' : 'user-token'
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ==========================================
// 3. GENERALIZED REST CRUD APIS FOR ANY ENTITY
// ==========================================

// CREATE (POST /api/:entity)
app.post('/api/:entity', resolveSchema, async (req, res) => {
  const schema = req.schema;
  const { data, errors } = validateAndFormat(schema, req.body, false);

  if (errors.length > 0) {
    return res.status(400).json({
      success: false,
      message: errors.join(' '),
      errors
    });
  }

  const cols = Object.keys(data);
  if (cols.length === 0) {
    return res.status(400).json({ success: false, message: 'No valid schema fields provided.' });
  }

  const vals = Object.values(data);
  const colNames = cols.map(c => `\`${c}\``).join(', ');
  const placeholders = cols.map(() => '?').join(', ');

  try {
    const [result] = await pool.query(
      `INSERT INTO \`${schema.name}\` (${colNames}) VALUES (${placeholders})`,
      vals
    );
    res.status(201).json({
      success: true,
      message: `${schema.name.charAt(0).toUpperCase() + schema.name.slice(1)} record created successfully!`,
      data: { id: result.insertId, ...data }
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// READ ALL with Filtering & Search (GET /api/:entity)
app.get('/api/:entity', resolveSchema, async (req, res) => {
  const schema = req.schema;
  try {
    let sql = `SELECT * FROM \`${schema.name}\``;
    const whereClauses = [];
    const params = [];

    // 1. Dynamic filtering by any schema field present in query params (e.g. ?category=CS)
    for (const [key, val] of Object.entries(req.query)) {
      if (schema.fields[key] && val !== undefined && val !== '') {
        whereClauses.push(`\`${key}\` = ?`);
        params.push(val);
      }
    }

    // 2. Optional text search across string fields (e.g. ?search=keyword or ?q=keyword)
    const searchQuery = req.query.search || req.query.q;
    if (searchQuery) {
      const stringCols = Object.entries(schema.fields)
        .filter(([, def]) => def.type === 'string' || def.type === 'text')
        .map(([col]) => `\`${col}\` LIKE ?`);
      if (stringCols.length > 0) {
        whereClauses.push(`(${stringCols.join(' OR ')})`);
        stringCols.forEach(() => params.push(`%${searchQuery}%`));
      }
    }

    if (whereClauses.length > 0) {
      sql += ` WHERE ${whereClauses.join(' AND ')}`;
    }

    sql += ' ORDER BY id DESC';

    const [rows] = await pool.query(sql, params);
    res.json({ success: true, count: rows.length, data: rows });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// READ ONE (GET /api/:entity/:id)
app.get('/api/:entity/:id', resolveSchema, async (req, res) => {
  const schema = req.schema;
  const { id } = req.params;

  try {
    const [rows] = await pool.query(`SELECT * FROM \`${schema.name}\` WHERE id = ?`, [id]);
    if (rows.length === 0) {
      return res.status(404).json({ success: false, message: `${schema.name} record #${id} not found.` });
    }
    res.json({ success: true, data: rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// UPDATE (PUT or PATCH /api/:entity/:id)
const handleUpdate = async (req, res) => {
  const schema = req.schema;
  const { id } = req.params;
  const { data, errors } = validateAndFormat(schema, req.body, true);

  if (errors.length > 0) {
    return res.status(400).json({ success: false, message: errors.join(' '), errors });
  }

  const cols = Object.keys(data);
  if (cols.length === 0) {
    return res.status(400).json({ success: false, message: 'No valid fields provided to update.' });
  }

  const setClause = cols.map(c => `\`${c}\` = ?`).join(', ');
  const vals = [...Object.values(data), id];

  try {
    const [result] = await pool.query(
      `UPDATE \`${schema.name}\` SET ${setClause} WHERE id = ?`,
      vals
    );
    if (result.affectedRows === 0) {
      return res.status(404).json({ success: false, message: `${schema.name} record #${id} not found.` });
    }
    res.json({
      success: true,
      message: `${schema.name.charAt(0).toUpperCase() + schema.name.slice(1)} #${id} updated successfully.`,
      data: { id: Number(id), ...data }
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
};

app.put('/api/:entity/:id', resolveSchema, handleUpdate);
app.patch('/api/:entity/:id', resolveSchema, handleUpdate);

// DELETE (DELETE /api/:entity/:id - Admin Authorized)
app.delete('/api/:entity/:id', resolveSchema, requireAdmin, async (req, res) => {
  const schema = req.schema;
  const { id } = req.params;

  try {
    const [result] = await pool.query(`DELETE FROM \`${schema.name}\` WHERE id = ?`, [id]);
    if (result.affectedRows === 0) {
      return res.status(404).json({ success: false, message: `${schema.name} record #${id} not found.` });
    }
    res.json({
      success: true,
      message: `${schema.name.charAt(0).toUpperCase() + schema.name.slice(1)} #${id} deleted successfully.`
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Start Server
setupDatabase().then(() => {
  app.listen(PORT, () => {
    console.log(`[MySQL API] Running at http://localhost:${PORT}`);
  });
});
