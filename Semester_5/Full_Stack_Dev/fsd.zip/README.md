# Standalone Fullstack Boilerplate (Generalized MySQL & MongoDB)

A minimal, student-level fullstack boilerplate containing:
- **Generalized common schema** for MySQL and MongoDB (`schema.js`).
- **Auto-creation** of databases and tables/collections for **any** entity defined in `schema.js`.
- **Dynamic Seeding**: automatically seeds initial data if tables/collections are empty.
- **Generalized REST CRUD APIs (`/api/:entity`)**:
  - `POST   /api/:entity` - Create record with automatic schema validation and type casting
  - `GET    /api/:entity` - Read records with dynamic filtering by query parameters and text search
  - `GET    /api/:entity/:id` - Read a single record
  - `PUT    /api/:entity/:id` - Update record
  - `DELETE /api/:entity/:id` - Delete record (protected by Admin authorization)
  - `GET    /api/schemas` - Inspect registered entities and field definitions
- **Role-based Authentication**: User login with token & role verification.
- **3 single-page frontends** (Tailwind, Bootstrap, Tailwind + Vue.js) with Sign In and Data Input on the same page.

---

## Files

- [schema.js](file:///R:/DeepWorks/DeepCollege/fsd/boilerplates/proj/standalone/schema.js): Common schema definition and validation engine.
- [server-mysql.js](file:///R:/DeepWorks/DeepCollege/fsd/boilerplates/proj/standalone/server-mysql.js): Standalone generalized MySQL API server.
- [server-mongo.js](file:///R:/DeepWorks/DeepCollege/fsd/boilerplates/proj/standalone/server-mongo.js): Standalone generalized MongoDB API server.
- [index-tailwind.html](file:///R:/DeepWorks/DeepCollege/fsd/boilerplates/proj/standalone/index-tailwind.html): Single-page frontend using Tailwind CSS.
- [index-bootstrap.html](file:///R:/DeepWorks/DeepCollege/fsd/boilerplates/proj/standalone/index-bootstrap.html): Single-page frontend using Bootstrap 5.
- [index-vue-tailwind.html](file:///R:/DeepWorks/DeepCollege/fsd/boilerplates/proj/standalone/index-vue-tailwind.html): Single-page frontend using Tailwind CSS + Vue.js.

---

## How to Customize or Add New Entities

Open [schema.js](file:///R:/DeepWorks/DeepCollege/fsd/boilerplates/proj/standalone/schema.js) and simply add your new entity to the `schemas` object:

```javascript
student: {
  name: 'student',
  fields: {
    name: { type: 'string', required: true },
    roll_no: { type: 'string', required: true },
    department: { type: 'string', default: 'Computer Science' },
    cgpa: { type: 'number', default: 0 }
  },
  seedData: [
    { name: 'John Doe', roll_no: 'CS101', department: 'Computer Science', cgpa: 3.8 }
  ]
}
```

Both MySQL and MongoDB servers will **instantly**:
1. Create the `student` table or collection on next startup.
2. Seed the initial data.
3. Provide `/api/student` endpoints (POST, GET, PUT, DELETE) with full schema validation and query filtering!

---

## How to Run

1. **Install dependencies**:
   ```bash
   npm install
   ```

2. **Start the MySQL server**:
   ```bash
   npm run start:mysql
   # or: node server-mysql.js
   ```

3. **OR Start the MongoDB server**:
   ```bash
   npm run start:mongo
   # or: node server-mongo.js
   ```

4. **Open in browser**:
   - `http://localhost:3000/index-tailwind.html`
   - `http://localhost:3000/index-bootstrap.html`
   - `http://localhost:3000/index-vue-tailwind.html`

---

## Demo Logins
- **Admin**: `admin` / `admin123` (Allowed to Delete)
- **User**: `student` / `user123` (Read & Create only, Cannot Delete)
