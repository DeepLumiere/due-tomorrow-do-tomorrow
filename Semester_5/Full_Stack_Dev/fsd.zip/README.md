# Standalone Fullstack Boilerplate (Generalized MySQL & MongoDB)

A minimal, student-level fullstack boilerplate featuring:
- **Unified Schema System ([schema.js](file:///R:/DeepWorks/DeepCollege/fsd/proj/schema.js))**: Define or edit any data model once; both MySQL and MongoDB adapt automatically.
- **Live Auto-Migration & Hot-Reloading**:
  - Automatically adds new columns to MySQL (`ALTER TABLE ADD COLUMN`) without data loss.
  - Automatically backfills default values for new fields in MongoDB.
  - Built-in file watcher detects `schema.js` changes instantly—**no server restart needed**.
- **Generalized Dynamic REST APIs (`/api/:entity`)**:
  - `POST   /api/:entity` — Create records with auto schema validation and type-casting.
  - `GET    /api/:entity` — Read records with dynamic field filtering (`?field=value`) and text search (`?q=term`).
  - `GET    /api/:entity/:id` — Read a single record by numeric ID or Mongo ObjectId.
  - `PUT    /api/:entity/:id` / `PATCH` — Update existing records.
  - `DELETE /api/:entity/:id` — Delete records (protected by Admin authorization).
  - `GET    /api/schemas` — Introspect registered schemas and fields.
  - `GET    /api/sync` — Force an immediate database migration & synchronization.
- **Role-Based Authentication**:
  - `POST /api/login` with token & role verification (`admin` vs `user`).
- **3 Single-Page Frontends** with Dual Mode (`file:///` and `http://localhost:3000`):
  - Tailwind CSS (Vanilla JS)
  - Bootstrap 5 (Vanilla JS)
  - Tailwind CSS + Vue.js 3

---

## Project Structure

```
├── schema.js              # Common schema definitions, validation, and SQL generation
├── server-mysql.js        # Generalized MySQL API with live sync & auto-migration
├── server-mongo.js        # Generalized MongoDB API with live sync & auto-migration
├── index-tailwind.html    # Tailwind CSS single-page frontend
├── index-bootstrap.html   # Bootstrap 5 single-page frontend
├── index-vue-tailwind.html# Tailwind CSS + Vue.js single-page frontend
└── package.json           # Scripts and dependencies
```

---

## Current Pre-configured Schemas

In [schema.js](file:///R:/DeepWorks/DeepCollege/fsd/proj/schema.js):
1. **`user`**: User authentication and roles (`admin` or `user`).
2. **`library`**: Sample library books entity (`title`, `author`, `category`, `copies`).
3. **`pharmacy`**: Sample pharmacy entity (`name`, `dtype`, `category`, `count`).

---

## How to Add or Edit Any Entity

Open [schema.js](file:///R:/DeepWorks/DeepCollege/fsd/proj/schema.js) and add or modify entities inside `schemas`:

```javascript
const schemas = {
  user: { ... },
  library: { ... },
  
  // Example: Adding a custom 'student' entity
  student: {
    name: 'student',
    fields: {
      name: { type: 'string', required: true },
      roll_no: { type: 'string', required: true },
      department: { type: 'string', default: 'Computer Science' },
      cgpa: { type: 'number', default: 0 }
    },
    seedData: [
      { name: 'John Doe', roll_no: 'CS101', department: 'Computer Science', cgpa: 3.8 }
    ]
  }
};
```

> [!TIP]
> **JavaScript Syntax Reminder**: Always make sure every entity inside `schemas` is separated by a comma (`,`) to avoid `SyntaxError: Unexpected identifier`.

### Supported Field Types
- `'string'` — Maps to `VARCHAR(255)` in MySQL, string in Mongo.
- `'number'` — Maps to `INT` in MySQL, number in Mongo.
- `'boolean'` — Maps to `TINYINT(1)` in MySQL, boolean in Mongo.
- `'date'` — Maps to `DATETIME` in MySQL, Date object in Mongo.
- `'text'` — Maps to `TEXT` in MySQL, string in Mongo.

---

## Live Auto-Migration & Sync

When you edit [schema.js](file:///R:/DeepWorks/DeepCollege/fsd/proj/schema.js):
1. **Adding a new entity**: Automatically creates the table/collection, seeds initial data, and registers all `/api/<entity>` endpoints.
2. **Adding a new field to an existing entity**: Automatically executes `ALTER TABLE <table> ADD COLUMN <field>` in MySQL, and backfills default values in MongoDB.
3. **Manual Trigger**: Visit `http://localhost:3000/api/sync` at any time to verify or force a full sync.

---

## How to Run

### 1. Install Dependencies
```bash
npm install
```

### 2. Start MySQL Server
```bash
npm run start:mysql
# or: node server-mysql.js
```
*Note: Make sure your MySQL service (e.g., XAMPP, WAMP, or standalone MySQL) is running.*

### 3. OR Start MongoDB Server
```bash
npm run start:mongo
# or: node server-mongo.js
```
*Note: Make sure MongoDB service is running on `mongodb://127.0.0.1:27017`.*

---

## Accessing the Frontends

You can open the frontends in **two ways**:

1. **Directly via Browser / Local File (`file:///`)**:
   - Double-click `index-tailwind.html`, `index-bootstrap.html`, or `index-vue-tailwind.html`.
   - The frontends automatically detect `file://` protocol and route API calls to `http://localhost:3000`.

2. **Via Localhost Web Server**:
   - `http://localhost:3000/index-tailwind.html`
   - `http://localhost:3000/index-bootstrap.html`
   - `http://localhost:3000/index-vue-tailwind.html`

---

## Demo Credentials

| Role | Username | Password | Permissions |
| :--- | :--- | :--- | :--- |
| **Admin** | `admin` | `admin123` | Full access (Read, Create, **Delete**) |
| **User** | `student` | `user123` | Standard access (Read, Create, **Delete Blocked**) |

---

## REST API Reference

| Method | Endpoint | Description | Auth Required |
| :--- | :--- | :--- | :--- |
| `POST` | `/api/login` | User login (returns role & token) | No |
| `GET` | `/api/schemas` | List all schemas & field definitions | No |
| `GET` | `/api/sync` | Trigger database migration & sync | No |
| `GET` | `/api/:entity` | Read all items (supports `?field=val` & `?q=text`) | No |
| `GET` | `/api/:entity/:id` | Read single item by ID | No |
| `POST` | `/api/:entity` | Create new item with validation | No |
| `PUT` | `/api/:entity/:id` | Update item by ID | No |
| `DELETE` | `/api/:entity/:id` | Delete item by ID | **Admin Only** (`x-role: admin`) |
