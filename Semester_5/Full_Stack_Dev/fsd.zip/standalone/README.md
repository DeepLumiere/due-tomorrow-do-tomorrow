# Standalone Library System

A minimal, student-level fullstack boilerplate containing:
- Common schema for MySQL and MongoDB
- Auto-creation of database and tables/collections
- Login, Create, Read, and Delete with Admin authorization
- 3 single-page frontends (Tailwind, Bootstrap, Tailwind + Vue.js) with Sign In and Data Input on the same page

## Files
- `schema.js`: Common schema definition for `user` and `library`.
- `server-mysql.js`: Standalone MySQL API server.
- `server-mongo.js`: Standalone MongoDB API server.
- `index-tailwind.html`: Single-page frontend using Tailwind CSS.
- `index-bootstrap.html`: Single-page frontend using Bootstrap 5.
- `index-vue-tailwind.html`: Single-page frontend using Tailwind CSS + Vue.js.

## How to Run

1. Install dependencies (if running inside this folder independently):
   ```bash
   npm install
   ```

2. Start the MySQL server:
   ```bash
   npm run start:mysql
   # or: node server-mysql.js
   ```

3. OR Start the MongoDB server:
   ```bash
   npm run start:mongo
   # or: node server-mongo.js
   ```

4. Open in browser:
   - `http://localhost:3000/index-tailwind.html`
   - `http://localhost:3000/index-bootstrap.html`
   - `http://localhost:3000/index-vue-tailwind.html`

## Demo Logins
- **Admin**: `admin` / `admin123` (Allowed to Delete)
- **User**: `student` / `user123` (Cannot Delete)
