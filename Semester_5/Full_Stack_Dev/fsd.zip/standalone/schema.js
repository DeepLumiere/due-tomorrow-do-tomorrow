/**
 * schema.js - Common Schema Definition for MySQL and MongoDB
 * 
 * To modify data structure:
 * Simply add/remove fields or entities here.
 * The servers will automatically create the database and tables/collections!
 */

const schemas = {
  // 1. User Schema (for login & admin authorization)
  user: {
    name: 'user',
    fields: {
      username: { type: 'string', required: true },
      password: { type: 'string', required: true },
      role: { type: 'string', default: 'user' } // 'admin' or 'user'
    }
  },

  // 2. Library Schema (the main data entity: can be customized anytime)
  library: {
    name: 'library',
    fields: {
      title: { type: 'string', required: true },
      author: { type: 'string', required: true },
      category: { type: 'string', default: 'General' },
      copies: { type: 'number', default: 1 }
    }
  }
};

/**
 * Helper to map schema types to MySQL data types
 */
function getMySqlType(fieldDef) {
  if (fieldDef.type === 'number') return 'INT DEFAULT 0';
  if (fieldDef.type === 'boolean') return 'TINYINT(1) DEFAULT 0';
  return 'VARCHAR(255) DEFAULT \'\'';
}

/**
 * Builds MySQL CREATE TABLE SQL query dynamically from any schema
 */
function generateMySqlTableSql(schema) {
  const columns = ['id INT AUTO_INCREMENT PRIMARY KEY'];
  
  for (const [fieldName, fieldDef] of Object.entries(schema.fields)) {
    const sqlType = getMySqlType(fieldDef);
    const notNull = fieldDef.required ? 'NOT NULL' : '';
    columns.push(`\`${fieldName}\` ${sqlType} ${notNull}`.trim());
  }

  columns.push('`created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP');
  return `CREATE TABLE IF NOT EXISTS \`${schema.name}\` (${columns.join(', ')}) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;`;
}

module.exports = {
  schemas,
  generateMySqlTableSql
};
