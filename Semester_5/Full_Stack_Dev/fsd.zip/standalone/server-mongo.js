/**
 * server-mongo.js
 * Standalone MongoDB API (Student Level)
 * 
 * Functions:
 * 1. Auto-creates database and collections from schema.js if not available
 * 2. Login endpoint (/api/login)
 * 3. Create library record (/api/library - POST)
 * 4. Read library records (/api/library - GET)
 * 5. Delete library record (/api/library/:id - DELETE) with ADMIN authorization
 */

const express = require('express');
const cors = require('cors');
const { MongoClient, ObjectId } = require('mongodb');
const path = require('path');
const { schemas } = require('./schema');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.static(__dirname)); // also serve root for direct html access

const MONGO_URI = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017';
const DB_NAME = 'library_db';

let db = null;

// Build Database and Collections dynamically from schema.js
async function setupDatabase() {
  try {
    const client = new MongoClient(MONGO_URI);
    await client.connect();
    db = client.db(DB_NAME);
    console.log(`[MongoDB] Database "${DB_NAME}" connected/created.`);

    // Auto-create collections for every schema in schema.js
    const existingCollections = await db.listCollections().toArray();
    const existingNames = existingCollections.map(c => c.name);

    for (const schema of Object.values(schemas)) {
      if (!existingNames.includes(schema.name)) {
        await db.createCollection(schema.name);
        console.log(`[MongoDB] Collection "${schema.name}" created.`);
      }
    }

    // Seed default admin & user if empty
    const userCount = await db.collection('user').countDocuments();
    if (userCount === 0) {
      await db.collection('user').insertMany([
        { username: 'admin', password: 'admin123', role: 'admin' },
        { username: 'student', password: 'user123', role: 'user' }
      ]);
      console.log('[MongoDB] Seeded users: admin (admin/admin123), student (student/user123)');
    }

    // Seed sample books if empty
    const bookCount = await db.collection('library').countDocuments();
    if (bookCount === 0) {
      await db.collection('library').insertMany([
        { id: 1, title: 'Clean Code', author: 'Robert C. Martin', category: 'Programming', copies: 5, created_at: new Date() },
        { id: 2, title: 'Introduction to Algorithms', author: 'CLRS', category: 'Computer Science', copies: 3, created_at: new Date() }
      ]);
      console.log('[MongoDB] Seeded sample library books.');
    }
  } catch (err) {
    console.error('[MongoDB Error] Could not connect to MongoDB:', err.message);
    console.log('-> Make sure MongoDB service is running on mongodb://127.0.0.1:27017.');
  }
}

// Middleware: Admin Authorization to Delete
function requireAdmin(req, res, next) {
  const role = req.headers['x-role'] || (req.headers['authorization'] === 'Bearer admin' ? 'admin' : '');
  if (role !== 'admin') {
    return res.status(403).json({
      success: false,
      error: 'Forbidden',
      message: 'Access Denied: Only Admin can delete library items!'
    });
  }
  next();
}

// 1. LOGIN API
app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ success: false, message: 'Username and password required.' });
  }

  try {
    const user = await db.collection('user').findOne({ username, password });
    if (!user) {
      return res.status(401).json({ success: false, message: 'Invalid username or password.' });
    }
    res.json({
      success: true,
      message: `Logged in successfully as ${user.role}!`,
      user: { username: user.username, role: user.role },
      token: user.role === 'admin' ? 'admin-token' : 'user-token'
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 2. CREATE API (Add to Library)
app.post('/api/library', async (req, res) => {
  const { title, author, category = 'General', copies = 1 } = req.body;
  if (!title || !author) {
    return res.status(400).json({ success: false, message: 'Title and Author are required.' });
  }

  try {
    // Generate simple auto-increment id
    const count = await db.collection('library').countDocuments();
    const newDoc = {
      id: count + 1,
      title,
      author,
      category,
      copies: Number(copies),
      created_at: new Date()
    };
    const result = await db.collection('library').insertOne(newDoc);
    res.status(201).json({
      success: true,
      message: 'Book added to library successfully!',
      data: { id: newDoc.id, _id: result.insertedId, title, author, category, copies: Number(copies) }
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 3. READ API (Get all or search)
app.get('/api/library', async (req, res) => {
  try {
    const { category } = req.query;
    const filter = {};
    if (category) filter.category = category;

    const items = await db.collection('library').find(filter).sort({ id: -1 }).toArray();
    res.json({ success: true, count: items.length, data: items });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 4. DELETE API (Requires Admin Authorization)
app.delete('/api/library/:id', requireAdmin, async (req, res) => {
  const { id } = req.params;
  try {
    const numId = Number(id);
    const filter = !isNaN(numId) ? { id: numId } : (ObjectId.isValid(id) ? { _id: new ObjectId(id) } : { id });

    const result = await db.collection('library').deleteOne(filter);
    if (result.deletedCount === 0) {
      return res.status(404).json({ success: false, message: 'Book not found.' });
    }
    res.json({ success: true, message: `Book #${id} deleted successfully.` });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Start Server
setupDatabase().then(() => {
  app.listen(PORT, () => {
    console.log(`[MongoDB API] Running at http://localhost:${PORT}`);
  });
});
