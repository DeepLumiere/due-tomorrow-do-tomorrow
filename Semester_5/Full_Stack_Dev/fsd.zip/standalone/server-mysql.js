/**
 * server-mysql.js
 * Standalone MySQL API (Student Level)
 * 
 * Functions:
 * 1. Auto-creates database and tables from schema.js if not available
 * 2. Login endpoint (/api/login)
 * 3. Create library record (/api/library - POST)
 * 4. Read library records (/api/library - GET)
 * 5. Delete library record (/api/library/:id - DELETE) with ADMIN authorization
 */

const express = require('express');
const cors = require('cors');
const mysql = require('mysql2/promise');
const path = require('path');
const { schemas, generateMySqlTableSql } = require('./schema');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.static(__dirname)); // also serve root for direct html access

const DB_CONFIG = {
  host: process.env.MYSQL_HOST || 'localhost',
  user: process.env.MYSQL_USER || 'root',
  password: process.env.MYSQL_PASSWORD || '',
  database: 'library_db',
  port: Number(process.env.MYSQL_PORT || 3306)
};

let pool = null;

// Build Database and Tables dynamically if not available
async function setupDatabase() {
  try {
    // 1. Connect without database to ensure database exists
    const rootConn = await mysql.createConnection({
      host: DB_CONFIG.host,
      user: DB_CONFIG.user,
      password: DB_CONFIG.password,
      port: DB_CONFIG.port
    });
    await rootConn.query(`CREATE DATABASE IF NOT EXISTS \`${DB_CONFIG.database}\`;`);
    await rootConn.end();
    console.log(`[MySQL] Database "${DB_CONFIG.database}" verified/created.`);

    // 2. Connect to the database pool
    pool = mysql.createPool(DB_CONFIG);

    // 3. Auto-create tables for every schema in schema.js
    for (const schema of Object.values(schemas)) {
      const sql = generateMySqlTableSql(schema);
      await pool.query(sql);
      console.log(`[MySQL] Table "${schema.name}" verified/created.`);
    }

    // 4. Seed default admin & user if empty
    const [users] = await pool.query('SELECT * FROM `user` LIMIT 1');
    if (users.length === 0) {
      await pool.query('INSERT INTO `user` (username, password, role) VALUES (?, ?, ?)', ['admin', 'admin123', 'admin']);
      await pool.query('INSERT INTO `user` (username, password, role) VALUES (?, ?, ?)', ['student', 'user123', 'user']);
      console.log('[MySQL] Seeded users: admin (admin/admin123), student (student/user123)');
    }

    // Seed sample books if empty
    const [books] = await pool.query('SELECT * FROM `library` LIMIT 1');
    if (books.length === 0) {
      await pool.query('INSERT INTO `library` (title, author, category, copies) VALUES (?, ?, ?, ?)', ['Clean Code', 'Robert C. Martin', 'Programming', 5]);
      await pool.query('INSERT INTO `library` (title, author, category, copies) VALUES (?, ?, ?, ?)', ['Introduction to Algorithms', 'CLRS', 'Computer Science', 3]);
      console.log('[MySQL] Seeded sample library books.');
    }
  } catch (err) {
    console.error('[MySQL Error] Could not connect to MySQL:', err.message);
    console.log('-> Make sure MySQL service is running and credentials in server-mysql.js match.');
  }
}

// Middleware: Admin Authorization to Delete
function requireAdmin(req, res, next) {
  const role = req.headers['x-role'] || (req.headers['authorization'] === 'Bearer admin' ? 'admin' : '');
  if (role !== 'admin') {
    return res.status(403).json({
      success: false,
      error: 'Forbidden',
      message: 'Access Denied: Only Admin can delete library items!'
    });
  }
  next();
}

// 1. LOGIN API
app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ success: false, message: 'Username and password required.' });
  }

  try {
    const [rows] = await pool.query('SELECT id, username, role FROM `user` WHERE username = ? AND password = ?', [username, password]);
    if (rows.length === 0) {
      return res.status(401).json({ success: false, message: 'Invalid username or password.' });
    }
    const user = rows[0];
    res.json({
      success: true,
      message: `Logged in successfully as ${user.role}!`,
      user: { username: user.username, role: user.role },
      token: user.role === 'admin' ? 'admin-token' : 'user-token'
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 2. CREATE API (Add to Library)
app.post('/api/library', async (req, res) => {
  const { title, author, category = 'General', copies = 1 } = req.body;
  if (!title || !author) {
    return res.status(400).json({ success: false, message: 'Title and Author are required.' });
  }

  try {
    const [result] = await pool.query(
      'INSERT INTO `library` (title, author, category, copies) VALUES (?, ?, ?, ?)',
      [title, author, category, Number(copies)]
    );
    res.status(201).json({
      success: true,
      message: 'Book added to library successfully!',
      data: { id: result.insertId, title, author, category, copies: Number(copies) }
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 3. READ API (Get all or search)
app.get('/api/library', async (req, res) => {
  try {
    const { category } = req.query;
    let sql = 'SELECT * FROM `library`';
    const params = [];
    if (category) {
      sql += ' WHERE category = ?';
      params.push(category);
    }
    sql += ' ORDER BY id DESC';

    const [rows] = await pool.query(sql, params);
    res.json({ success: true, count: rows.length, data: rows });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 4. DELETE API (Requires Admin Authorization)
app.delete('/api/library/:id', requireAdmin, async (req, res) => {
  const { id } = req.params;
  try {
    const [result] = await pool.query('DELETE FROM `library` WHERE id = ?', [id]);
    if (result.affectedRows === 0) {
      return res.status(404).json({ success: false, message: 'Book not found.' });
    }
    res.json({ success: true, message: `Book #${id} deleted successfully.` });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Start Server
setupDatabase().then(() => {
  app.listen(PORT, () => {
    console.log(`[MySQL API] Running at http://localhost:${PORT}`);
  });
});
