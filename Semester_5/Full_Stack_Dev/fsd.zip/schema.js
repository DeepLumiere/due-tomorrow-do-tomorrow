/**
 * schema.js - Common Schema Definition for MySQL and MongoDB
 * 
 * To modify or add data structures:
 * Simply add/modify entities in the `schemas` object below.
 * Both server-mysql.js and server-mongo.js will automatically:
 *  1. Create the database & tables/collections.
 *  2. Seed default data if empty.
 *  3. Expose generalized REST APIs (/api/:entity) with validation!
 *
 * Example: To add a 'student' entity, just add:
 * student: {
 *   name: 'student',
 *   fields: {
 *     name: { type: 'string', required: true },
 *     roll_no: { type: 'string', required: true },
 *     department: { type: 'string', default: 'CS' },
 *     cgpa: { type: 'number', default: 0 }
 *   },
 *   seedData: [ ... ]
 * }
 */

const schemas = {
  // 1. User Schema (for login & admin authorization)
  user: {
    name: 'user',
    fields: {
      username: { type: 'string', required: true },
      password: { type: 'string', required: true },
      role: { type: 'string', default: 'user' } // 'admin' or 'user'
    },
    seedData: [
      { username: 'admin', password: 'admin123', role: 'admin' },
      { username: 'student', password: 'user123', role: 'user' }
    ]
  },

  // 2. Library Schema (default entity - change or add any entity!)
  library: {
    name: 'library',
    fields: {
      title: { type: 'string', required: true },
      author: { type: 'string', required: true },
      category: { type: 'string', default: 'General' },
      copies: { type: 'number', default: 1 }
    },
    seedData: [
      { title: 'Clean Code', author: 'Robert C. Martin', category: 'Programming', copies: 5 },
      { title: 'Introduction to Algorithms', author: 'CLRS', category: 'Computer Science', copies: 3 }
    ]
  }
};

/**
 * Helper to map schema types to MySQL data types
 */
function getMySqlType(fieldDef) {
  if (fieldDef.type === 'number') return 'INT DEFAULT 0';
  if (fieldDef.type === 'boolean') return 'TINYINT(1) DEFAULT 0';
  if (fieldDef.type === 'date') return 'DATETIME DEFAULT CURRENT_TIMESTAMP';
  if (fieldDef.type === 'text') return 'TEXT';
  return "VARCHAR(255) DEFAULT ''";
}

/**
 * Builds MySQL CREATE TABLE SQL query dynamically from any schema
 */
function generateMySqlTableSql(schema) {
  const columns = ['`id` INT AUTO_INCREMENT PRIMARY KEY'];
  
  for (const [fieldName, fieldDef] of Object.entries(schema.fields)) {
    const sqlType = getMySqlType(fieldDef);
    const notNull = fieldDef.required ? 'NOT NULL' : '';
    columns.push(`\`${fieldName}\` ${sqlType} ${notNull}`.trim());
  }

  columns.push('`created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP');
  return `CREATE TABLE IF NOT EXISTS \`${schema.name}\` (${columns.join(', ')}) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;`;
}

/**
 * Validates and sanitizes input data dynamically against any schema definition
 * @param {object} schema - The schema object from `schemas`
 * @param {object} inputData - Incoming request payload
 * @param {boolean} isUpdate - If true, required checks only apply to fields actually provided
 */
function validateAndFormat(schema, inputData, isUpdate = false) {
  const data = {};
  const errors = [];

  for (const [fieldName, fieldDef] of Object.entries(schema.fields)) {
    let val = inputData[fieldName];

    // Check required fields
    if (fieldDef.required && (val === undefined || val === null || val === '')) {
      if (!isUpdate || val !== undefined) {
        errors.push(`Field '${fieldName}' is required.`);
        continue;
      }
    }

    // Apply default value if field is missing
    if (val === undefined && fieldDef.default !== undefined && !isUpdate) {
      val = typeof fieldDef.default === 'function' ? fieldDef.default() : fieldDef.default;
    }

    if (val !== undefined && val !== null && val !== '') {
      // Cast types
      if (fieldDef.type === 'number') {
        const num = Number(val);
        if (isNaN(num)) {
          errors.push(`Field '${fieldName}' must be a number.`);
          continue;
        }
        val = num;
      } else if (fieldDef.type === 'boolean') {
        val = val === true || val === 'true' || val === 1 || val === '1';
      } else if (fieldDef.type === 'date') {
        const date = new Date(val);
        if (isNaN(date.getTime())) {
          errors.push(`Field '${fieldName}' must be a valid date.`);
          continue;
        }
        val = date;
      } else {
        val = String(val);
      }
      data[fieldName] = val;
    } else if (val === '' && fieldDef.type === 'string') {
      data[fieldName] = '';
    }
  }

  return { data, errors };
}

module.exports = {
  schemas,
  generateMySqlTableSql,
  validateAndFormat
};
