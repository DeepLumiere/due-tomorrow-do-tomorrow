/**
 * schema.js - Common Schema Definition for MySQL and MongoDB
 * 
 * To modify or add data structures:
 * Simply add/modify entities in the `schemas` object below.
 * Both server-mysql.js and server-mongo.js will automatically:
 *  1. Create the database & tables/collections.
 *  2. Auto-migrate existing tables (add any newly added columns automatically).
 *  3. Auto-seed initial data if empty.
 *  4. Hot-reload changes live without needing server restart!
 *  5. Expose generalized REST APIs (/api/:entity) with validation!
 *
 * Example: To add a 'student' entity, just add:
 * student: {
 *   name: 'student',
 *   fields: {
 *     name: { type: 'string', required: true },
 *     roll_no: { type: 'string', required: true },
 *     department: { type: 'string', default: 'CS' },
 *     cgpa: { type: 'number', default: 0 }
 *   },
 *   seedData: [ ... ]
 * }
 */

const schemas = {
  // 1. User Schema (for login & admin authorization)
  user: {
    name: 'user',
    fields: {
      username: { type: 'string', required: true },
      password: { type: 'string', required: true },
      role: { type: 'string', default: 'user' } // 'admin' or 'user'
    },
    seedData: [
      { username: 'admin', password: 'admin123', role: 'admin' },
      { username: 'student', password: 'user123', role: 'user' }
    ]
  },

  // 2. Library Schema (default entity - change or add any entity!)
  library: {
    name: 'library',
    fields: {
      title: { type: 'string', required: true },
      author: { type: 'string', required: true },
      category: { type: 'string', default: 'General' },
      copies: { type: 'number', default: 1 }
    },
    seedData: [
      { title: 'Clean Code', author: 'Robert C. Martin', category: 'Programming', copies: 5 },
      { title: 'Introduction to Algorithms', author: 'CLRS', category: 'Computer Science', copies: 3 }
    ]
  }
};

/**
 * Helper to map schema types to MySQL data types
 */
function getMySqlType(fieldDef) {
  if (fieldDef.type === 'number') return 'INT';
  if (fieldDef.type === 'boolean') return 'TINYINT(1)';
  if (fieldDef.type === 'date') return 'DATETIME';
  if (fieldDef.type === 'text') return 'TEXT';
  return 'VARCHAR(255)';
}

/**
 * Generates full column definition for MySQL (type, default, nullability)
 */
function getMySqlColumnDef(fieldDef) {
  const type = getMySqlType(fieldDef);
  let defaultClause = '';

  if (fieldDef.default !== undefined) {
    if (typeof fieldDef.default === 'number') {
      defaultClause = `DEFAULT ${fieldDef.default}`;
    } else if (typeof fieldDef.default === 'boolean') {
      defaultClause = `DEFAULT ${fieldDef.default ? 1 : 0}`;
    } else {
      defaultClause = `DEFAULT '${String(fieldDef.default).replace(/'/g, "''")}'`;
    }
  } else if (fieldDef.type === 'number') {
    defaultClause = 'DEFAULT 0';
  } else if (fieldDef.type === 'boolean') {
    defaultClause = 'DEFAULT 0';
  } else if (fieldDef.type === 'date') {
    defaultClause = 'DEFAULT CURRENT_TIMESTAMP';
  } else if (fieldDef.type !== 'text') {
    defaultClause = "DEFAULT ''";
  }

  const notNull = fieldDef.required ? 'NOT NULL' : '';
  return `${type} ${defaultClause} ${notNull}`.trim();
}

/**
 * Builds MySQL CREATE TABLE SQL query dynamically from any schema
 */
function generateMySqlTableSql(schema) {
  const columns = ['`id` INT AUTO_INCREMENT PRIMARY KEY'];
  
  for (const [fieldName, fieldDef] of Object.entries(schema.fields)) {
    const colDef = getMySqlColumnDef(fieldDef);
    columns.push(`\`${fieldName}\` ${colDef}`);
  }

  columns.push('`created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP');
  return `CREATE TABLE IF NOT EXISTS \`${schema.name}\` (${columns.join(', ')}) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;`;
}

/**
 * Validates and sanitizes input data dynamically against any schema definition
 * @param {object} schema - The schema object from `schemas`
 * @param {object} inputData - Incoming request payload
 * @param {boolean} isUpdate - If true, required checks only apply to fields actually provided
 */
function validateAndFormat(schema, inputData, isUpdate = false) {
  const data = {};
  const errors = [];

  for (const [fieldName, fieldDef] of Object.entries(schema.fields)) {
    let val = inputData[fieldName];

    // Check required fields
    if (fieldDef.required && (val === undefined || val === null || val === '')) {
      if (!isUpdate || val !== undefined) {
        errors.push(`Field '${fieldName}' is required.`);
        continue;
      }
    }

    // Apply default value if field is missing
    if (val === undefined && fieldDef.default !== undefined && !isUpdate) {
      val = typeof fieldDef.default === 'function' ? fieldDef.default() : fieldDef.default;
    }

    if (val !== undefined && val !== null && val !== '') {
      // Cast types
      if (fieldDef.type === 'number') {
        const num = Number(val);
        if (isNaN(num)) {
          errors.push(`Field '${fieldName}' must be a number.`);
          continue;
        }
        val = num;
      } else if (fieldDef.type === 'boolean') {
        val = val === true || val === 'true' || val === 1 || val === '1';
      } else if (fieldDef.type === 'date') {
        const date = new Date(val);
        if (isNaN(date.getTime())) {
          errors.push(`Field '${fieldName}' must be a valid date.`);
          continue;
        }
        val = date;
      } else {
        val = String(val);
      }
      data[fieldName] = val;
    } else if (val === '' && fieldDef.type === 'string') {
      data[fieldName] = '';
    }
  }

  return { data, errors };
}

module.exports = {
  schemas,
  getMySqlType,
  getMySqlColumnDef,
  generateMySqlTableSql,
  validateAndFormat
};
