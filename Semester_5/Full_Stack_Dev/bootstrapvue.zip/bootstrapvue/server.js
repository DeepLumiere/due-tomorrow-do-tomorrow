const express = require("express");
const mysql = require("mysql2");
const path = require("path");

const app = express();
const PORT = 3000;

// Enable CORS so browser requests from any origin (Live Server / file) succeed
app.use((req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS");
    res.header("Access-Control-Allow-Headers", "Content-Type");
    if (req.method === "OPTIONS") {
        return res.sendStatus(200);
    }
    next();
});

// Body parser to read JSON data
app.use(express.json());

// Serve static files (HTML, CSS, JS)
app.use(express.static(__dirname));

// MySQL connection
const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "1234",
    database: "student_db"
});

// Auto-create students table if it doesn't exist
const createTableSql = `
    CREATE TABLE IF NOT EXISTS students (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(100) NOT NULL,
        score INT NOT NULL,
        department VARCHAR(50) NOT NULL,
        semester INT NOT NULL
    )
`;
db.query(createTableSql, (err) => {
    if (err) console.error("Table setup error:", err.message);
});

// Serve index.html UI at the root path
app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "index.html"));
});

// Simple Login with hardcoded credentials (no middleware)
app.post("/login", (req, res) => {
    const { username, password } = req.body;

    // Hardcoded credentials: admin / admin123 (or 1234)
    if (username === "admin" && (password === "admin123" || password === "1234")) {
        return res.json({ success: true, message: "Login successful", username: "admin" });
    }

    res.status(401).json({ success: false, message: "Invalid username or password" });
});

// GET: Fetch all students
app.get("/students", (req, res) => {
    const sql = "SELECT * FROM students ORDER BY id DESC";
    db.query(sql, (err, rows) => {
        if (err) {
            console.error(err);
            return res.status(500).send("Could not fetch students");
        }
        res.json(rows);
    });
});

// POST: Add a new student
app.post("/students", (req, res) => {
    const { name, email, score, department, semester } = req.body;

    if (!name || !email || score === undefined || !department || !semester) {
        return res.status(400).send("All fields are required");
    }

    const sql = `
        INSERT INTO students (name, email, score, department, semester)
        VALUES (?, ?, ?, ?, ?)
    `;

    db.query(
        sql,
        [name.trim(), email.trim(), Number(score), department, Number(semester)],
        (err) => {
            if (err) {
                console.error(err);
                return res.status(500).send("Could not add student");
            }
            res.status(201).send("Student added successfully");
        }
    );
});

// DELETE: Delete a student by ID
app.delete("/students/:id", (req, res) => {
    const id = req.params.id;
    const sql = "DELETE FROM students WHERE id = ?";

    db.query(sql, [id], (err, result) => {
        if (err) {
            console.error(err);
            return res.status(500).send("Could not delete student");
        }
        if (result.affectedRows === 0) {
            return res.status(404).send("Student not found");
        }
        res.send("Student deleted successfully");
    });
});

// Connect to MySQL and start the server
db.connect((err) => {
    if (err) {
        console.error("MySQL connection failed:", err.message);
        return;
    }
    console.log("Connected to MySQL (student_db)");
    app.listen(PORT, () => {
        console.log(`Server running at http://localhost:${PORT}`);
    });
});
