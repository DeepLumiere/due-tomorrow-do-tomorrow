

const studentForm = document.getElementById('studentForm');
const studentTable = document.getElementById('studentTableBody');
const submitBtn = document.querySelector('button[type="submit"]');

let students = [];

// let students = JSON.parse(localStorage.getItem('sms_students')) || [];
// let studentId = 1;
// let editingId = null;

// function saveStudents(){
//     localStorage.setItem('sms_students', JSON.stringify(students));
// }

function displayStudents(){
    studentTable.innerHTML = '';

    for(let i = 0; i<students.length; i++){
        let s = students[i];
        const row = document.createElement('tr');

        row.innerHTML = `
            <td>${s.id}</td>
            <td>${s.enrollment}</td>
            <td>${s.name}</td>
            <td>${s.email}</td>
            <td>${s.department}</td>
            <td>${s.semester}</td> 
        `;

        studentTable.appendChild(row);
    }
}   

function loadStudents(){
    fetch('http://localhost:3000/api/students').
    then(response=>{
        if(!response.ok){
            throw new Error('Could not fetch students');
        }

        return response.json();
    })
    .then(data => {
        students = data;
        displayStudents();
    })
    .catch(error=>{
        console.log('Error:', error.message);
        alert('Could not load students. Check your backend.');
    });
}
studentForm.addEventListener('submit', function(event){
    event.preventDefault();

    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const department = document.getElementById('department').value;
    const semester = document.getElementById('semester').value;
    const enrollment = document.getElementById('enrollment').value.trim();

    if(!name || !email || !department || !semester || !enrollment) {
        alert('Please fill in all fields.');
        return;
    }

    let student = {
        // id: editingId === null ? studentId : editingId,
        enrollment: enrollment,
        name: name,
        email: email,
        department: department,
        semester: semester 
    };

    // if(editingId === null){
    //     students.push(student);
    //     studentId++;
    // } else {
    //     for (let i = 0; i < students.length; i++){
    //         if(students[i].id === editingId){
    //             students[i] = student;
    //             break;
    //         }
    //     }
    // }

    // saveStudents();
    // displayStudents();
    // studentForm.reset();
    // editingId = null;
    // submitBtn.textContent = 'Add Student';

    fetch('http://localhost:3000/api/students', {
        method: 'POST',

        headers:{
            'Content-Type': 'application/json'
        },

        body: JSON.stringify(student)
    })
    .then(response => {
        return response.json().then(data => {

            if(!response.ok){
                throw new Error(data.error || 'Could not add');
            }
            return data;
        });
    })
    .then(data => {
        alert('Student added successfully. ID: ' + data.id);

        studentForm.reset();

        loadStudents();
    })
    .catch(error => {
        console.log('Error:', error.message);
        alert(error.message);
    });
});


function editStudent(id) {
    for (let i = 0; i < students.length; i++) {
        if (students[i].id === id) {
            document.getElementById('name').value = students[i].name;
            document.getElementById('email').value = students[i].email;
            document.getElementById('department').value = students[i].department;
            document.getElementById('semester').value = students[i].semester;
            document.getElementById('enrollment').value = students[i].enrollment;

            editingId = id;
            submitBtn.textContent = 'Update Student';
            break;
        }
    }
}

// Delete student
function deleteStudent(id) {
    for (let i = 0; i < students.length; i++) {
        if (students[i].id === id) {
            students.splice(i, 1);
            break;
        }
    }

    saveStudents();
    displayStudents();
}

// Reset editing mode
studentForm.addEventListener('reset', function() {
    editingId = null;
    submitBtn.textContent = 'Add Student';
});

// Show saved students when the page opens
loadStudents();
displayStudents();


const taskForm = document.getElementById("taskForm");
const taskInput = document.getElementById("taskInput");
const taskList = document.getElementById("taskList");

let tasks = JSON.parse(localStorage.getItem('sms_tasks')) || [];

function saveTasks(){
    localStorage.setItem('sms_tasks', JSON.stringify(tasks));
}

function displayTasks(){
    taskList.innerHTML='';

    for(let i=0 ; i<tasks.length; i++){
        let task = tasks[i];

        let li = document.createElement('li');
        li.className = 'list-group-item d-flex align-items-center gap-2';

        let checkbx = document.createElement('input');
        checkbx.type = 'checkbox';
        checkbx.checked = task.completed;

        let taskname = document.createElement('span');
        taskname.textContent = task.name;
        taskname.style.flex = '1';

        if(task.completed){
            taskname.style.textDecoration = 'line-through';
        }

        let deleteBtn = document.createElement('button');
        deleteBtn.textContent = 'Delete';
        deleteBtn.className = 'btn btn-danger btn-sm';
        deleteBtn.type = 'button';

        checkbx.addEventListener('change', function(){
            task.completed = checkbx.checked;
            saveTasks();
            displayTasks();
        });

        deleteBtn.addEventListener('click', function(){
            tasks.splice(i, 1);

            saveTasks();
            displayTasks();
        })

        li.append(checkbx);
        li.append(taskname);
        li.append(deleteBtn);

        taskList.appendChild(li);
    }
    
}

taskForm.addEventListener('submit', function(event){
    event.preventDefault();

    let taskName = taskInput.value.trim();
    if(taskName === ''){
        alert('Please enter a task name.');
        return;
    }

    let task = {
        name: taskName,
        completed: false
    }

    tasks.push(task);

    saveTasks();
    displayTasks();

    taskForm.reset();
});



fetch('http://localhost:3000/api/test')
    .then(response => {
        if(!response.ok){
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data =>{
        document.getElementById('backendStatus').textContent = 'Backend connected: '+data.message;
        console.log(data);
    })

    .catch(error =>{
        document.getElementById('backendStatus').textContent = 'Backend  Connection Failed. Check';
        console.log('Error:', error);
    })
displayTasks();