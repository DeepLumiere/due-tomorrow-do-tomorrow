const locBtn = document.getElementById('locationBtn')
const locResult = document.getElementById('locationResult')

locBtn.addEventListener('click', () => {
    if(!navigator.geolocation){
        locResult.textContent = 'Geolocation is not supported by your browser'
        return;
    }

    locResult.textContent = 'Locating...'

    navigator.geolocation.getCurrentPosition(function(position){
        const lat = position.coords.latitude;
        const lng = position.coords.longitude;

        locResult.textContent = 'Latitude: '+lat+', Longitude: '+lng;
    },

    function(error){
        locResult.textContent = 'Could not get Location: '+error.message;
    })
})

const dragItems = document.querySelectorAll('.drag-item');
const dropZone = document.getElementById('dropzone');

for(let i=0; i<dragItems.length; i++){
    dragItems[i].addEventListener('dragstart', function(event){
        event.dataTransfer.setData('text/plain', event.currentTarget.id);
    });
}

dropZone.addEventListener('dragover', function(event){
    event.preventDefault();
});

dropZone.addEventListener('drop', function(event){
    event.preventDefault();

    const id = event.dataTransfer.getData('text/plain');
    const draggedItem = document.getElementById(id);

    if(draggedItem){
        dropZone.appendChild(draggedItem);
    }
})
