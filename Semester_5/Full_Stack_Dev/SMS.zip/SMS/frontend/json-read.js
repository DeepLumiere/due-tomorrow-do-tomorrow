const fs = require('fs');
const path = require('path');

const filepath = path.join(__dirname, "data", "student.json");

fs.readFile(filepath, "utf8", (err, data)=>{
    if (err) {
        console.error('Error reading file:', err);
        return;
    }

    const students = JSON.parse(data);
    students.forEach(student => {
        console.log(`Name: ${student.name}, Enrollment: ${student.enrollment}`);
    });

})