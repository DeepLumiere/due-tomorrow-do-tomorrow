CREATE DATABASE IF NOT EXISTS sms_db;

USE sms_db;

CREATE TABLE IF NOT EXISTS students(
    id INT auto_increment primary key,
    enrollment varchar(30) not null unique,
    name varchar(100) not null,
    email varchar(150) not null,
    department varchar(50) not null, 
    semester int not null
);