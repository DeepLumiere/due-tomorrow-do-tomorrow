const express = require('express');
const cors = require('cors');
const mysql= require('mysql2/promise');

require('dotenv').config();

const app = express();

app.use(cors());
app.use(express.json());

const db = mysql.createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME
});


app.get('/', (req, res)=>{
    res.send('Student management is Running');
})

app.get('/api/test', async (req, res)=>{
    try{
        const[rows] = await db.query('SELECT 1 AS connected');
        
        res.json({
            message: 'API is working with MySQL and Backend', 
            database: process.env.DB_NAME, 
            connected: rows[0].connected
        });
    }

    catch(error){
        console.error(error.message);

        res.status(500).json({
            message: "DB connection failed"
        });
    }
});

app.get('/api/students', async (req, res) => {
    try{
        const [students] = await db.query(
            'SELECT * FROM students ORDER BY id'
        );

        res.json(students);
    }
    catch(error){
        console.log(error.message);
        res.status(500).json({ error: 'Could not fetch students' });
    }
});

app.post('/api/students', async(req, res) => {
    try{
        const { enrollment, name, email, department, semester } = req.body;

        if(!enrollment || !name || !email || !department || !semester){
            return res.status(400).json({
                error: 'Please fill in all fields'
            });
        }

        const [result] = await db.execute(
            `INSERT INTO students
            (enrollment, name, email, department, semester)
            VALUES(?, ?, ?, ?, ?)`,
            [enrollment, name, email, department, Number(semester)]
        );

        res.status(201).json({
            id: result.insertId,
            enrollment,
            name,
            email,
            department,
            semester: Number(semester)
        });
    }
    catch(error){
        console.log(error.message);
        res.status(500).json({error:'Could not add student'});
    }
});

async function startServer() {
    try {
        await db.query('SELECT 1');

        console.log('MySQL connected');

        const port = process.env.PORT || 3000;

        app.listen(port, () => {
            console.log(`Server running at http://localhost:${port}`);
        });

    } catch (error) {
        console.error('MySQL connection failed:', error.message);
    }
}

startServer();
