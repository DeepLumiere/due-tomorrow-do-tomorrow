# 3CS103ME24: Data Analysis and Visualisation (DAV)
# Module 4: Tableau Desktop Guide & Core Visualizations

*Designed for B.Tech Computer Science DAV Lab Exams, Vivas, and Term Submissions.*  
*Contains core architecture, the 7 lab visualizations click-by-click, end-to-end flows for ETL, Classification, and Regression, calculated fields formulas, and interactive dashboarding.*

---

## Table of Contents
1. [Tableau Core Architecture & Visual Variables](#tableau-architecture)
2. [The 7 Core Lab Graphs in Tableau (Click-by-Click)](#tableau-7-graphs)
   - [Graph 1: Pie Chart & Donut Chart](#graph-1)
   - [Graph 2: Bar Chart (Vertical, Horizontal, Stacked, Clustered)](#graph-2)
   - [Graph 3: Line Chart (Time-Series & Multi-Line Trend)](#graph-3)
   - [Graph 4: KPI Card / BAN (Big Ass Number)](#graph-4)
   - [Graph 5: Treemap (Hierarchical Sizing & Coloring)](#graph-5)
   - [Graph 6: Box & Whisker Plot (With Outlier Fences)](#graph-6)
   - [Graph 7: Distribution Histogram (Bins & Frequency)](#graph-7)
3. [Complete Flow 1: Data Processing & Preparation (ETL Pipeline)](#tableau-flow-etl)
4. [Complete Flow 2: Classification Performance & Diagnostics Dashboard](#tableau-flow-classification)
5. [Complete Flow 3: Regression Techniques & Residual Error Diagnostics](#tableau-flow-regression)
6. [Master Calculated Fields Cheat Sheet](#tableau-calculated-fields)
7. [Interactive Dashboard Assembly & Action Filters](#tableau-dashboard-assembly)
8. [Tableau Lab Exam & Viva Quick Reference](#tableau-viva)

---

<a name="tableau-architecture"></a>
### 1. Tableau Core Architecture & Visual Variables

- **Data Pane Mechanics**:
  - **Blue Pills (Discrete)**: Slices data into distinct categories, headers, and individual row/column groups.
  - **Green Pills (Continuous)**: Generates an unbroken numerical or temporal axis with continuous coordinate scaling.
  - **Dimensions**: Categorical, qualitative attributes setting the **Level of Detail (LoD)** on the sheet (e.g., `Region`, `Product_Category`, `Customer_Segment`).
  - **Measures**: Quantitative, numerical values aggregated dynamically based on active dimensions (`SUM`, `AVG`, `MEDIAN`, `COUNT`, `STDEV`).
- **Marks Card Visual Channels**:
  - **Color**: Heatmaps, class distribution, diverging error bands, conditional formatting.
  - **Size**: Proportional bubble sizing, weighted scatter points, correlation magnitudes.
  - **Label / Text**: Hero metrics, BAN values, percentages-of-total.
  - **Detail**: Injects granular row-level data points without visual color/shape distortions (essential for scatter plots).
  - **Tooltip**: Rich hover cards displaying contextual metadata.

---

<a name="tableau-7-graphs"></a>
### 2. The 7 Core Lab Graphs in Tableau (Click-by-Click)

<a name="graph-1"></a>
#### Graph 1: Pie Chart & Donut Chart

- **A. Standard Pie Chart**:
  1. In the Marks card dropdown, change mark type from *Automatic* to **Pie**.
  2. Drag categorical Dimension (e.g. `Region` or `Category`) to **Color** on the Marks card.
  3. Drag numeric Measure (e.g. `Sales` or `Profit`) to **Angle** on the Marks card.
  4. Drag Dimension to **Label**. Drag Measure to **Label**.
  5. Right-click the Measure pill inside **Label** $\rightarrow$ **Quick Table Calculation** $\rightarrow$ **Percent of Total**.
  6. In top toolbar, change view mode from *Standard* to **Entire View** for a clear, centered circle.
- **B. Professional Donut Chart (Dual-Axis Method — Exam/Viva Favorite)**:
  1. Follow steps 1-3 above to build the base pie chart.
  2. Double-click the empty space on the **Rows** shelf $\rightarrow$ type `AVG(0)` and press Enter.
  3. Type `AVG(0)` a second time on the **Rows** shelf and press Enter. (Two identical pie charts appear stacked vertically).
  4. Right-click the second `AVG(0)` pill in Rows $\rightarrow$ Select **Dual Axis**.
  5. In the Marks card sidebar, you will see three tabs: *All*, *AVG(0)* (outer pie), and *AVG(0) (2)* (inner circle):
     - Click **AVG(0)** tab: Increase **Size** slider slightly.
     - Click **AVG(0) (2)** tab: Remove `Color` and `Angle` pills. Change mark type to **Circle**. Set **Color** to solid White. Adjust **Size** slider to be slightly smaller than the outer pie.
     - Drag total metric `SUM(Sales)` to **Label** on the *AVG(0) (2)* tab to display the grand total inside the center hole!
  6. Right-click the left vertical axis $\rightarrow$ Uncheck **Show Header**. Result: A clean donut chart!

<a name="graph-2"></a>
#### Graph 2: Bar Chart (Vertical, Horizontal, Stacked, Clustered)

- **A. Vertical Column Bar Chart**:
  1. Drag Dimension (e.g. `Sub-Category`) to the **Columns** shelf.
  2. Drag Measure (e.g. `Sales`) to the **Rows** shelf.
  3. Click **Sort Descending** icon on the top toolbar.
- **B. Horizontal Sorted Bar Chart (Best for Long Labels)**:
  1. Drag Measure to **Columns**, Dimension to **Rows**.
  2. Click **Sort Descending** icon (prevents label overlapping).
  3. Drag Measure to **Label** to display exact bar totals.
- **C. Stacked Bar Chart (Composition)**:
  1. Create a vertical or horizontal bar chart as above.
  2. Drag a secondary Dimension (e.g. `Customer_Segment` or `Ship_Mode`) to **Color** on the Marks card.
  3. The single bar splits into proportional stacked colored segments.
- **D. Clustered / Side-by-Side Bar Chart**:
  1. Drag primary Dimension (e.g. `Category`) to **Columns**.
  2. Drag secondary Dimension (e.g. `Segment`) to **Columns** (placed immediately to the right of `Category`).
  3. Drag Measure (e.g. `Sales`) to **Rows**.
  4. Drag secondary Dimension to **Color** on Marks card to color each cluster distinctly.

<a name="graph-3"></a>
#### Graph 3: Line Chart (Time-Series & Multi-Line Trend)

- **A. Single Continuous Time-Series Line**:
  1. Drag Date Dimension (e.g. `Order_Date`) to the **Columns** shelf.
  2. Click the date pill dropdown $\rightarrow$ Select the continuous green date level (e.g. **Month** with year: `May 2024`).
  3. Drag Measure (e.g. `Sales`) to the **Rows** shelf. Mark type automatically becomes **Line**.
  4. Click **Color** on Marks card $\rightarrow$ Under *Effects*, check **Markers** $\rightarrow$ Select **All** (places clear dots on each data point).
- **B. Multi-Line Trend Comparison**:
  1. Create single line chart as above.
  2. Drag categorical Dimension (e.g. `Region` or `Category`) to **Color** on Marks card.
  3. Multiple colored trend lines render simultaneously on the same coordinate axis with an interactive legend.
  4. Click **Label** on Marks card $\rightarrow$ Check **Show mark labels** $\rightarrow$ Select **Line Ends** (labels only start and finish to prevent visual clutter).

<a name="graph-4"></a>
#### Graph 4: KPI Card / BAN (Big Ass Number)

1. In Marks card dropdown, change mark type to **Text**.
2. Drag numeric Measure (e.g. `Sales`) to **Text / Label** on Marks card.
3. Click **Text** on Marks card $\rightarrow$ Click the `...` button next to the text preview:
   - Highlight `<SUM(Sales)>` $\rightarrow$ Change font size to **28pt Bold**, color Dark Navy `#1F2937`.
   - Add a subtitle line: `TOTAL ANNUAL REVENUE` in **9pt Light Gray**, uppercase.
4. Add Secondary Comparison / Delta ($\Delta$):
   - Drag `YoY Growth` or `Target Difference` to **Text / Label**.
   - Format with an up/down arrow symbol ($\blacktriangle$ / $\blacktriangledown$) and conditional green/red color.
5. In top toolbar, set view to **Entire View**. Right-click canvas $\rightarrow$ **Format...** $\rightarrow$ Set card border.

<a name="graph-5"></a>
#### Graph 5: Treemap (Hierarchical Sizing & Coloring)

1. Drag categorical Dimension (e.g. `Category`) to **Label** on the Marks card.
2. Drag numeric Measure (e.g. `Sales`) to **Size** on the Marks card.
3. Mark type automatically changes to **Square / Rectangle** layout.
4. Drag secondary metric (e.g. `Profit` or `Profit_Margin`) to **Color** on the Marks card.
   - Click **Color** $\rightarrow$ **Edit Colors...** $\rightarrow$ Select **Red-Green Diverging** (instantly reveals high-sales but low-profit categories!).
5. **Nested Hierarchical Treemap**:
   - Drag a lower-level Dimension (e.g. `Sub-Category`) onto **Detail** or **Label** on Marks card.
   - Tableau groups sub-categories neatly inside their parent Category bounding rectangles!

<a name="graph-6"></a>
#### Graph 6: Box & Whisker Plot (With Outlier Fences)

1. Drag categorical Dimension (e.g. `Department` or `Category`) to the **Columns** shelf.
2. Drag numeric Measure (e.g. `Salary` or `Sales`) to the **Rows** shelf.
3. **Crucial Disaggregation Step**:
   - By default, Tableau aggregates all rows into one bar. Go to top menu: click **Analysis** $\rightarrow$ **Uncheck "Aggregate Measures"** (or drag unique row ID `Record_ID` to **Detail** on Marks card). Every observation is now a distinct dot.
4. Click the **Analytics** tab next to Data on the left sidebar.
5. Drag **Box Plot** onto the canvas and drop it on **Cell**.
6. Right-click the box plot on the chart $\rightarrow$ Select **Edit...**:
   - **Whiskers**: Set to **1.5 times the IQR** (Standard Tukey Fence rule).
   - Check **Hide underlying marks (except outliers)** if you only want to see the box summary and extreme outlier dots.
7. Points beyond the upper and lower whiskers appear distinctly as outlier marks!

<a name="graph-7"></a>
#### Graph 7: Distribution Histogram (Bins & Frequency)

1. In the Data Pane (left), find your numeric Measure (e.g. `Age`, `Salary`, or `Discount`).
2. Right-click the Measure $\rightarrow$ Select **Create** $\rightarrow$ **Bins...**.
3. In the dialog, set **Size of bins** (e.g. `10` for Age, `500` for Salary) $\rightarrow$ Click **OK**.
4. Drag the newly created Bin dimension (Blue pill with histogram icon) to the **Columns** shelf.
5. Drag the original numeric Measure to the **Rows** shelf.
6. Click the dropdown arrow on the Measure pill in Rows $\rightarrow$ Change **Measure (Sum)** to **Count** (or `Count (Distinct)`).
7. In Marks card, verify mark type is **Bar**. Click **Size** $\rightarrow$ Set to **Fixed** with alignment center to produce touching histogram bars without artificial gaps.
8. Drag `Count` to **Label** to display exact bin frequency counts.

---

<a name="tableau-flow-etl"></a>
### 3. Complete Flow 1: Data Processing & Preparation (ETL Pipeline)

#### Concrete Dataset Scenario: `raw_ecommerce_transactions.csv`
- `Transaction_ID`: Alpha-numeric code (`TX-2023-9901`).
- `Customer_Info`: Combined string (`"John Doe - Corporate Tier"`).
- `Order_Date`: String date with mixed separators.
- `Region`: Geographic category (`East`, `West`, `South`, `North`, `Unknown`).
- `Sales_Q1`, `Sales_Q2`, `Sales_Q3`, `Sales_Q4`: Wide unpivoted quarterly sales columns.
- `Discount_Raw`: String percentages containing symbols and nulls (`"15%"`, `"None"`, `NULL`).
- `Return_Status`: Categorical with nulls (`"Returned"`, `NULL`).

#### Click-by-Click Implementation Steps:

```mermaid
flowchart TD
    A[Data Source Connection & Data Interpreter] --> B[Pivot Wide Quarterly Sales to Rows]
    B --> C[Custom String Split: Name & Tier]
    C --> D[Handling Missing Values & Type Casting: ZN, IFNULL]
    D --> E[LOD Discretization: Tertile / Quartile Bins]
    E --> F[Feature Normalization: Min-Max & Z-Score Fields]
    F --> G[Clean Data Schema Validation]
```

1. **Step 1: Ingestion & Data Interpreter**:
   - In Tableau start page, click **Text file** $\rightarrow$ Select `raw_ecommerce_transactions.csv`.
   - On the Data Source canvas, check the box **Use Data Interpreter** (top left). Tableau automatically detects titles and properly infers header rows.
2. **Step 2: Pivoting Wide Columns into Tall/Normalized Format**:
   - In the data preview grid, multi-select `Sales_Q1`, `Sales_Q2`, `Sales_Q3`, and `Sales_Q4` using `Ctrl + Click`.
   - Right-click any selected column header $\rightarrow$ Select **Pivot**.
   - Rename `Pivot Field Names` to **`Quarter`**. Rename `Pivot Field Values` to **`Revenue`**.
   - *Why this is mandatory*: Wide columns force clumsy calculations (`Q1 + Q2 + Q3 + Q4`), whereas a tall table enables instantaneous slicing by `Quarter`.
3. **Step 3: String Splitting (Feature Extraction)**:
   - In the Data grid, locate `Customer_Info`.
   - Click the drop-down arrow $\rightarrow$ Select **Custom Split...** $\rightarrow$ Separator: `-`, Split off: **All**.
   - Rename `Customer_Info - Split 1` to **`Customer_Name`**.
   - Rename `Customer_Info - Split 2` to **`Customer_Tier`**.
4. **Step 4: Imputation & Type Casting with Calculated Fields**:
   - Click **Analysis** $\rightarrow$ **Create Calculated Field...**.
   - **Discount Imputation & Float Casting (`[Clean_Discount]`)**:
     ```tableau
     ZN(FLOAT(REPLACE(REPLACE([Discount_Raw], "%", ""), "None", "0"))) / 100.0
     ```
   - **Handling Categorical Nulls (`[Clean_Return_Status]`)**:
     ```tableau
     IFNULL([Return_Status], "Kept / Not Returned")
     ```
5. **Step 5: Normalization via Level of Detail (LOD) Calculations**:
   - **Min-Max Normalization (`[Revenue_MinMax_Normalized]`)**:
     ```tableau
     ([Revenue] - {FIXED : MIN([Revenue])}) / ({FIXED : MAX([Revenue])} - {FIXED : MIN([Revenue])})
     ```
   - **Z-Score Normalization (`[Revenue_ZScore_Normalized]`)**:
     ```tableau
     ([Revenue] - {FIXED : AVG([Revenue])}) / {FIXED : STDEV([Revenue])}
     ```
6. **Step 6: Discretization (Equal-Width vs. Equal-Frequency Bins)**:
   - **Equal-Width Bins**: Right-click `Revenue` $\rightarrow$ Create $\rightarrow$ Bins (Size = `500`).
   - **Equal-Frequency Tertiles (`[Revenue_Tertile_Cohort]`)**:
     ```tableau
     IF [Revenue] <= {FIXED : PERCENTILE([Revenue], 0.333)} THEN "T1: Low Volume (<33%)"
     ELSEIF [Revenue] <= {FIXED : PERCENTILE([Revenue], 0.667)} THEN "T2: Mid Volume (33-67%)"
     ELSE "T3: High Volume (>67%)"
     END
     ```

---

<a name="tableau-flow-classification"></a>
### 4. Complete Flow 2: Classification Performance & Diagnostics Dashboard

#### Concrete Dataset Scenario: `telecom_customer_churn_eval.csv`
- `Customer_ID`: Unique client key.
- `Actual_Churn`: Binary ground truth (`"Yes"`, `"No"`).
- `Churn_Probability`: Continuous output from model ($0.00$ to $1.00$).
- `Monthly_Charges`: Customer monthly billing measure.
- `Tenure_Months`: Customer loyalty duration in months.

#### Click-by-Click Implementation Steps:

```mermaid
flowchart TD
    A[Create Probability Threshold Parameter: 0.0 to 1.0] --> B[Calculated Field: Dynamic Predicted Class]
    B --> C[Calculated Field: 4-Quadrant Outcome: TP, TN, FP, FN]
    C --> D[Confusion Matrix Heatmap with Dual Labels]
    D --> E[Interactive KPI BAN Cards: Accuracy, Precision, Recall, F1]
    E --> F[Decision Boundary Feature Scatter Plot]
```

1. **Step 1: Create Interactive Classification Threshold Parameter**:
   - In Data Pane, click dropdown arrow $\rightarrow$ **Create Parameter...**.
   - Name: **`Classification_Threshold`**, Data type: **Float**, Current value: `0.50`, Range: `0.0` to `1.0`, Step: `0.05`.
   - Right-click parameter $\rightarrow$ **Show Parameter** (slider appears on canvas).
2. **Step 2: Generate Dynamic Predictions**:
   - Create Calculated Field **`[Dynamic_Predicted_Churn]`**:
     ```tableau
     IF [Churn_Probability] >= [Classification_Threshold] THEN "Yes" ELSE "No" END
     ```
3. **Step 3: Define 4-Quadrant Diagnostic Outcome**:
   - Create Calculated Field **`[Confusion_Matrix_Class]`**:
     ```tableau
     IF [Actual_Churn] = "Yes" AND [Dynamic_Predicted_Churn] = "Yes" THEN "True Positive (TP)"
     ELSEIF [Actual_Churn] = "No" AND [Dynamic_Predicted_Churn] = "No" THEN "True Negative (TN)"
     ELSEIF [Actual_Churn] = "No" AND [Dynamic_Predicted_Churn] = "Yes" THEN "False Positive (FP)"
     ELSEIF [Actual_Churn] = "Yes" AND [Dynamic_Predicted_Churn] = "No" THEN "False Negative (FN)"
     END
     ```
4. **Step 4: Build Confusion Matrix Heatmap**:
   - Drag `Actual_Churn` to **Rows**; `Dynamic_Predicted_Churn` to **Columns**.
   - Change mark type to **Square**.
   - Drag `Customer_ID` (Count Distinct) to **Color** (Palette: Orange-Blue Diverging).
   - Drag `Customer_ID` (Count Distinct) to **Label**.
   - Add Percentage: Drag `Customer_ID` to **Label** a second time $\rightarrow$ Quick Table Calculation $\rightarrow$ **Percent of Total**.
5. **Step 5: Create KPI BAN Cards for Model Performance**:
   - **Accuracy**:
     ```tableau
     SUM(IIF([Actual_Churn] = [Dynamic_Predicted_Churn], 1, 0)) / COUNT([Customer_ID])
     ```
   - **Precision**:
     ```tableau
     SUM(IIF([Actual_Churn] = "Yes" AND [Dynamic_Predicted_Churn] = "Yes", 1, 0)) /
     NULLIF(SUM(IIF([Dynamic_Predicted_Churn] = "Yes", 1, 0)), 0)
     ```
   - **Recall (Sensitivity)**:
     ```tableau
     SUM(IIF([Actual_Churn] = "Yes" AND [Dynamic_Predicted_Churn] = "Yes", 1, 0)) /
     NULLIF(SUM(IIF([Actual_Churn] = "Yes", 1, 0)), 0)
     ```
   - **F1-Score**:
     ```tableau
     2 * (([Model_Precision] * [Model_Recall]) / NULLIF(([Model_Precision] + [Model_Recall]), 0))
     ```
6. **Step 6: Diagnostic Scatter Plot (Feature Space Misclassification View)**:
   - Drag `Tenure_Months` to Columns, `Monthly_Charges` to Rows. Uncheck Aggregate Measures.
   - Drag `[Confusion_Matrix_Class]` to **Color** and **Shape**.
   - Moving the `Classification_Threshold` slider dynamically reclassifies observations between False Negatives and False Positives in real-time!

---

<a name="tableau-flow-regression"></a>
### 5. Complete Flow 3: Regression Techniques & Residual Error Diagnostics

#### Concrete Dataset Scenario: `real_estate_sales_regression.csv`
- `Property_ID`: Observation identifier.
- `Square_Footage`: Continuous predictor attribute ($X$).
- `Sale_Price`: Dependent continuous target ($Y$).

#### Click-by-Click Implementation Steps:

```mermaid
flowchart TD
    A[Scatter Plot: Square Footage vs Sale Price] --> B[Analytics Pane: Linear & Polynomial Trend Lines]
    B --> C[Extract Model Parameters: Slope m, Intercept c, R2, p-value]
    C --> D[Parameter-Driven Prediction Field]
    D --> E[Compute Residuals: Actual - Predicted]
    E --> F1[Residual vs Fitted Plot: Check Homoscedasticity]
    E --> F2[Residual Bins Histogram: Check Error Normality]
    E --> F3[Regression Metric KPIs: MAE, RMSE]
```

1. **Step 1: Construct Regression Scatter Plot**:
   - Drag `Square_Footage` to Columns, `Sale_Price` to Rows.
   - Uncheck **Analysis** $\rightarrow$ **Aggregate Measures**. Change mark to Circle, Opacity 65%.
2. **Step 2: Fit and Evaluate Trend Lines**:
   - Analytics tab $\rightarrow$ Drag **Trend Line** $\rightarrow$ Drop on **Linear**.
   - Right-click Trend Line $\rightarrow$ Select **Describe Trend Line...**:
     - Read equation: $Sale\_Price = 215.42 \times Square\_Footage + 35120.5$.
     - Read model quality: $R^2 = 0.8412$, $p\text{-value} < 0.0001$.
3. **Step 3: Create Parameter-Driven Predictions & Error Metrics**:
   - Create Parameters: `Param_Slope` (`215.42`), `Param_Intercept` (`35120.5`).
   - Calculated Field `[Predicted_Sale_Price]`: `([Param_Slope] * [Square_Footage]) + [Param_Intercept]`
   - Calculated Field `[Residual_Error]`: `[Sale_Price] - [Predicted_Sale_Price]`
   - Calculated Field `[Absolute_Residual]`: `ABS([Residual_Error])`
   - Calculated Field `[Squared_Residual]`: `([Residual_Error]) ^ 2`
4. **Step 4: Diagnostic Sheet 1 — Residual vs. Fitted (Homoscedasticity Check)**:
   - Drag `[Predicted_Sale_Price]` to Columns, `[Residual_Error]` to Rows. Uncheck Aggregate Measures.
   - Analytics tab $\rightarrow$ Add **Constant Line** at `0.0` (dashed red line).
   - *Diagnostic Rule*: Points randomly scattered around zero indicate valid **homoscedasticity**. If the spread expands into a cone shape, **heteroscedasticity** is present.
5. **Step 5: Diagnostic Sheet 2 — Residual Normality Histogram**:
   - Right-click `[Residual_Error]` $\rightarrow$ Create $\rightarrow$ Bins (Size = `5000`).
   - Drag `[Residual_Error (bin)]` to Columns, `COUNT([Property_ID])` to Rows.
   - Verify errors form a symmetric, zero-mean bell curve.
6. **Step 6: Regression KPI Metrics**:
   - `[MAE_Metric]`: `AVG([Absolute_Residual])`
   - `[RMSE_Metric]`: `SQRT(AVG([Squared_Residual]))`

---

<a name="tableau-calculated-fields"></a>
### 6. Master Calculated Fields Cheat Sheet

| Task | Tableau Calculated Field Expression | Notes |
| :--- | :--- | :--- |
| **Missing Imputation (Numeric)** | `ZN([Metric])` or `IFNULL([Metric], {FIXED : MEDIAN([Metric])})` | Replaces nulls with 0 or dataset median |
| **Missing Imputation (String)** | `IFNULL([Category], "Missing / Unspecified")` | Prevents filter drops |
| **Z-Score Normalization** | `([Value] - {FIXED : AVG([Value])}) / {FIXED : STDEV([Value])}` | Scales mean to 0, std to 1 |
| **Min-Max Normalization** | `([Value] - {FIXED : MIN([Value])}) / ({FIXED : MAX([Value])} - {FIXED : MIN([Value])})` | Bounds data strictly in $[0, 1]$ |
| **Tukey IQR Outlier Flag** | `IF [Value] < {FIXED : PERCENTILE([Value], 0.25)} - 1.5 * ({FIXED : PERCENTILE([Value], 0.75)} - {FIXED : PERCENTILE([Value], 0.25)}) OR [Value] > {FIXED : PERCENTILE([Value], 0.75)} + 1.5 * ({FIXED : PERCENTILE([Value], 0.75)} - {FIXED : PERCENTILE([Value], 0.25)}) THEN "Outlier" ELSE "Inlier" END` | Flags 1.5x IQR outliers |
| **Custom Equal-Freq Quantile** | `IF [Value] <= {FIXED : PERCENTILE([Value], 0.25)} THEN "Q1" ELSEIF [Value] <= {FIXED : PERCENTILE([Value], 0.50)} THEN "Q2" ELSEIF [Value] <= {FIXED : PERCENTILE([Value], 0.75)} THEN "Q3" ELSE "Q4" END` | Creates 4 equal-count groups |
| **Model Classification Accuracy**| `SUM(IIF([Actual] = [Predicted], 1, 0)) / COUNT([ID])` | Proportion of correct predictions |
| **Model Precision** | `SUM(IIF([Actual] = "1" AND [Predicted] = "1", 1, 0)) / NULLIF(SUM(IIF([Predicted] = "1", 1, 0)), 0)` | Positive predictive value |
| **Model Recall** | `SUM(IIF([Actual] = "1" AND [Predicted] = "1", 1, 0)) / NULLIF(SUM(IIF([Actual] = "1", 0)), 0)` | True positive rate (Sensitivity) |
| **Model F1-Score** | `2 * (([Precision] * [Recall]) / NULLIF(([Precision] + [Recall]), 0))` | Harmonic mean of Precision and Recall |
| **Regression Residual** | `[Actual_Y] - [Predicted_Y]` | Raw deviation |
| **Regression RMSE** | `SQRT(AVG(([Actual_Y] - [Predicted_Y]) ^ 2))` | Root Mean Squared Error |

---

<a name="tableau-dashboard-assembly"></a>
### 7. Interactive Dashboard Assembly & Action Filters

1. At bottom tab bar, click **New Dashboard** (four squares icon).
2. Set Size to **Fixed (1920 x 1080)** or **Automatic**.
3. Drag a **Horizontal Container** to top of canvas for KPI BAN cards.
4. Drag your KPI sheets (`Accuracy`, `Precision`, `Recall`, `F1`) side-by-side into this container.
5. Drag a **Vertical Container** below the KPIs.
6. Drag your Confusion Matrix / Scatter Plot and Residual Histogram into the vertical container.
7. Show Parameters: Click container menu $\rightarrow$ **Parameters** $\rightarrow$ Check **`Classification_Threshold`**.
8. **Add Interactive Filter Actions**:
   - Menu: **Dashboard** $\rightarrow$ **Actions...** $\rightarrow$ **Add Action** $\rightarrow$ **Filter...**.
   - *Source Sheets*: Check Confusion Matrix.
   - *Run action on*: **Select** (click).
   - *Target Sheets*: Check KPI cards and Diagnostic Scatter sheets.
   - *Clearing selection*: **Show all values**. Click **OK**.
9. Clicking any quadrant (e.g. "False Positive") instantly filters the scatter plot to inspect those specific customers!

---

<a name="tableau-viva"></a>
### 8. Tableau Lab Exam & Viva Quick Reference

| Viva Question | Correct Academic / Tool Answer |
| :--- | :--- |
| **Blue Pill vs Green Pill?** | Blue means **Discrete** (creates row/column headers and categorizes); Green means **Continuous** (creates unbroken numeric/temporal axes). |
| **Dimension vs Measure?** | Dimensions are qualitative categorical attributes setting the Level of Detail; Measures are quantitative numerical fields aggregated via `SUM`, `AVG`, etc. |
| **What does `{FIXED}` do in LOD?** | Computes aggregations at the specified dimension level independent of any sheet filters or active visualization dimensions. |
| **How to create a Donut Chart in Tableau?** | Build a Pie chart, place `AVG(0)` on Rows twice, set Dual Axis, change second mark to white Circle, and label the center hole. |
| **How to build a Histogram in Tableau?** | Right-click Measure $\rightarrow$ Create Bins. Place Bin dimension on Columns, and Measure (`Count`) on Rows. |
| **How to remove aggregation in scatter plots?** | Top menu: Uncheck **Analysis $\rightarrow$ Aggregate Measures** (or drag row ID to Detail). |
