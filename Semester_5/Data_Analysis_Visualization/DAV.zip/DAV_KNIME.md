# 3CS103ME24: Data Analysis and Visualisation (DAV)
# Module 3: KNIME Analytics Platform Lab Manual & Complete Flows

*Designed for B.Tech Computer Science DAV Lab Exams, Vivas, and Term Submissions.*  
*Contains node architecture, port conventions, and complete step-by-step click guides with Mermaid flowcharts for all major lab tasks.*

---

## Table of Contents
1. [KNIME Core Architecture & Traffic Lights](#knime-architecture)
2. [Complete Flow 1: Data Processing, Outliers & Discretization](#knime-flow-processing)
3. [Complete Flow 2: Supervised Classification & Diagnostics (Churn Example)](#knime-flow-classification)
4. [Complete Flow 3: Regression Techniques & Residual Diagnostics (Housing Example)](#knime-flow-regression)
5. [Complete Flow 4: PCA & Feature Selection (Practical 6)](#knime-flow-pca)
6. [Complete Flow 5: Unsupervised K-Means Clustering & Validation (Practical 8)](#knime-flow-clustering)
7. [KNIME Lab Exam & Viva Master Quick Reference](#knime-viva)

---

<a name="knime-architecture"></a>
### 1. KNIME Core Architecture & Traffic Lights

- **Node Traffic Light Execution States**:
  - 🔴 **Red**: Unconfigured node. File path missing, columns unassigned, or parameters invalid.
  - 🟡 **Yellow**: Configured and ready to execute. All parameters set.
  - 🟢 **Green**: Executed successfully. Data or model ready at the output port.
  - ❌ **Red with X**: Execution error (e.g. data type mismatch, file not found, memory limit).
- **Port Types**:
  - **Black Triangle (▶)**: Standard data table (rows and columns).
  - **Blue Square (■)**: Trained Machine Learning Model port (passed from `Learner` to `Predictor`, or from `Normalizer` to `Normalizer Apply`).
  - **Red Circle (●)**: Flow variables port.
  - **Brown Cylinder**: Database connection / SQL port.
- **Essential Keyboard Shortcuts**:
  - **F7**: Execute selected node(s).
  - **F8**: Execute all executable nodes downstream.
  - **F9**: Reset selected node(s) back to yellow state.
  - **Double Click**: Open node configuration dialog.

---

<a name="knime-flow-processing"></a>
### 2. Complete Flow 1: Data Processing, Outliers & Discretization

#### Concrete Dataset Scenario: `raw_messy_customer_data.csv`
- `Cust_ID`: Alpha-numeric identifier (`"CUST-00921"`).
- `Age`: Numeric with missing values (`NaN`) and erroneous negative entries (`-8`, `150`).
- `Annual_Income`: Numeric with missing values and severe positive outliers (`$2,500,000` vs median `$60,000`).
- `Gender`: Inconsistent strings (`"M"`, `"Male"`, `"male"`, `"F"`, `"Female"`, `"female"`, `"?"`).
- `Department`: Padded strings with whitespace (`"  Sales  "`, `" Marketing "`).
- `Credit_Score`: Integer range ($300$ to $850$).
- `Purchase_Frequency`: Numeric transactions per quarter.

#### End-to-End Architecture Workflow:

```mermaid
flowchart TD
    A[CSV Reader: Ingest Messy Data] --> B[Missing Value: Median & Mode Imputation]
    B --> C[String Manipulation: Trim Whitespace]
    C --> D[Rule Engine: Standardize Categorical Labels]
    D --> E[Numeric Outliers: Detect & Treat 1.5x IQR Fences]
    E --> F[Normalizer: Min-Max & Z-Score Scaling]
    F --> G[Auto-Binner: Equal-Width & Equal-Frequency Discretization]
    G --> H[Row Filter: Exclude Invalid Records Age < 18]
    H --> I[Column Filter: Drop Raw & Intermediate Features]
    I --> J[Clean Output Table: Data View & Verification]
```

#### Detailed Step-by-Step Node Configuration:

1. **Step 1: Data Ingestion (`CSV Reader`)**:
   - Drag `CSV Reader` onto canvas.
   - Point file path to `raw_messy_customer_data.csv`.
   - In Settings: Check **"Has column header"**.
   - Quote support: Ensure quote character `"` is set to handle commas in strings.
   - Press **F7** to execute 🟢.
2. **Step 2: Handle Missing Data (`Missing Value`)**:
   - Connect `CSV Reader` to `Missing Value`.
   - Double-click to configure:
     - **Default tab**:
       - *Number (Double)* $\rightarrow$ **Median** (median is immune to `$2,500,000` skew; mean would corrupt baseline).
       - *Number (Integer)* $\rightarrow$ **Median**.
       - *String* $\rightarrow$ **Most Frequent Value (Mode)** or fixed text `"Unknown"`.
     - **Individual tab**:
       - `Department` $\rightarrow$ set to fixed text `"General"`.
     - Click **OK** $\rightarrow$ Execute (F7).
3. **Step 3: Text Cleaning (`String Manipulation`)**:
   - Connect to `String Manipulation`.
   - Expression: `strip($Department$)`
   - Check **"Replace Existing Column"** $\rightarrow$ Select `Department`.
   - Click **OK** $\rightarrow$ Execute (F7).
4. **Step 4: Standardize Categories (`Rule Engine`)**:
   - Connect to `Rule Engine`. Double-click to define matching rules:
     ```knime
     $Gender$ LIKE "M*" OR $Gender$ LIKE "m*" => "Male"
     $Gender$ LIKE "F*" OR $Gender$ LIKE "f*" => "Female"
     TRUE => "Other"
     ```
   - Check **"Replace Existing Column"** $\rightarrow$ Select `Gender`. Click **OK** $\rightarrow$ Execute (F7).
5. **Step 5: Outlier Detection & Treatment (`Numeric Outliers`)**:
   - Connect to `Numeric Outliers` node (*Data Manipulation* $\rightarrow$ *Row* $\rightarrow$ *Filter*).
   - Configure:
     - Target column: `Annual_Income`.
     - **Outlier estimation**: **IQR (Interquartile Range)**.
     - **IQR multiplier**: `1.5` (Standard Tukey Fence).
     - **Treatment option**: Select **"Replace outlier values"** (Winsorization: caps values at upper fence $Q_3 + 1.5 \times IQR$, retaining sample size without variance explosion).
     - Click **OK** $\rightarrow$ Execute (F7).
6. **Step 6: Feature Normalization (`Normalizer`)**:
   - Connect to `Normalizer`.
   - Configure:
     - **Min-Max Normalization**: Scales features to $[0.0, 1.0]$. Select `Credit_Score`.
     - (Alternative: Use **Z-Score Normalization** on `Annual_Income` to scale $\mu = 0, \sigma = 1$).
     - *Key Note*: Top black triangle outputs scaled table; bottom blue square is the Normalization Model (connect to `Normalizer Apply` for test sets).
     - Click **OK** $\rightarrow$ Execute (F7).
7. **Step 7: Discretization & Binning (`Auto-Binner`)**:
   - Connect to `Auto-Binner`.
   - Configure:
     - **Age $\rightarrow$ Equal-Width**: Method = **Equal width**, Number of bins = `4`, Naming = Borders ($[18, 35), [35, 50), [50, 65), [65, 100]$).
     - **Annual_Income $\rightarrow$ Equal-Frequency**: Method = **Sample quantiles (Equal frequency)**, Number of bins = `4` (Quartiles $Q_1, Q_2, Q_3, Q_4$). Guarantees exactly 25% of customers in each bin.
     - Click **OK** $\rightarrow$ Execute (F7).
8. **Step 8: Filter Boundary Rows (`Row Filter`)**:
   - Connect to `Row Filter`.
   - Column: `Age` $\rightarrow$ Range checking: Lower = `18`, Upper = `100`. Include rows by attribute value (drops corrupt noise like `-8` or `150`).
   - Click **OK** $\rightarrow$ Execute (F7).
9. **Step 9: Column Selection (`Column Filter`)**:
   - Connect to `Column Filter`. Exclude raw messy columns (`Cust_ID`, raw calculations). Keep clean modeling attributes.
10. **Step 10: Final Table Inspection**:
    - Right-click `Column Filter` $\rightarrow$ View **Filtered Table**. Confirm 0 missing values, standardized categories, and properly normalized numeric bounds.

---

<a name="knime-flow-classification"></a>
### 3. Complete Flow 2: Supervised Classification & Diagnostics (Churn Example)

#### Concrete Dataset Scenario: `customer_churn_classification.csv`
- `CustomerID`: Unique string key.
- `Tenure_Months`: Integer ($1$ to $72$).
- `MonthlyCharges`: Numeric continuous float.
- `TotalCharges`: Numeric float (with occasional missing blanks).
- `ContractType`: Categorical (`"Month-to-month"`, `"One year"`, `"Two year"`).
- `TechSupport`: Categorical (`"Yes"`, `"No"`, `"No internet"`).
- `Churn`: Target class label (`"Yes"`, `"No"`; 75% No, 25% Yes — class imbalanced!).

#### End-to-End Architecture Workflow:

```mermaid
flowchart TD
    A[CSV Reader: Ingest Data] --> B[Missing Value: Median & Mode Imputation]
    B --> C[Number to String: Target Column Encoding]
    C --> D[Partitioning: 80% Train / 20% Test Stratified]
    
    subgraph Training Pipeline [Training & Oversampling]
        D -- 80% Train Port --> E[SMOTE: Synthetic Minority Oversampling]
        E --> F1[Decision Tree Learner]
        E --> F2[Random Forest Learner]
    end
    
    subgraph Testing & Prediction [Unseen Test Evaluation]
        D -- 20% Test Port --> G1[Decision Tree Predictor]
        D -- 20% Test Port --> G2[Random Forest Predictor]
        F1 -- Blue Model Port --> G1
        F2 -- Blue Model Port --> G2
    end
    
    subgraph Model Diagnostics & Comparison [Evaluation]
        G1 --> H1[Scorer: DT Confusion Matrix & F1]
        G2 --> H2[Scorer: RF Confusion Matrix & F1]
        G1 --> I[ROC Curve: Multi-Model AUC Comparison]
        G2 --> I
    end
```

#### Detailed Step-by-Step Node Configuration:

1. **Step 1: Ingestion (`CSV Reader`)**: Load `customer_churn_classification.csv`. Ensure column header is checked. Execute (F7) 🟢.
2. **Step 2: Clean Data (`Missing Value`)**: Number $\rightarrow$ Median; String $\rightarrow$ Mode.
3. **Step 3: Ensure Categorical Target (`Number To String`)**: Classification in KNIME requires nominal targets. Ensure `Churn` is String type.
4. **Step 4: Train/Test Split (`Partitioning`)**:
   - Relative: `80%`.
   - **Sampling method**: **Stratified sampling** $\rightarrow$ select `Churn` column.
   - *Why this is mandatory*: With 75:25 imbalance, stratified sampling guarantees both train and test partitions maintain identical 25% churn rates.
5. **Step 5: Class Rebalancing (`SMOTE` Node)**:
   - Connect **top 80% Train port** to `SMOTE`.
   - *Crucial Rule*: Never apply SMOTE before Partitioning! Oversampling the test partition causes data leakage and invalid inflated test accuracy.
   - Class column: `Churn`, Oversample class: `"Yes"`, Nearest neighbors $k = 5$. Balance ratio to 50:50.
6. **Step 6: Train Baseline Model (`Decision Tree Learner`)**:
   - Connect `SMOTE` output to `Decision Tree Learner`.
   - Class column: `Churn`. Quality measure: `Gini Index` or `Gain Ratio`.
   - Pruning: **MDL** (Minimum Description Length) or **Reduced error pruning** to prevent overfitting.
   - Min number of records per node: `10`. Execute (F7).
   - Right-click $\rightarrow$ **View: Decision Tree View** to explore rules.
7. **Step 7: Train Ensemble Benchmark (`Random Forest Learner`)**:
   - Connect `SMOTE` output to `Random Forest Learner`.
   - Target column: `Churn`, Number of trees = `100`, Split criterion = `Information Gain Ratio`. Execute (F7).
8. **Step 8: Generate Test Predictions (`Predictor` Nodes)**:
   - For `Decision Tree Predictor`:
     - Top input: Connect `Decision Tree Learner` blue model port.
     - Bottom input: Connect `Partitioning` **bottom 20% test data port**.
     - Check: **"Append columns with predicted probabilities"**.
   - For `Random Forest Predictor`:
     - Connect model port and 20% test port. Check **"Append individual class probabilities"**.
   - Execute both. Tables append `Prediction (Churn)`, `P(Churn=Yes)`, and `P(Churn=No)`.
9. **Step 9: Diagnostics & Confusion Matrix (`Scorer` Node)**:
   - Drag two `Scorer` nodes. Connect Predictor 1 to Scorer 1, and Predictor 2 to Scorer 2.
   - First column: `Churn` (actual). Second column: `Prediction (Churn)`.
   - Right-click Scorer $\rightarrow$ **View: Confusion Matrix** (TP, FP, TN, FN).
   - Right-click Scorer $\rightarrow$ **View: Class Statistics** (Accuracy, Precision, Recall, $F_1$-Measure, Cohen's Kappa).
10. **Step 10: Multi-Model ROC Analysis (`ROC Curve`)**:
    - Connect Predictors to `ROC Curve` node.
    - Class column: `Churn`, Positive class: `"Yes"`.
    - Include probability columns: `P(Churn=Yes)` from both models.
    - Right-click $\rightarrow$ **Interactive View: ROC Curve**: Compare curves and read the **Area Under the Curve (AUC)** score (e.g. $AUC_{RF} = 0.88$ vs $AUC_{DT} = 0.79$).

---

<a name="knime-flow-regression"></a>
### 4. Complete Flow 3: Regression Techniques & Residual Diagnostics (Housing Example)

#### Concrete Dataset Scenario: `real_estate_house_pricing.csv`
- `Property_ID`: Identifier string.
- `SquareFootage`: Continuous predictor ($X_1$).
- `Bedrooms`: Discrete numeric ($X_2$).
- `Bathrooms`: Discrete numeric ($X_3$).
- `DistanceToMetro`: Continuous distance in km ($X_4$).
- `BuildingAge`: Age of building in years ($X_5$).
- `SalePrice`: Continuous target variable ($Y$, e.g. $150,000 to $850,000).

#### End-to-End Architecture Workflow:

```mermaid
flowchart TD
    A[CSV Reader: Ingest Data] --> B[Missing Value: Median Imputation]
    B --> C[Normalizer: Z-Score Standardization]
    C --> D[Partitioning: 80% Train / 20% Test Split]
    
    subgraph Model Training [Training Phase]
        D -- 80% Train Port --> E1[Linear Regression Learner]
        D -- 80% Train Port --> E2[Random Forest Regressor]
    end
    
    subgraph Test Set Inference [Inference Phase]
        D -- 20% Test Port --> F1[Regression Predictor: Linear]
        D -- 20% Test Port --> F2[Regression Predictor: RF]
        E1 -- Blue Model Port --> F1
        E2 -- Blue Model Port --> F2
    end
    
    subgraph Error Evaluation & Diagnostics [Diagnostics Phase]
        F1 --> G1[Numeric Scorer: R2, MAE, RMSE]
        F2 --> G2[Numeric Scorer: RF Comparison]
        F1 --> H[Math Formula: Compute Residuals]
        H --> I1[Scatter Plot: Residuals vs Predicted]
        H --> I2[Histogram: Normality of Errors]
    end
```

#### Detailed Step-by-Step Node Configuration:

1. **Step 1: Data Ingestion (`CSV Reader`)**: Load `real_estate_house_pricing.csv`. Verify double/integer types. Execute (F7) 🟢.
2. **Step 2: Missing Value Imputation (`Missing Value`)**: Number $\rightarrow$ **Median** (immune to skewed property prices).
3. **Step 3: Feature Scaling (`Normalizer`)**:
   - Z-Score Normalization (Gaussian) on all numerical predictors.
   - *Why this is essential*: Standardizing allows direct comparison of regression coefficients ($\beta$) to measure relative feature influence.
4. **Step 4: Train/Test Split (`Partitioning`)**:
   - Relative: `80%`. Sampling: Random sampling with fixed seed `42`.
   - Top port emits 80% Train rows; bottom port emits 20% Test rows.
5. **Step 5: Train Parametric Model (`Linear Regression Learner`)**:
   - Connect **top 80% Train port** to `Linear Regression Learner`.
   - Target column: `SalePrice`.
   - Include columns: `SquareFootage`, `Bedrooms`, `Bathrooms`, `DistanceToMetro`, `BuildingAge`.
   - Check **"Calculate coefficient statistics"** ($t$-statistic, standard error, $p$-values).
   - Right-click $\rightarrow$ **View: Linear Regression Result View**: Features with $p < 0.05$ are statistically significant.
6. **Step 6: Train Non-Parametric Benchmark (`Random Forest Regressor`)**:
   - Connect 80% Train port to `Random Forest Regressor`. Target: `SalePrice`, Trees = `100`. Execute (F7).
7. **Step 7: Predict on Unseen Test Partition (`Regression Predictor`)**:
   - Drag two `Regression Predictor` nodes.
   - Predictor 1: Connect `Linear Regression Learner` model port + 20% Test port.
   - Predictor 2: Connect `Random Forest Regressor` model port + 20% Test port.
   - Execute both. Both tables append **`Prediction (SalePrice)`**.
8. **Step 8: Error Metric Calculation (`Numeric Scorer`)**:
   - Drag two `Numeric Scorer` nodes. Connect Predictor outputs.
   - Reference column: `SalePrice`. Predicted column: `Prediction (SalePrice)`.
   - Right-click $\rightarrow$ **View: Statistics**:
     - Read off $R^2$ (e.g. $0.842$), Mean Absolute Error ($MAE$), Mean Squared Error ($MSE$), Root Mean Squared Error ($RMSE$), and $MAPE$.
9. **Step 9: Compute Residuals (`Math Formula`)**:
   - Connect output of `Regression Predictor` (Linear Model) to `Math Formula`.
   - Expression:
     ```knime
     $SalePrice$ - $Prediction (SalePrice)$
     ```
   - Check **"Append New Column"** $\rightarrow$ Set name to **`Residual`**. Click **OK** $\rightarrow$ Execute (F7).
10. **Step 10: Regression Error Diagnostics Visualization**:
    - **A. Residual vs. Predicted Scatter Plot (Homoscedasticity Test)**:
      - Drag `Scatter Plot` node. $X$-axis: `Prediction (SalePrice)`, $Y$-axis: `Residual`.
      - *Diagnostic Rule*: Points must form an even horizontal band around zero. If scatter expands into a cone/funnel shape, heteroscedasticity is present (indicating need for log transformation).
    - **B. Normality of Residuals Histogram**:
      - Drag `Histogram` node. Column: `Residual`, Bins = `20`.
      - *Diagnostic Rule*: Verify errors follow a symmetric, zero-mean bell-shaped Gaussian distribution.

---

<a name="knime-flow-pca"></a>
### 5. Complete Flow 4: PCA & Feature Selection (Practical 6)

```mermaid
flowchart LR
    A[CSV Reader] --> B[Normalizer: Z-Score]
    B --> C[PCA Compute]
    C --> D[PCA Apply]
    B --> E[Low Variance Filter]
    E --> F[Correlation Filter]
```

1. **Step 1: Reading Data (`CSV Reader`)**: Point to dataset, ensure column header is checked, execute (F7).
2. **Step 2: Normalization (`Normalizer`)**:
   - PCA is highly sensitive to variable scales. Set to **Z-Score Normalization (Gaussian)**. Include all numeric features.
3. **Step 3: Dimensionality Reduction (`PCA Compute` & `PCA Apply`)**:
   - Connect `Normalizer` to `PCA Compute`. Set target components (e.g. $k=2$ or target variance $95\%$).
   - Drag `PCA Apply`. Connect `Normalizer` data port to top input; connect `PCA Compute` blue model port to bottom input.
   - Right-click `PCA Apply` $\rightarrow$ View **PCA Transformed Data** (features reduced to orthogonal Principal Components).
4. **Step 4: Feature Selection (`Low Variance Filter` & `Correlation Filter`)**:
   - Connect `Normalizer` to `Low Variance Filter` $\rightarrow$ Threshold: `0.01` (drops near-constant attributes).
   - Connect to `Correlation Filter` $\rightarrow$ Threshold: `0.85` (removes collinear redundant features). View **Filtered Table**.

---

<a name="knime-flow-clustering"></a>
### 6. Complete Flow 5: Unsupervised K-Means Clustering & Validation (Practical 8)

```mermaid
flowchart LR
    A[CSV Reader] --> B[Normalizer: Min-Max]
    B --> C[k-Means]
    C --> D[Color Manager]
    D --> E[Scatter Plot]
    C --> F[Silhouette Coefficient]
```

1. **Step 1: Normalization (`Normalizer`)**:
   - Euclidean distance in K-Means requires scaling. Apply **Min-Max [0, 1]** or **Z-Score Normalization**.
2. **Step 2: K-Means Clustering (`k-Means`)**:
   - Drag `k-Means` node onto canvas. Connect `Normalizer` output to it.
   - Configure: Set **Number of clusters ($k$)**: e.g., `3`. Max iterations: `100`. Include numeric attributes. Execute (F7).
3. **Step 3: Cluster Visualization (`Color Manager` & `Scatter Plot`)**:
   - Connect `k-Means` output table to `Color Manager`. Assign distinct colors to each cluster (`cluster_0`, `cluster_1`, `cluster_2`).
   - Connect to `Scatter Plot` $\rightarrow$ View separated cluster groups across principal dimensions.
4. **Step 4: Validation (`Silhouette Coefficient`)**:
   - Connect `k-Means` output to `Silhouette Coefficient` node.
   - Execute $\rightarrow$ View table: Check overall mean silhouette score (values near $+1.0$ indicate dense, well-separated clusters; values $\le 0$ indicate overlapping clusters).

---

<a name="knime-viva"></a>
### 7. KNIME Lab Exam & Viva Master Quick Reference

| Viva Question | Correct Academic / Tool Answer |
| :--- | :--- |
| **What do the 4 node colors mean?** | 🔴 Red = Unconfigured; 🟡 Yellow = Configured/Ready; 🟢 Green = Executed; ❌ Red with X = Error. |
| **Difference between black triangle and blue square ports?** | Black Triangle (▶) transmits a **Data Table**; Blue Square (■) transmits a **Trained Machine Learning Model** object. |
| **Where must SMOTE be placed in the workflow?** | Strictly on the **80% Training port** after the `Partitioning` node. Never before `Partitioning` (prevents data leakage). |
| **Why must target be Nominal for Decision Tree Learner?** | Classification algorithms require discrete string classes. Use `Number To String` if the target is coded as $0/1$. |
| **How to evaluate Regression in KNIME?** | Connect `Regression Predictor` to `Numeric Scorer`. Inspect $R^2$, MAE, MSE, and RMSE. |
| **How to check Homoscedasticity in KNIME?** | Compute residuals using `Math Formula` (`Actual - Predicted`), then connect to `Scatter Plot` ($X = \text{Predicted}, Y = \text{Residual}$). Points must form a uniform horizontal band. |
| **How to apply trained normalization to test data?** | Connect the blue model port from `Normalizer` into the model port of a `Normalizer Apply` node fed with test data. |
