# 3CS103ME24: Data Analysis and Visualisation (DAV)
# Module 2: Python Graphing Recipes (Student Level 2-3 Liners & Subplots)

*Designed specifically for 3rd-year B.Tech DAV Lab Exams, Vivas, and Practicals.*  
*Contains concise, 2-to-3 line standard implementations using `matplotlib.pyplot` and `seaborn` without unnecessary styling fluff, followed by essential Subplot grid patterns.*

---

## Table of Contents
1. [Quick Sample Dataset (For Running Examples)](#sample-data)
2. [The 7 Core Lab Graphs (2-3 Liners)](#core-graphs)
   - [1. Pie Chart & Donut Chart](#graph-pie)
   - [2. Bar Chart (Vertical, Horizontal, Clustered)](#graph-bar)
   - [3. Line Chart (Single & Multi-Line)](#graph-line)
   - [4. KPI Card / BAN (Big Ass Number)](#graph-kpi)
   - [5. Treemap](#graph-treemap)
   - [6. Box & Whisker Plot](#graph-box)
   - [7. Distribution Histogram](#graph-hist)
3. [Master Subplots Section (Multiple Graphs on One Canvas)](#subplots-section)
   - [Pattern A: 1x2 Side-by-Side Subplots](#subplot-1x2)
   - [Pattern B: 2x2 Grid Dashboard (Exam Favorite)](#subplot-2x2)
   - [Pattern C: `plt.subplot()` Sequential Indexing](#subplot-sequential)
   - [Pattern D: 1x3 Distribution Suite (Hist + Box + Density)](#subplot-1x3)
4. [Bonus Diagnostics: Correlation Heatmap & Residual Scatter](#bonus-diagnostics)

---

<a name="sample-data"></a>
### 1. Quick Sample Dataset (For Running Examples)

```python
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np

# Quick student dummy data
np.random.seed(42)
categories = ['Electronics', 'Clothing', 'Grocery', 'Books']
values = [450, 280, 320, 150]

df = pd.DataFrame({
    'Category': np.random.choice(categories, 100),
    'Segment': np.random.choice(['Consumer', 'Corporate'], 100),
    'Sales': np.random.normal(loc=200, scale=50, size=100),
    'Profit': np.random.normal(loc=40, scale=15, size=100)
})
```

---

<a name="core-graphs"></a>
### 2. The 7 Core Lab Graphs (2-3 Liners)

<a name="graph-pie"></a>
#### 1. Pie Chart & Donut Chart

```python
# --- Standard Pie Chart ---
plt.pie(values, labels=categories, autopct='%1.1f%%', startangle=90)
plt.title("Pie Chart")
plt.show()

# --- Donut Chart (2-liner using wedgeprops width) ---
plt.pie(values, labels=categories, autopct='%1.1f%%', wedgeprops={'width': 0.4})
plt.title("Donut Chart")
plt.show()
```

<a name="graph-bar"></a>
#### 2. Bar Chart (Vertical, Horizontal, Clustered)

```python
# --- Vertical Bar Chart ---
plt.bar(categories, values)
plt.title("Vertical Bar Chart")
plt.show()

# --- Horizontal Bar Chart ---
plt.barh(categories, values)
plt.title("Horizontal Bar Chart")
plt.show()

# --- Clustered / Side-by-Side Bar (Seaborn hue) ---
sns.barplot(data=df, x='Category', y='Sales', hue='Segment')
plt.title("Clustered Bar Chart")
plt.show()
```

<a name="graph-line"></a>
#### 3. Line Chart (Single & Multi-Line)

```python
# --- Single Time-Series Line ---
plt.plot(['Jan', 'Feb', 'Mar', 'Apr', 'May'], [10, 25, 18, 30, 42], marker='o')
plt.title("Line Chart")
plt.grid(True)
plt.show()

# --- Multi-Line Comparison (Seaborn) ---
sns.lineplot(data=df, x='Category', y='Sales', hue='Segment', marker='s')
plt.title("Multi-Line Trend")
plt.show()
```

<a name="graph-kpi"></a>
#### 4. KPI Card / BAN (Big Ass Number)

```python
# --- Simple Student KPI Card ---
plt.figure(figsize=(4, 2))
plt.text(0.5, 0.6, "$842,500", fontsize=24, weight='bold', ha='center')
plt.text(0.5, 0.3, "TOTAL REVENUE (+14.2% YoY)", fontsize=10, ha='center', color='green')
plt.axis('off')
plt.show()
```

<a name="graph-treemap"></a>
#### 5. Treemap

```python
# --- Treemap (squarify) ---
import squarify
squarify.plot(sizes=values, label=categories, alpha=0.8)
plt.axis('off')
plt.title("Treemap")
plt.show()
```

<a name="graph-box"></a>
#### 6. Box & Whisker Plot (With Outliers)

```python
# --- Boxplot with Category Grouping ---
sns.boxplot(data=df, x='Category', y='Sales')
plt.title("Box & Whisker Plot")
plt.show()
```

<a name="graph-hist"></a>
#### 7. Distribution Histogram

```python
# --- Histogram with KDE Curve ---
sns.histplot(df['Sales'], kde=True, bins=15)
plt.title("Distribution Histogram")
plt.show()
```

---

<a name="subplots-section"></a>
### 3. Master Subplots Section (Multiple Graphs on One Canvas)

In lab exams, examiners frequently ask: *"Plot multiple graphs side-by-side or on a 2x2 grid on a single figure window."*

---

<a name="subplot-1x2"></a>
#### Pattern A: 1x2 Side-by-Side Subplots (1 Row, 2 Columns)

```python
fig, axes = plt.subplots(1, 2, figsize=(10, 4))

# Left plot (index 0)
axes[0].bar(categories, values)
axes[0].set_title("Category Sales")

# Right plot (index 1)
axes[1].pie(values, labels=categories, autopct='%1.1f%%')
axes[1].set_title("Market Share")

plt.tight_layout()
plt.show()
```

---

<a name="subplot-2x2"></a>
#### Pattern B: 2x2 Grid Dashboard (Exam Master Recipe)
*Presents 4 core visualizations on one dashboard figure.*

```python
fig, axes = plt.subplots(2, 2, figsize=(10, 8))

# Top-Left [0, 0]: Bar Chart
axes[0, 0].bar(categories, values, color='skyblue')
axes[0, 0].set_title("Bar Chart: Category Sales")

# Top-Right [0, 1]: Line Chart
axes[0, 1].plot(categories, values, marker='o', color='green')
axes[0, 1].set_title("Line Chart: Trend")
axes[0, 1].grid(True)

# Bottom-Left [1, 0]: Histogram
sns.histplot(df['Sales'], kde=True, ax=axes[1, 0], color='orange')
axes[1, 0].set_title("Histogram: Sales Distribution")

# Bottom-Right [1, 1]: Boxplot
sns.boxplot(data=df, x='Category', y='Sales', ax=axes[1, 1], palette='pastel')
axes[1, 1].set_title("Boxplot: Outlier Detection")

plt.tight_layout()
plt.show()
```

---

<a name="subplot-sequential"></a>
#### Pattern C: Sequential Indexing with `plt.subplot(nrows, ncols, index)`
*Easiest way to write subplots quickly without indexing arrays!*

```python
plt.figure(figsize=(10, 4))

# Subplot 1 (Row 1, Col 2, Position 1)
plt.subplot(1, 2, 1)
plt.hist(df['Sales'], bins=10, color='purple', edgecolor='black')
plt.title("Sales Histogram")

# Subplot 2 (Row 1, Col 2, Position 2)
plt.subplot(1, 2, 2)
plt.boxplot(df['Sales'])
plt.title("Sales Boxplot")

plt.tight_layout()
plt.show()
```

---

<a name="subplot-1x3"></a>
#### Pattern D: 1x3 Distribution Suite (Hist + Box + Violin)
*Great for Practical 3 (outliers and distribution shape).*

```python
fig, axes = plt.subplots(1, 3, figsize=(12, 4))

# 1. Histogram
sns.histplot(df['Sales'], kde=True, ax=axes[0])
axes[0].set_title("1. Histogram with KDE")

# 2. Boxplot
sns.boxplot(y=df['Sales'], ax=axes[1], color='lightgreen')
axes[1].set_title("2. Boxplot (Outliers)")

# 3. Violin Plot
sns.violinplot(y=df['Sales'], ax=axes[2], color='pink')
axes[2].set_title("3. Violin Plot (Density)")

plt.tight_layout()
plt.show()
```

---

<a name="bonus-diagnostics"></a>
### 4. Bonus Diagnostics: Correlation Heatmap & Residual Scatter

```python
# --- Correlation Matrix Heatmap (2-liner) ---
sns.heatmap(df.select_dtypes(include=[np.number]).corr(), annot=True, cmap='coolwarm')
plt.title("Correlation Heatmap")
plt.show()

# --- Residual Diagnostic Scatter Plot (3-liner) ---
residuals = df['Sales'] - (df['Sales'] + np.random.normal(0, 10, len(df)))
plt.scatter(df['Sales'], residuals)
plt.axhline(0, color='red', linestyle='--')
plt.title("Residual vs. Fitted Plot")
plt.show()
```
