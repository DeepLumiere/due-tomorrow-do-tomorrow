# 3CS103ME24: Data Analysis and Visualisation (DAV)
# Module 2: Python Graphing Recipes (The 7 Core Lab Graphs)

*Designed for B.Tech Computer Science DAV Lab Exams, Vivas, and Term Submissions.*  
*Contains copy-paste runnable Python code using `matplotlib` and `seaborn` for the 7 primary lab visualizations, plus diagnostic plots and a synthetic dataset runner.*

---

## The 7 Core Lab Graphs
1. [Pie Chart & Donut Chart](#graph-1)
2. [Bar Chart (Vertical, Horizontal, Stacked, Clustered)](#graph-2)
3. [Line Chart (Time-Series & Multi-Line Trend)](#graph-3)
4. [KPI Card / BAN (Big Ass Number)](#graph-4)
5. [Treemap (Hierarchical Rectangles with Size and Color)](#graph-5)
6. [Box & Whisker Plot (With Outliers & Tukey Fences)](#graph-6)
7. [Distribution Histogram with KDE & Central Tendency Lines](#graph-7)
8. [Bonus: Correlation Matrix Heatmap & Residual Diagnostic Plot](#bonus-graphs)
9. [Complete Runnable Test Harness (Copy-Paste Test)](#runnable-test)

---

```python
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import pandas as pd
import matplotlib.patches as patches

# Aesthetic configuration
sns.set_theme(style="whitegrid", font="sans-serif")
plt.rcParams['font.size'] = 10
plt.rcParams['figure.autolayout'] = True
```

---

<a name="graph-1"></a>
### 1. Pie Chart & Donut Chart

#### A. Standard Pie Chart with Explode & Percentages
```python
def plot_pie_chart(categories, values, title="Market Share Breakdown"):
    """
    Standard Pie Chart with automatic slice explode for the top category,
    percentages, and drop shadow.
    """
    plt.figure(figsize=(7, 5))
    colors = sns.color_palette("pastel")[:len(categories)]
    
    # Explode largest slice slightly for emphasis
    max_idx = values.index(max(values)) if isinstance(values, list) else np.argmax(values)
    explode = [0.08 if i == max_idx else 0.0 for i in range(len(categories))]
    
    wedges, texts, autotexts = plt.pie(
        values,
        labels=categories,
        autopct='%1.1f%%',
        startangle=140,
        explode=explode,
        colors=colors,
        shadow=True,
        wedgeprops={'edgecolor': 'white', 'linewidth': 1.5}
    )
    for at in autotexts:
        at.set_fontsize(9)
        at.set_weight('bold')
        
    plt.title(title, fontsize=13, weight='bold')
    plt.show()
```

#### B. Professional Donut Chart (With White Center Cutout & Metric Callout)
```python
def plot_donut_chart(categories, values, center_text="Total\n$1.2M", title="Category Distribution"):
    """
    Professional Donut Chart with a center hole cutout and hero metric text.
    """
    plt.figure(figsize=(6, 6))
    colors = sns.color_palette("Set2")[:len(categories)]
    
    wedges, texts, autotexts = plt.pie(
        values,
        labels=categories,
        autopct='%1.1f%%',
        pctdistance=0.80,
        startangle=90,
        colors=colors,
        wedgeprops={'width': 0.35, 'edgecolor': 'white', 'linewidth': 2}
    )
    for at in autotexts:
        at.set_fontsize(9)
        at.set_weight('bold')
        
    # Central callout text
    plt.text(0, 0, center_text, ha='center', va='center', fontsize=12, weight='bold', color='#1F2937')
    plt.title(title, fontsize=13, weight='bold')
    plt.show()
```

---

<a name="graph-2"></a>
### 2. Bar Chart (Vertical, Horizontal, Stacked, Clustered)

#### A. Vertical Bar Chart with Direct Value Labels
```python
def plot_vertical_bar(df, cat_col, val_col):
    """Vertical bar chart with automated direct value labels on top of bars."""
    plt.figure(figsize=(8, 4.5))
    ax = sns.barplot(data=df, x=cat_col, y=val_col, palette="Blues_d")
    for p in ax.patches:
        ax.annotate(f"{p.get_height():,.0f}",
                    (p.get_x() + p.get_width() / 2., p.get_height()),
                    ha='center', va='bottom', fontsize=9, xytext=(0, 3),
                    textcoords='offset points')
    plt.title(f"{val_col} by {cat_col}", fontsize=12, weight='bold')
    plt.xlabel(cat_col); plt.ylabel(val_col)
    plt.show()
```

#### B. Horizontal Sorted Bar Chart (Best for Long Labels)
```python
def plot_horizontal_bar_sorted(df, cat_col, val_col):
    """Horizontal sorted bar chart to prevent overlapping category labels."""
    sorted_df = df.sort_values(by=val_col, ascending=True)
    plt.figure(figsize=(8, 5))
    ax = plt.barh(sorted_df[cat_col], sorted_df[val_col], color='teal', edgecolor='black', alpha=0.8)
    plt.bar_label(ax, fmt='{:,.0f}', padding=4)
    plt.title(f"Ranked {val_col} by {cat_col}", fontsize=12, weight='bold')
    plt.xlabel(val_col); plt.ylabel(cat_col)
    plt.show()
```

#### C. Stacked Bar Chart (Part-to-Whole Composition)
```python
def plot_stacked_bar(df_crosstab, title="Stacked Composition by Category"):
    """
    Stacked Bar Chart. Takes a pandas crosstab / pivot table:
    Example: df_crosstab = pd.crosstab(df['Region'], df['Product_Tier'], values=df['Sales'], aggfunc='sum')
    """
    ax = df_crosstab.plot(kind='bar', stacked=True, figsize=(8, 5), colormap='viridis', edgecolor='white')
    plt.title(title, fontsize=12, weight='bold')
    plt.ylabel("Cumulative Total"); plt.xticks(rotation=0)
    plt.legend(title="Sub-Group", bbox_to_anchor=(1.05, 1), loc='upper left')
    plt.show()
```

#### D. Clustered / Side-by-Side Bar Chart
```python
def plot_clustered_bar(df, cat_col, hue_col, val_col):
    """Clustered / Side-by-Side Bar Chart for multi-variable comparisons."""
    plt.figure(figsize=(9, 5))
    sns.barplot(data=df, x=cat_col, y=val_col, hue=hue_col, palette="Set1")
    plt.title(f"{val_col} Comparison across {cat_col} and {hue_col}", fontsize=12, weight='bold')
    plt.legend(title=hue_col); plt.show()
```

---

<a name="graph-3"></a>
### 3. Line Chart (Time-Series & Multi-Line Trend)

#### A. Single Time-Series Line with Shaded Area
```python
def plot_time_series_line(dates, values, label="Sales Trend"):
    """Single continuous time-series line with markers, grid, and soft area fill."""
    plt.figure(figsize=(9, 4.5))
    plt.plot(dates, values, marker='o', linewidth=2.2, color='#2563EB', label=label)
    plt.fill_between(dates, values, color='#93C5FD', alpha=0.25)
    plt.title(f"{label} Over Time", fontsize=12, weight='bold')
    plt.xlabel("Timeline"); plt.ylabel("Metric Value")
    plt.xticks(rotation=30)
    plt.grid(True, linestyle='--', alpha=0.5)
    plt.legend(); plt.show()
```

#### B. Multi-Line Comparative Trend
```python
def plot_multi_line_trend(df, date_col, val_col, group_col):
    """Multi-line comparative trend plot with automatic color palette and legend."""
    plt.figure(figsize=(10, 5))
    sns.lineplot(data=df, x=date_col, y=val_col, hue=group_col, marker='s', linewidth=2)
    plt.title(f"{val_col} Trend Grouped by {group_col}", fontsize=12, weight='bold')
    plt.xticks(rotation=30); plt.grid(True, linestyle='--', alpha=0.5)
    plt.show()
```

---

<a name="graph-4"></a>
### 4. KPI Card / BAN (Big Ass Number Card)
```python
def plot_kpi_card(title="TOTAL REVENUE", value="$842,500", delta="+12.4% vs last period", positive=True):
    """
    Renders an executive KPI Card (BAN) as a standalone visual card.
    """
    fig, ax = plt.subplots(figsize=(4, 2.5), dpi=100)
    ax.axis('off')
    
    # Outer Card Background with Rounded Box
    rect = patches.FancyBboxPatch(
        (0.05, 0.05), 0.90, 0.90,
        boxstyle="round,pad=0.04,rounding_size=0.08",
        ec="#E5E7EB", fc="#F9FAFB", lw=1.5
    )
    ax.add_patch(rect)
    
    # Title Subheading
    ax.text(0.12, 0.72, title.upper(), fontsize=9, weight='bold', color="#6B7280", transform=ax.transAxes)
    
    # Hero KPI Value
    ax.text(0.12, 0.40, value, fontsize=22, weight='heavy', color="#111827", transform=ax.transAxes)
    
    # Delta Badge
    delta_color = "#16A34A" if positive else "#DC2626"
    arrow = "▲" if positive else "▼"
    ax.text(0.12, 0.20, f"{arrow} {delta}", fontsize=9, weight='semibold', color=delta_color, transform=ax.transAxes)
    
    plt.show()
```

---

<a name="graph-5"></a>
### 5. Treemap (Hierarchical Rectangles with Size and Color)
```python
def plot_treemap(labels, sizes, title="Hierarchical Treemap"):
    """
    Hierarchical Treemap using squarify.
    Install squarify if needed: pip install squarify
    """
    try:
        import squarify
        plt.figure(figsize=(9, 6))
        
        norm = plt.Normalize(min(sizes), max(sizes))
        colors = [plt.cm.Blues(norm(value)) for value in sizes]
        
        formatted_labels = [f"{lbl}\n{val:,.0f}" for lbl, val in zip(labels, sizes)]
        squarify.plot(sizes=sizes, label=formatted_labels, color=colors, alpha=0.85,
                      text_kwargs={'fontsize': 10, 'weight': 'bold'}, edgecolor="white", linewidth=2)
        plt.title(title, fontsize=13, weight='bold')
        plt.axis('off')
        plt.show()
    except ImportError:
        print("Note: Run `pip install squarify` to render Treemaps.")
```

---

<a name="graph-6"></a>
### 6. Box & Whisker Plot (With Outliers & Tukey Fences)
```python
def plot_boxplot_with_fences(df, cat_col, val_col):
    """
    Boxplot showing Median, IQR Box, Whiskers at 1.5x IQR, and Outlier Dots.
    """
    plt.figure(figsize=(8, 5))
    ax = sns.boxplot(
        data=df, x=cat_col, y=val_col,
        palette="light:#597dbf",
        showmeans=True,
        meanprops={"marker": "^", "markerfacecolor": "yellow", "markeredgecolor": "black", "markersize": "7"},
        flierprops={"marker": "D", "markerfacecolor": "crimson", "markeredgecolor": "black", "markersize": 6}
    )
    plt.title(f"Box & Whisker Distribution: {val_col} by {cat_col}", fontsize=12, weight='bold')
    plt.xlabel(cat_col); plt.ylabel(val_col)
    plt.show()
```

---

<a name="graph-7"></a>
### 7. Distribution Histogram with KDE & Central Tendency Lines
```python
def plot_histogram_with_stats(df, col, bins=25):
    """
    Histogram with continuous KDE curve, Mean line (red dashed), and Median line (green solid).
    """
    plt.figure(figsize=(8, 4.5))
    clean_series = df[col].dropna()
    mean_val = clean_series.mean()
    median_val = clean_series.median()
    
    sns.histplot(clean_series, kde=True, bins=bins, color='#3B82F6', edgecolor='white', alpha=0.7)
    plt.axvline(mean_val, color='crimson', linestyle='--', linewidth=2, label=f'Mean: {mean_val:.2f}')
    plt.axvline(median_val, color='green', linestyle='-', linewidth=2, label=f'Median: {median_val:.2f}')
    
    plt.title(f"Distribution & Density of {col}", fontsize=12, weight='bold')
    plt.xlabel(col); plt.ylabel("Frequency Count")
    plt.legend(frameon=True)
    plt.show()
```

---

<a name="bonus-graphs"></a>
### 8. Bonus: Correlation Matrix Heatmap & Residual Diagnostic Plot

#### A. Lower-Triangle Correlation Heatmap
```python
def plot_correlation_heatmap(df):
    """Lower triangle correlation heatmap for numerical attributes."""
    plt.figure(figsize=(8, 6))
    corr = df.select_dtypes(include=[np.number]).corr()
    mask = np.triu(np.ones_like(corr, dtype=bool))
    sns.heatmap(corr, mask=mask, annot=True, fmt=".2f", cmap="vlag", vmin=-1, vmax=1,
                linewidths=0.5, cbar_kws={"shrink": 0.8})
    plt.title("Correlation Matrix Heatmap", fontsize=12, weight='bold')
    plt.show()
```

#### B. Residual vs. Fitted Scatter Plot (Homoscedasticity Check)
```python
def plot_residuals(y_true, y_pred):
    """Regression diagnostic: Residual vs Fitted scatter plot."""
    residuals = np.array(y_true) - np.array(y_pred)
    plt.figure(figsize=(7, 4.5))
    plt.scatter(y_pred, residuals, alpha=0.6, color='#8B5CF6', edgecolors='k', s=35)
    plt.axhline(0, color='crimson', linestyle='--', linewidth=1.8, label="Zero Error Baseline")
    plt.xlabel("Fitted / Predicted Values"); plt.ylabel("Residuals (y - ŷ)")
    plt.title("Residual vs. Fitted Plot (Homoscedasticity Check)", fontsize=12, weight='bold')
    plt.legend(); plt.show()
```

---

<a name="runnable-test"></a>
### 9. Complete Runnable Test Harness (Copy-Paste Test)
*Run this code block to verify all 7 graphs on synthetic test data!*

```python
if __name__ == "__main__":
    print("Executing DAV Graphing Suite...")
    
    # 1. Synthetic Data Creation
    np.random.seed(42)
    categories = ['Electronics', 'Clothing', 'Home & Kitchen', 'Books', 'Toys']
    sales_values = [45000, 28000, 32000, 15000, 12000]
    
    df_sample = pd.DataFrame({
        'Category': np.random.choice(categories, 200),
        'Segment': np.random.choice(['Consumer', 'Corporate', 'Home Office'], 200),
        'Sales': np.random.exponential(scale=500, size=200) + 50,
        'Profit': np.random.normal(loc=100, scale=40, size=200),
        'Rating': np.random.uniform(1.0, 5.0, size=200)
    })
    dates = pd.date_range(start='2024-01-01', periods=12, freq='M').strftime('%b %Y').tolist()
    monthly_revenue = [12000, 14500, 13800, 16200, 17500, 19000, 18200, 21000, 22500, 24000, 26500, 28000]

    # 1. Pie & Donut
    plot_pie_chart(categories, sales_values)
    plot_donut_chart(categories, sales_values, center_text="Total\n$132,000")

    # 2. Bar Charts
    plot_vertical_bar(df_sample.groupby('Category', as_index=False)['Sales'].sum(), 'Category', 'Sales')
    plot_horizontal_bar_sorted(df_sample.groupby('Category', as_index=False)['Sales'].sum(), 'Category', 'Sales')
    
    crosstab_df = pd.crosstab(df_sample['Category'], df_sample['Segment'], values=df_sample['Sales'], aggfunc='sum').fillna(0)
    plot_stacked_bar(crosstab_df)
    plot_clustered_bar(df_sample, 'Category', 'Segment', 'Sales')

    # 3. Line Charts
    plot_time_series_line(dates, monthly_revenue)

    # 4. KPI Card
    plot_kpi_card(title="ANNUAL SALES", value="$132,000", delta="+18.5% YoY", positive=True)

    # 5. Treemap
    plot_treemap(categories, sales_values)

    # 6. Boxplot
    plot_boxplot_with_fences(df_sample, 'Category', 'Sales')

    # 7. Histogram
    plot_histogram_with_stats(df_sample, 'Sales', bins=20)
    
    # 8. Bonus Diagnostics
    plot_correlation_heatmap(df_sample)
    plot_residuals(df_sample['Sales'], df_sample['Sales'] + np.random.normal(0, 50, len(df_sample)))
    
    print("Graphing suite executed successfully!")
```
