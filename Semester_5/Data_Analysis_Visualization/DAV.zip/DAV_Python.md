# 3CS103ME24: Data Analysis and Visualisation (DAV)
# Module 1: Python Algorithms & Lab Practicals

*Designed for B.Tech Computer Science DAV Lab Exams, Vivas, and Term Submissions.*  
*Contains mathematical concepts, upper-level algorithmic workflows from scratch (using standard `math` / `numpy`), and idiomatic library implementations (`pandas`, `scipy`, `sklearn`).*

---

## Table of Contents
1. [Practical 2: Class Balance, Uncertainty & Data Cleaning](#practical-2)
2. [Practical 3: Five-Number Summary, Central Tendency & Outlier Detection](#practical-3)
3. [Practical 6: Principal Component Analysis (PCA) & Feature Selection](#practical-6)
4. [Practical 7: Supervised Classification & Diagnostics (KNN & Metrics)](#practical-7)
5. [Practical 8: Unsupervised Clustering & Validation (K-Means)](#practical-8)
6. [Practical 9: Regression Techniques & Error Diagnostics (OLS)](#practical-9)
7. [Practical 10: Data Smoothing, Normalization, Redundancy & Discretization](#practical-10)

---

<a name="practical-2"></a>
# Practical 2: Class Balance, Uncertainty & Data Cleaning

### 1. Concepts & Formulas Explained
- **Class Balance Ratio**: Proportion of total instances belonging to class $C_k$:
  $$P(C_k) = \frac{\text{Count of class } C_k}{\text{Total instances } N}$$
- **Imbalance Ratio ($IR$)**: Ratio of majority class instances to minority class instances:
  $$IR = \frac{\max(N_k)}{\min(N_k)}$$
  *Interpretation*: If $IR > 3$, the dataset exhibits class skew. Standard accuracy becomes misleading; evaluate using Precision, Recall, $F_1$, and Stratified Sampling.
- **Missing Data Mechanisms**:
  - **MCAR (Missing Completely at Random)**: Missingness is independent of both observed and unobserved data. Imputation is unbiased.
  - **MAR (Missing at Random)**: Missingness depends on observed features (e.g., older respondents skipping income).
  - **MNAR (Missing Not at Random)**: Missingness depends on the unobserved value itself (e.g., high earners refusing to report wealth).

### 2. Standalone Python Codes

#### A. Class Balance & Imbalance Ratio
```python
# --- WITHOUT HEAVY LIBRARY (Student Level Standalone) ---
def compute_class_balance_scratch(labels):
    """
    Takes a raw list of class labels.
    Returns class counts, percentage distribution, and Imbalance Ratio.
    """
    total = len(labels)
    if total == 0:
        return {}, {}, 0.0
    
    counts = {}
    for y in labels:
        counts[y] = counts.get(y, 0) + 1
        
    proportions = {k: v / total for k, v in counts.items()}
    ir = max(counts.values()) / min(counts.values()) if min(counts.values()) > 0 else float('inf')
    
    return counts, proportions, ir

# --- WITH LIBRARY (Pandas Standalone) ---
import pandas as pd

def compute_class_balance_library(series: pd.Series):
    counts = series.value_counts().to_dict()
    proportions = series.value_counts(normalize=True).to_dict()
    ir = float(series.value_counts().max() / series.value_counts().min())
    return counts, proportions, ir
```

#### B. Data Cleaning & Imputation
```python
# --- WITHOUT HEAVY LIBRARY (Student Level Standalone) ---
def clean_missing_scratch(rows, missing_values=[None, "", "NaN", "null"]):
    """
    Takes a 2D list of rows (table).
    Imputes numeric columns with column mean, and categorical columns with mode.
    """
    if not rows or not rows[0]:
        return []
    
    n_rows = len(rows)
    n_cols = len(rows[0])
    cleaned = [row[:] for row in rows]
    
    for c in range(n_cols):
        col_vals = [cleaned[r][c] for r in range(n_rows)]
        valid_vals = [v for v in col_vals if v not in missing_values]
        
        # Determine if numeric column
        try:
            num_vals = [float(v) for v in valid_vals]
            col_mean = sum(num_vals) / len(num_vals) if num_vals else 0.0
            for r in range(n_rows):
                if cleaned[r][c] in missing_values:
                    cleaned[r][c] = col_mean
        except (ValueError, TypeError):
            # Categorical mode imputation
            freq = {}
            for v in valid_vals:
                freq[v] = freq.get(v, 0) + 1
            mode_val = max(freq, key=freq.get) if freq else ""
            for r in range(n_rows):
                if cleaned[r][c] in missing_values:
                    cleaned[r][c] = mode_val
                    
    return cleaned

# --- WITH LIBRARY (Pandas Standalone) ---
import pandas as pd
import numpy as np

def clean_missing_library(df: pd.DataFrame):
    df_clean = df.copy()
    # Numeric -> median (robust to outliers)
    for col in df_clean.select_dtypes(include=[np.number]).columns:
        df_clean[col] = df_clean[col].fillna(df_clean[col].median())
    # Categorical -> mode
    for col in df_clean.select_dtypes(exclude=[np.number]).columns:
        if df_clean[col].nunique() > 0:
            df_clean[col] = df_clean[col].fillna(df_clean[col].mode()[0])
    df_clean = df_clean.drop_duplicates()
    return df_clean
```

---

<a name="practical-3"></a>
# Practical 3: Five-Number Summary, Central Tendency & Outlier Detection

### 1. Concepts & Formulas Explained
- **Mean ($\bar{x}$)**: $\bar{x} = \frac{1}{N}\sum_{i=1}^N x_i$. Heavily shifted by extreme values.
- **Median ($Q_2$)**: Physical 50th percentile rank of sorted sequence. Robust to extreme outliers.
- **Mode**: Most frequently recurring observation.
- **Midrange**: $\frac{\min + \max}{2}$. Extremely sensitive to outliers.
- **Five-Number Summary**: $[\min, Q_1, \text{Median}, Q_3, \max]$.
- **Interquartile Range (IQR)**: $IQR = Q_3 - Q_1$ (captures the middle 50% data dispersion).
- **Tukey's Fences**:
  $$\text{Lower Fence} = Q_1 - 1.5 \times IQR, \quad \text{Upper Fence} = Q_3 + 1.5 \times IQR$$
  Values outside $[\text{Lower Fence}, \text{Upper Fence}]$ are classified as outliers.
- **Z-Score**: $z = \frac{x - \mu}{\sigma}$. Observations with $|z| > 3.0$ fall beyond $99.7\%$ of Gaussian distribution.

### 2. Standalone Python Codes
```python
# --- WITHOUT HEAVY LIBRARY (Student Level Standalone) ---
import math

def five_number_summary_and_outliers_scratch(numbers):
    """
    Takes a raw list of numbers.
    Computes Min, Q1, Median, Q3, Max, Mode, Midrange, IQR, and Outliers.
    """
    s = sorted([float(x) for x in numbers if x is not None])
    n = len(s)
    if n == 0:
        return {}
    
    # 1. Median helper function
    def calc_med(lst):
        m = len(lst)
        mid = m // 2
        return lst[mid] if m % 2 == 1 else (lst[mid - 1] + lst[mid]) / 2.0
    
    min_v = s[0]
    max_v = s[-1]
    q2 = calc_med(s)
    
    # 2. Quartiles (Tukey method)
    mid = n // 2
    lower_half = s[:mid]
    upper_half = s[mid:] if n % 2 == 0 else s[mid + 1:]
    q1 = calc_med(lower_half)
    q3 = calc_med(upper_half)
    iqr = q3 - q1
    
    # 3. Fences & Outliers
    lf = q1 - 1.5 * iqr
    uf = q3 + 1.5 * iqr
    iqr_outliers = [x for x in s if x < lf or x > uf]
    
    # 4. Mode & Midrange
    freq = {}
    for x in s: freq[x] = freq.get(x, 0) + 1
    max_c = max(freq.values())
    modes = [k for k, v in freq.items() if v == max_c]
    midrange = (min_v + max_v) / 2.0
    
    # 5. Z-Score Outliers (> 3 sigma)
    mean_v = sum(s) / n
    std_v = math.sqrt(sum((x - mean_v) ** 2 for x in s) / n)
    z_outliers = [x for x in s if std_v > 0 and abs((x - mean_v) / std_v) > 3.0]
    
    return {
        "Min": min_v, "Q1": q1, "Median": q2, "Q3": q3, "Max": max_v,
        "IQR": iqr, "Lower_Fence": lf, "Upper_Fence": uf,
        "Mode": modes, "Midrange": midrange,
        "IQR_Outliers": iqr_outliers, "Z_Outliers": z_outliers
    }

# --- WITH LIBRARY (Pandas / Scipy Standalone) ---
import pandas as pd
from scipy import stats

def five_number_summary_and_outliers_library(numbers):
    s = pd.Series(numbers).dropna()
    q1 = float(s.quantile(0.25))
    q2 = float(s.quantile(0.50))
    q3 = float(s.quantile(0.75))
    iqr = q3 - q1
    lf = q1 - 1.5 * iqr
    uf = q3 + 1.5 * iqr
    
    iqr_outliers = s[(s < lf) | (s > uf)].tolist()
    z_scores = stats.zscore(s)
    z_outliers = s[abs(z_scores) > 3.0].tolist()
    
    return {
        "Min": float(s.min()), "Q1": q1, "Median": q2, "Q3": q3, "Max": float(s.max()),
        "IQR": iqr, "Lower_Fence": lf, "Upper_Fence": uf,
        "Mode": s.mode().tolist(), "Midrange": float((s.min() + s.max()) / 2.0),
        "IQR_Outliers": iqr_outliers, "Z_Outliers": z_outliers
    }
```

---

<a name="practical-6"></a>
# Practical 6: Principal Component Analysis (PCA) & Feature Selection

### 1. Concepts & Formulas Explained
- **PCA Objective**: Find orthogonal projection axes (eigenvectors) that maximize variance:
  $$\max_w \text{Var}(Xw) \quad \text{subject to } \|w\|_2 = 1$$
- **Covariance Matrix**:
  $$\Sigma = \frac{1}{N - 1} X_c^T X_c$$
  where $X_c = X - \mu$ is the zero-mean centered feature matrix.
- **Eigendecomposition**:
  $$\Sigma v_i = \lambda_i v_i$$
  where $\lambda_i$ is the eigenvalue (variance along eigenvector $v_i$).
- **Explained Variance Ratio (EVR)**:
  $$EVR_k = \frac{\lambda_k}{\sum_{j=1}^m \lambda_j}$$

### 2. Standalone Python Codes
```python
# --- WITHOUT HEAVY ML LIBRARY (Student Level Standalone) ---
import numpy as np

def pca_student_scratch(matrix, n_components=2):
    """
    Student-level PCA workflow:
    1. Zero-mean center data (X - mean)
    2. Compute covariance matrix
    3. Standard np.linalg.eig for eigenvalues/eigenvectors
    4. Sort descending by eigenvalue magnitude
    5. Calculate EVR and project data
    """
    X = np.array(matrix, dtype=float)
    n_samples, n_features = X.shape
    
    # 1. Centering
    mean_vec = np.mean(X, axis=0)
    X_centered = X - mean_vec
    
    # 2. Covariance Matrix
    cov_matrix = np.dot(X_centered.T, X_centered) / (n_samples - 1)
    
    # 3. Eigendecomposition
    eigenvalues, eigenvectors = np.linalg.eig(cov_matrix)
    
    # 4. Sort eigenvalues descending
    sort_indices = np.argsort(eigenvalues)[::-1]
    sorted_evals = eigenvalues[sort_indices]
    sorted_evecs = eigenvectors[:, sort_indices]
    
    # 5. Explained Variance Ratio
    total_var = np.sum(sorted_evals)
    evr = (sorted_evals[:n_components] / total_var).tolist()
    
    # 6. Project onto top n_components
    W = sorted_evecs[:, :n_components]
    projected_data = np.dot(X_centered, W).tolist()
    
    return {
        "Eigenvalues": sorted_evals[:n_components].tolist(),
        "Eigenvectors": W.tolist(),
        "Explained_Variance_Ratio": evr,
        "Projected_Data": projected_data
    }

# --- WITH SCIKIT-LEARN (Standalone) ---
from sklearn.decomposition import PCA

def pca_library(matrix, n_components=2):
    pca = PCA(n_components=n_components)
    projected = pca.fit_transform(matrix)
    return {
        "EVR": pca.explained_variance_ratio_.tolist(),
        "Projected_Data": projected.tolist()
    }
```

---

<a name="practical-7"></a>
# Practical 7: Supervised Classification & Diagnostics (KNN & Metrics)

### 1. Concepts & Formulas Explained
- **Shannon Entropy**: Impurity measure of a partition. $H(S) = -\sum_{i=1}^c p_i \log_2(p_i)$.
- **Information Gain**: Expected entropy reduction after splitting on feature $A$:
  $$Gain(S, A) = H(S) - \sum_{v \in Values(A)} \frac{|S_v|}{|S|} H(S_v)$$
- **Gini Impurity**: $Gini(S) = 1 - \sum_{i=1}^c p_i^2$.
- **KNN Euclidean Distance**:
  $$d(p, q) = \sqrt{\sum_{j=1}^m (p_j - q_j)^2}$$
- **Diagnostic Metrics**:
  $$\text{Accuracy} = \frac{TP + TN}{TP + TN + FP + FN}, \quad \text{Precision} = \frac{TP}{TP + FP}$$
  $$\text{Recall} = \frac{TP}{TP + FN}, \quad F_1 = \frac{2 \cdot \text{Precision} \cdot \text{Recall}}{\text{Precision} + \text{Recall}}$$

### 2. Standalone Python Codes
```python
# --- WITHOUT HEAVY ML LIBRARY (Student Level Standalone) ---
import math

class KNNClassifierStudent:
    def __init__(self, k=3):
        self.k = k
        self.X_train = []
        self.y_train = []

    def fit(self, X_train, y_train):
        self.X_train = X_train
        self.y_train = y_train

    def predict(self, X_test):
        preds = []
        for test_pt in X_test:
            # 1. Distances to all training points
            dists = []
            for i, tr_pt in enumerate(self.X_train):
                d = math.sqrt(sum((test_pt[j] - tr_pt[j]) ** 2 for j in range(len(test_pt))))
                dists.append((d, self.y_train[i]))
            # 2. Sort by distance & pick top k
            dists.sort(key=lambda t: t[0])
            top_k_labels = [label for _, label in dists[:self.k]]
            # 3. Majority vote
            counts = {}
            for l in top_k_labels: counts[l] = counts.get(l, 0) + 1
            preds.append(max(counts, key=counts.get))
        return preds

def classification_metrics_scratch(y_true, y_pred, pos_label=1):
    tp = sum(1 for t, p in zip(y_true, y_pred) if t == pos_label and p == pos_label)
    fp = sum(1 for t, p in zip(y_true, y_pred) if t != pos_label and p == pos_label)
    fn = sum(1 for t, p in zip(y_true, y_pred) if t == pos_label and p != pos_label)
    tn = sum(1 for t, p in zip(y_true, y_pred) if t != pos_label and p != pos_label)
    
    total = len(y_true)
    acc = (tp + tn) / total if total > 0 else 0.0
    prec = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    rec = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    f1 = (2 * prec * rec) / (prec + rec) if (prec + rec) > 0 else 0.0
    
    return {
        "Accuracy": acc, "Precision": prec, "Recall": rec, "F1": f1,
        "CM": {"TP": tp, "FP": fp, "TN": tn, "FN": fn}
    }

# --- WITH SCIKIT-LEARN (Standalone) ---
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import classification_report

def knn_library(X_train, y_train, X_test, y_test, k=3):
    clf = KNeighborsClassifier(n_neighbors=k).fit(X_train, y_train)
    preds = clf.predict(X_test)
    return classification_report(y_test, preds, output_dict=True)
```

---

<a name="practical-8"></a>
# Practical 8: Unsupervised Clustering & Validation (K-Means)

### 1. Concepts & Formulas Explained
- **K-Means Objective (WCSS / Inertia)**:
  $$WCSS = \sum_{k=1}^K \sum_{x \in C_k} \|x - \mu_k\|^2$$
- **Silhouette Coefficient**:
  $$s(i) = \frac{b(i) - a(i)}{\max(a(i), b(i))}, \quad -1 \le s(i) \le +1$$
  - $a(i)$: Mean intra-cluster distance between sample $i$ and all points in its cluster.
  - $b(i)$: Mean nearest-cluster distance between sample $i$ and the closest neighboring cluster.

### 2. Standalone Python Codes
```python
# --- WITHOUT HEAVY ML LIBRARY (Student Level Standalone) ---
import math

class KMeansStudent:
    def __init__(self, k=3, max_iter=100):
        self.k = k
        self.max_iter = max_iter

    def fit(self, data):
        n_features = len(data[0])
        # Seed first k instances as initial centroids
        self.centroids = [data[i][:] for i in range(self.k)]
        
        for _ in range(self.max_iter):
            # Assignment phase
            clusters = [[] for _ in range(self.k)]
            self.labels = []
            for pt in data:
                dists = [math.sqrt(sum((pt[j] - c[j]) ** 2 for j in range(n_features))) for c in self.centroids]
                closest = dists.index(min(dists))
                clusters[closest].append(pt)
                self.labels.append(closest)
                
            # Update phase
            new_centroids = []
            for k_idx in range(self.k):
                pts = clusters[k_idx]
                if pts:
                    new_centroids.append([sum(p[j] for p in pts) / len(pts) for j in range(n_features)])
                else:
                    new_centroids.append(self.centroids[k_idx])
                    
            # Check convergence
            shifts = [math.sqrt(sum((self.centroids[k][j] - new_centroids[k][j]) ** 2 for j in range(n_features))) for k in range(self.k)]
            self.centroids = new_centroids
            if max(shifts) < 1e-4: break
            
        # Total WCSS
        self.wcss = sum(sum((data[i][j] - self.centroids[self.labels[i]][j]) ** 2 for j in range(n_features)) for i in range(len(data)))
        return self

# --- WITH SCIKIT-LEARN (Standalone) ---
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score

def kmeans_library(data, k=3):
    km = KMeans(n_clusters=k, random_state=42, n_init=10).fit(data)
    sil = silhouette_score(data, km.labels_)
    return {
        "Centroids": km.cluster_centers_.tolist(),
        "Labels": km.labels_.tolist(),
        "WCSS": float(km.inertia_),
        "Silhouette": float(sil)
    }
```

---

<a name="practical-9"></a>
# Practical 9: Regression Techniques & Error Diagnostics (OLS)

### 1. Concepts & Formulas Explained
- **Simple Linear Regression Closed Form**:
  $$m = \frac{\sum (x_i - \bar{x})(y_i - \bar{y})}{\sum (x_i - \bar{x})^2}, \quad c = \bar{y} - m\bar{x}$$
- **Regression Evaluation Metrics**:
  $$MAE = \frac{1}{N}\sum_{i=1}^N |y_i - \hat{y}_i|, \quad MSE = \frac{1}{N}\sum_{i=1}^N (y_i - \hat{y}_i)^2, \quad RMSE = \sqrt{MSE}$$
  $$R^2 = 1 - \frac{\sum (y_i - \hat{y}_i)^2}{\sum (y_i - \bar{y})^2}$$

### 2. Standalone Python Codes
```python
# --- WITHOUT HEAVY ML LIBRARY (Student Level Standalone) ---
import math

def simple_ols_scratch(x, y):
    n = len(x)
    mx, my = sum(x) / n, sum(y) / n
    m = sum((x[i] - mx) * (y[i] - my) for i in range(n)) / sum((x[i] - mx) ** 2 for i in range(n))
    c = my - m * mx
    
    y_pred = [m * val + c for val in x]
    mae = sum(abs(y[i] - y_pred[i]) for i in range(n)) / n
    mse = sum((y[i] - y_pred[i]) ** 2 for i in range(n)) / n
    rmse = math.sqrt(mse)
    ss_tot = sum((val - my) ** 2 for val in y)
    r2 = 1.0 - (sum((y[i] - y_pred[i]) ** 2 for i in range(n)) / ss_tot) if ss_tot > 0 else 0.0
    
    return {
        "Slope": m, "Intercept": c, "Predictions": y_pred,
        "MAE": mae, "MSE": mse, "RMSE": rmse, "R2": r2
    }

# --- WITH SCIKIT-LEARN (Standalone) ---
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
import numpy as np

def simple_ols_library(x, y):
    X_arr = np.array(x).reshape(-1, 1)
    model = LinearRegression().fit(X_arr, y)
    preds = model.predict(X_arr)
    return {
        "Slope": float(model.coef_[0]), "Intercept": float(model.intercept_),
        "RMSE": float(np.sqrt(mean_squared_error(y, preds))), "R2": float(r2_score(y, preds))
    }
```

---

<a name="practical-10"></a>
# Practical 10: Data Smoothing, Normalization, Redundancy & Discretization

### 1. Concepts & Formulas Explained
- **Bin Smoothing**: Sort data, partition into $k$ bins, replace bin elements with Mean, Median, or Boundaries.
- **Min-Max Normalization**:
  $$v' = \frac{v - \min_A}{\max_A - \min_A} (new\_max_A - new\_min_A) + new\_min_A$$
- **Z-Score Standardization**:
  $$v' = \frac{v - \mu_A}{\sigma_A}$$
- **Decimal Scaling**:
  $$v' = \frac{v}{10^j}, \quad \text{where } j \text{ is the smallest integer such that } \max(|v'|) < 1$$
- **Pearson Product-Moment Correlation**:
  $$r_{A, B} = \frac{\sum (a_i - \bar{A})(b_i - \bar{B})}{(N - 1) s_A s_B}$$
- **Chi-Square ($\chi^2$) Independence Test**:
  $$\chi^2 = \sum \frac{(O_{ij} - E_{ij})^2}{E_{ij}}, \quad E_{ij} = \frac{\text{row\_total}_i \times \text{col\_total}_j}{N}$$

### 2. Standalone Python Codes
```python
# --- WITHOUT HEAVY ML LIBRARY (Student Level Standalone) ---
import math

# 1. Smoothing (Bin Mean, Median, Boundary)
def bin_smoothing_scratch(data, bin_size=3, method='mean'):
    s = sorted(data)
    smoothed = []
    for i in range(0, len(s), bin_size):
        b = s[i:i + bin_size]
        if method == 'mean':
            smoothed.extend([sum(b) / len(b)] * len(b))
        elif method == 'median':
            m = len(b)
            med = b[m // 2] if m % 2 == 1 else (b[m // 2 - 1] + b[m // 2]) / 2.0
            smoothed.extend([med] * len(b))
        elif method == 'boundary':
            for x in b:
                smoothed.append(b[0] if abs(x - b[0]) <= abs(x - b[-1]) else b[-1])
    return smoothed

# 2. Normalization (Min-Max, Z-Score, Decimal Scaling)
def normalize_all_scratch(data):
    n = len(data)
    mn, mx = min(data), max(data)
    mean_v = sum(data) / n
    std_v = math.sqrt(sum((x - mean_v) ** 2 for x in data) / n)
    j = len(str(int(max(abs(x) for x in data)))) if max(abs(x) for x in data) >= 1 else 0
    scale = 10 ** j
    
    return {
        "MinMax": [(x - mn) / (mx - mn) if mx != mn else 0.0 for x in data],
        "ZScore": [(x - mean_v) / std_v if std_v > 0 else 0.0 for x in data],
        "DecimalScaling": [x / scale for x in data]
    }

# 3. Pearson Correlation
def pearson_scratch(x, y):
    n = len(x)
    mx, my = sum(x) / n, sum(y) / n
    num = sum((x[i] - mx) * (y[i] - my) for i in range(n))
    den = math.sqrt(sum((x[i] - mx)**2 for i in range(n)) * sum((y[i] - my)**2 for i in range(n)))
    return num / den if den != 0 else 0.0

# 4. Chi-Square Test from Raw Categorical Lists
def chi_square_scratch(col_a, col_b):
    cats_a, cats_b = sorted(list(set(col_a))), sorted(list(set(col_b)))
    table = {ca: {cb: 0 for cb in cats_b} for ca in cats_a}
    for a, b in zip(col_a, col_b): table[a][b] += 1
    
    row_t = {ca: sum(table[ca].values()) for ca in cats_a}
    col_t = {cb: sum(table[ca][cb] for ca in cats_a) for cb in cats_b}
    grand = len(col_a)
    
    chi2 = 0.0
    for ca in cats_a:
        for cb in cats_b:
            exp = (row_t[ca] * col_t[cb]) / grand
            obs = table[ca][cb]
            if exp > 0: chi2 += ((obs - exp) ** 2) / exp
    dof = (len(cats_a) - 1) * (len(cats_b) - 1)
    return {"Chi2": chi2, "DoF": dof}

# 5. Discretization (Equal-Width & Equal-Frequency)
def discretize_scratch(data, k=3):
    # Equal Width
    mn, mx = min(data), max(data)
    w = (mx - mn) / k
    ew = [f"W_Bin_{min(int((x - mn)/w) + 1, k)}" for x in data]
    # Equal Frequency
    indexed = sorted(enumerate(data), key=lambda t: t[1])
    n = len(data)
    bin_size = n // k
    ef = [None] * n
    for rank, (orig_i, _) in enumerate(indexed):
        ef[orig_i] = f"F_Bin_{min(rank // bin_size + 1, k)}"
    return {"Equal_Width": ew, "Equal_Frequency": ef}

# --- WITH LIBRARIES (Pandas / Scipy Standalone) ---
import pandas as pd
from scipy import stats
from sklearn.preprocessing import MinMaxScaler, StandardScaler
import numpy as np

def preprocessing_libraries(series_num, col_a, col_b, k=3):
    arr = series_num.values.reshape(-1, 1)
    mm = MinMaxScaler().fit_transform(arr).flatten().tolist()
    zs = StandardScaler().fit_transform(arr).flatten().tolist()
    r, _ = stats.pearsonr(series_num, series_num)
    contingency = pd.crosstab(pd.Series(col_a), pd.Series(col_b))
    chi2, p_val, dof, _ = stats.chi2_contingency(contingency)
    ew = pd.cut(series_num, bins=k, labels=[f"W{i+1}" for i in range(k)]).tolist()
    ef = pd.qcut(series_num, q=k, labels=[f"F{i+1}" for i in range(k)], duplicates='drop').tolist()
    return {"MinMax": mm, "ZScore": zs, "Chi2": float(chi2), "EqualWidth": ew, "EqualFrequency": ef}
```
